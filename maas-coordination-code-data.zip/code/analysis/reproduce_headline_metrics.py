#!/usr/bin/env python3
"""Reproduce the five headline metrics reported for the eight stress worlds."""

from __future__ import annotations

import argparse
import csv
import math
import statistics
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
SEEDS = (42, 43, 44, 45, 46)
T_CRITICAL_95_DF4 = 2.776
VALUE_OF_TIME = {"low": 5.0, "middle": 10.0, "high": 20.0}
METRICS = (
    ("gencost", "Generalised cost (minutes-equivalent per trip)", "low"),
    ("d2d_tt_min", "Door-to-door TT (min)", "low"),
    ("match_rate", "Match rate", "high"),
    ("pt_serve", "PT served", "high"),
    ("income_time_gap_min", "Income time-gap (min)", "abs_lower"),
)


def _rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def _successful(rows: list[dict[str, str]]) -> list[dict[str, str]]:
    return [row for row in rows if row.get("outcome", "").strip().lower() == "success"]


def _travel_minutes(row: dict[str, str]) -> float:
    return float(row["travel_time"]) * 10.0


def _metric(rows: list[dict[str, str]], name: str) -> float:
    served = _successful(rows)
    if name == "match_rate":
        return len(served) / len(rows)
    if name == "d2d_tt_min":
        return statistics.mean(_travel_minutes(row) for row in served)
    if name == "gencost":
        return statistics.mean(
            _travel_minutes(row)
            + float(row["price"]) / VALUE_OF_TIME[row["income_group"].strip().lower()] * 60.0
            for row in served
        )
    if name == "pt_serve":
        return float(sum(row.get("chosen_mode", "").strip().lower() in {"public", "bundle"} for row in served))
    if name == "income_time_gap_min":
        by_income = {
            income: statistics.mean(
                _travel_minutes(row)
                for row in served
                if row.get("income_group", "").strip().lower() == income
            )
            for income in ("low", "high")
        }
        return by_income["low"] - by_income["high"]
    raise KeyError(name)


def _mean_ci(values: list[float]) -> tuple[float, float]:
    mean = statistics.mean(values)
    if len(values) < 2:
        return mean, 0.0
    ci = T_CRITICAL_95_DF4 * statistics.stdev(values) / math.sqrt(len(values))
    return mean, ci


def _winner(c_mean: float, d_mean: float, direction: str) -> str:
    if direction == "high":
        return "D" if d_mean > c_mean else "C" if c_mean > d_mean else "Tie"
    if direction == "abs_lower":
        return "D" if abs(d_mean) < abs(c_mean) else "C" if abs(c_mean) < abs(d_mean) else "Tie"
    return "D" if d_mean < c_mean else "C" if c_mean < d_mean else "Tie"


def reproduce() -> list[dict[str, object]]:
    data_root = ROOT / "data" / "stress_runs"
    worlds = sorted(path.name for path in (data_root / "seed_42").iterdir() if path.is_dir())
    output: list[dict[str, object]] = []
    for world in worlds:
        for metric, label, direction in METRICS:
            c_values: list[float] = []
            d_values: list[float] = []
            for seed in SEEDS:
                cell = data_root / f"seed_{seed}" / world
                c_values.append(_metric(_rows(cell / "centralised" / "requests.csv"), metric))
                d_values.append(_metric(_rows(cell / "decentralised" / "requests.csv"), metric))
            c_mean, c_ci = _mean_ci(c_values)
            d_mean, d_ci = _mean_ci(d_values)
            differences = [d - c for c, d in zip(c_values, d_values)]
            diff, diff_ci = _mean_ci(differences)
            output.append(
                {
                    "world": world,
                    "metric": metric,
                    "label": label,
                    "direction": direction,
                    "c_mean": c_mean,
                    "c_ci": c_ci,
                    "d_mean": d_mean,
                    "d_ci": d_ci,
                    "diff": diff,
                    "diff_ci": diff_ci,
                    "winner": _winner(c_mean, d_mean, direction),
                    "significant": bool(diff_ci > 0.0 and abs(diff) > diff_ci),
                }
            )
    return output


def _write(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def _check(rows: list[dict[str, object]], tolerance: float = 1e-9) -> None:
    expected_path = ROOT / "data" / "source_data" / "sydney" / "stop16_sydney_spec3_5metric_win_table.csv"
    expected = _rows(expected_path)
    if len(rows) != len(expected):
        raise SystemExit(f"FAIL: reproduced {len(rows)} rows; expected {len(expected)}")
    numeric = {"c_mean", "c_ci", "d_mean", "d_ci", "diff", "diff_ci"}
    for index, (actual, reference) in enumerate(zip(rows, expected), start=2):
        for field in actual:
            if field in numeric:
                if not math.isclose(float(actual[field]), float(reference[field]), rel_tol=tolerance, abs_tol=tolerance):
                    raise SystemExit(
                        f"FAIL: row {index} {field}: reproduced {actual[field]} != stored {reference[field]}"
                    )
            elif str(actual[field]) != str(reference[field]):
                raise SystemExit(
                    f"FAIL: row {index} {field}: reproduced {actual[field]!r} != stored {reference[field]!r}"
                )
    print(f"PASS: {len(rows)} headline rows reproduce the stored source table.")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, help="Optional path for the reproduced CSV.")
    parser.add_argument("--check", action="store_true", help="Compare against the archived source table.")
    args = parser.parse_args()
    rows = reproduce()
    if args.output:
        _write(args.output, rows)
        print(f"Wrote {args.output}")
    if args.check:
        _check(rows)
    if not args.output and not args.check:
        parser.error("select --check, --output PATH, or both")


if __name__ == "__main__":
    main()
