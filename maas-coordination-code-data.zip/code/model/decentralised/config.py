"""
Configuration parameters aligned with centralized ABM model.
All values match ABM_ETOP_framework/MaaS-Centralised/spf_abm_analysis_separate/database_01.py
"""

# Random seed for reproducibility
RANDOM_SEED = 42

# Simulation parameters
SIMULATION_STEPS = 120
TIME_STEP_MINUTES = 10  # Each step represents 10 minutes
STEPS_PER_DAY = 144     # 24 hours * 6 (10-min intervals)

# Grid parameters
GRID_WIDTH = 85
GRID_HEIGHT = 85

# Population parameters
NUM_COMMUTERS = 130
INCOME_WEIGHTS = [0.5, 0.3, 0.2]  # [low, middle, high]
HEALTH_WEIGHTS = [0.9, 0.1]       # [good, poor]
PAYMENT_WEIGHTS = [0.8, 0.2]      # [PAYG, subscription]
DISABILITY_WEIGHTS = [0.2, 0.8]   # [has_disability, no_disability]
TECH_ACCESS_WEIGHTS = [0.95, 0.05]  # [has_access, no_access]

AGE_DISTRIBUTION = {
    (18, 25): 0.2, 
    (26, 35): 0.3, 
    (36, 45): 0.2, 
    (46, 55): 0.15, 
    (56, 65): 0.1, 
    (66, 75): 0.05,
}

# Value of Time (per 10 minutes)
VALUE_OF_TIME = {
    'low': 5, 
    'middle': 10, 
    'high': 20
}

# Utility function coefficients
UTILITY_FUNCTION_BASE_COEFFICIENTS = {
    'beta_C': -0.15,  # Cost coefficient
    'beta_T': -0.09,  # Time coefficient
    'beta_W': -0.04,  # Walk coefficient
    'beta_A': -0.04,  # Affordability coefficient
    'alpha': -0.01    # Constant
}

# Alternative-Specific Constants
ASC_VALUES = {
    'walk': 0,
    'bike': 0,
    'car': 0,
    'public': 0,
    'bus': 0,
    'train': 0,
    'maas': 0,      # v8 parity fix (parity_audit Step 1): unified with centralised
    'bundle': 0,    #  ASC_VALUES.maas = 0. Was +8 in D only, +0 in C — an
                    #  unintended asymmetry that biased D's argmax toward bundles.
    'default': 0
}

# Penalty coefficients
PENALTY_COEFFICIENTS = {
    'disability_bike_walk': 0.8,
    'age_health_bike_walk': 0.3,
    'no_tech_access_car_bike': 0.1
}

# Affordability thresholds
AFFORDABILITY_THRESHOLDS = {
    'low': 25, 
    'middle': 40, 
    'high': 130
}

# Flexibility adjustments
FLEXIBILITY_ADJUSTMENTS = {
    'low': 1.15, 
    'medium': 1.0, 
    'high': 0.85
}

# Congestion parameters (BPR function)
CONGESTION_ALPHA = 0.03
CONGESTION_BETA = 1.5
CONGESTION_CAPACITY = 10
CONGESTION_T_IJ_FREE_FLOW = 1.5
BACKGROUND_TRAFFIC_AMOUNT = 120
CHANCE_FOR_INSERTING_RANDOM_TRAFFIC = 0.2

# Provider parameters
UBER_LIKE1_CAPACITY = 15
UBER_LIKE1_PRICE = 15.5

UBER_LIKE2_CAPACITY = 19
UBER_LIKE2_PRICE = 16.5

BIKE_SHARE1_CAPACITY = 10
BIKE_SHARE1_PRICE = 2.5

BIKE_SHARE2_CAPACITY = 12
BIKE_SHARE2_PRICE = 3.0

# Public transport pricing
PUBLIC_PRICE_TABLE = {
    'train': {'on_peak': 3.0, 'off_peak': 2.6},
    'bus': {'on_peak': 2.4, 'off_peak': 2.0}
}

# Peak hours (in steps, 0-143 for a day)
PEAK_HOURS = [(36, 60), (90, 114)]

# Dynamic pricing parameters
DYNAMIC_MAAS_SURCHARGE_BASE_COEFFICIENTS = {
    'S_base': 0.02,
    'alpha': 0.10,
    'delta': 0.5
}

ALPHA_VALUES = {
    'UberLike1': 0.3,
    'UberLike2': 0.3,
    'BikeShare1': 0.25,
    'BikeShare2': 0.25
}

# Subsidy dataset
SUBSIDY_DATASET = {
    'low': {'bike': 0.50, 'car': 0.55, 'MaaS_Bundle': 0.5},
    'middle': {'bike': 0.23, 'car': 0.35, 'MaaS_Bundle': 0.35},
    'high': {'bike': 0.1, 'car': 0.05, 'MaaS_Bundle': 0.1},
}

