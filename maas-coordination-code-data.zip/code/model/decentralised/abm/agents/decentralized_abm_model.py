from mesa import Model
from mesa.space import MultiGrid
from mesa.time import RandomActivation
from mesa.datacollection import DataCollector

from abm.agents.decentralized_commuter import DecentralizedCommuter
from abm.agents.decentralized_provider import DecentralizedProvider, PublicTransportProvider
from abm.agents.speculator_agent import SpeculatorAgent
from abm.agents.nft_marketplace import NFTMarketplace

import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from abm.utils.blockchain_interface import BlockchainInterface

# Import non-canonical behavior defaults from local decentralized config.
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../..'))
try:
    import config as local_config
except ImportError:
    local_config = None


def _cfg(name, default):
    if local_config is None:
        return default
    return getattr(local_config, name, default)


INCOME_WEIGHTS = _cfg("INCOME_WEIGHTS", [0.5, 0.3, 0.2])
HEALTH_WEIGHTS = _cfg("HEALTH_WEIGHTS", [0.9, 0.1])
PAYMENT_WEIGHTS = _cfg("PAYMENT_WEIGHTS", [0.8, 0.2])
AGE_DISTRIBUTION = _cfg("AGE_DISTRIBUTION", {(18, 25): 0.2, (26, 35): 0.3, (36, 45): 0.2, (46, 55): 0.15, (56, 65): 0.1, (66, 75): 0.05})
DISABILITY_WEIGHTS = _cfg("DISABILITY_WEIGHTS", [0.2, 0.8])
TECH_ACCESS_WEIGHTS = _cfg("TECH_ACCESS_WEIGHTS", [0.95, 0.05])
UBER_LIKE1_CAPACITY = _cfg("UBER_LIKE1_CAPACITY", 15)
UBER_LIKE1_PRICE = _cfg("UBER_LIKE1_PRICE", 15.5)
UBER_LIKE2_CAPACITY = _cfg("UBER_LIKE2_CAPACITY", 19)
UBER_LIKE2_PRICE = _cfg("UBER_LIKE2_PRICE", 16.5)
BIKE_SHARE1_CAPACITY = _cfg("BIKE_SHARE1_CAPACITY", 10)
BIKE_SHARE1_PRICE = _cfg("BIKE_SHARE1_PRICE", 2.5)
BIKE_SHARE2_CAPACITY = _cfg("BIKE_SHARE2_CAPACITY", 12)
BIKE_SHARE2_PRICE = _cfg("BIKE_SHARE2_PRICE", 3.0)
CONGESTION_ALPHA = _cfg("CONGESTION_ALPHA", 0.03)
CONGESTION_BETA = _cfg("CONGESTION_BETA", 1.5)
BACKGROUND_TRAFFIC_AMOUNT = _cfg("BACKGROUND_TRAFFIC_AMOUNT", 120)
DECENTRALISED_CONGESTION_CAPACITY = _cfg("DECENTRALISED_CONGESTION_CAPACITY", 70)

REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../../"))
if REPO_ROOT not in sys.path:
    sys.path.insert(0, REPO_ROOT)

from shared_experiment_config import (
    RANDOM_SEED,
    SIMULATION_STEPS,
    GRID_WIDTH,
    GRID_HEIGHT,
    NUM_COMMUTERS,
    SMALL_WORLD_P,
    PT_IN_VEHICLE_PER_HOP,
)
from shared_frozen_inputs import (
    group_trips_by_canonical_commuter,
    load_fixed_commuters,
    load_fixed_trip_requests,
)
from shared_cross_world_runtime import (
    normalize_world_settings,
    resolve_background_traffic_amount,
)
from shared_topology_v2 import build_subcentre_hubs, get_small_world_map
from shared_pt_router import pt_route_time_between_points, reset_pt_router_stats
from shared_trip_generator import generate_two_trip_day, trip_stream_fingerprint
from shared_supply_v2_config import get_v2_supply_definition

import numpy as np
import random
import logging
import time
import math
import json
from datetime import datetime


def _env_flag(name, default):
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in ("1", "true", "yes", "on")


class DecentralizedMaaSModel(Model):
    """
    Agent-based model for decentralized Mobility-as-a-Service with blockchain integration.
    Includes NFT marketplace and AMM for time-sensitive pricing of mobility services.
    """
    def __init__(self,
                 num_providers=20,
                 grid_width=GRID_WIDTH,  # Changed from 25 to 85
                 grid_height=GRID_HEIGHT,  # Changed from 25 to 85
                 num_commuters=NUM_COMMUTERS,  # Changed from 20 to 130
                 income_weights=INCOME_WEIGHTS,  # Changed from [0.3, 0.5, 0.2] to [0.5, 0.3, 0.2]
                 health_weights=HEALTH_WEIGHTS,  # Changed from [0.8, 0.2] to [0.9, 0.1]
                 payment_weights=PAYMENT_WEIGHTS,  # Changed from [0.7, 0.3] to [0.8, 0.2]
                 age_distribution=AGE_DISTRIBUTION,  # Updated to match centralized
                 disability_weights=DISABILITY_WEIGHTS,  # Changed from [0.1, 0.9] to [0.2, 0.8]
                 tech_access_weights=TECH_ACCESS_WEIGHTS,  # Changed from [0.85, 0.15] to [0.95, 0.05]
                 uber_like1_capacity=UBER_LIKE1_CAPACITY,  # Changed from 50 to 15
                 uber_like1_price=UBER_LIKE1_PRICE,  # Changed from 1.2 to 15.5
                 uber_like2_capacity=UBER_LIKE2_CAPACITY,  # Changed from 30 to 19
                 uber_like2_price=UBER_LIKE2_PRICE,  # Changed from 1.0 to 16.5
                 bike_share1_capacity=BIKE_SHARE1_CAPACITY,  # Kept at 10
                 bike_share1_price=BIKE_SHARE1_PRICE,  # Changed from 0.5 to 2.5
                 bike_share2_capacity=BIKE_SHARE2_CAPACITY,  # Changed from 8 to 12
                 bike_share2_price=BIKE_SHARE2_PRICE,  # Changed from 0.4 to 3.0
                 stations=None,
                 routes=None,
                 transfers=None,
                 blockchain_config="../../blockchain_config.json",
                 market_type="hybrid",
                 time_decay_factor=0.1,
                 min_price_ratio=0.5,
                 enable_speculators=None,
                 enable_resale_market=None,
                 enable_market_extensions=None,
                 disable_random_provider_topup=False,
                 use_v2_supply_config=False,
                 comparison_relaxed_direct_offers=False,
                 comparison_offer_exposure_formalized=False,
                 comparison_pt_bundle_feasibility=False,
                 world_settings=None,
                 run_seed=RANDOM_SEED,
                 fixed_commuters_path=None,
                 fixed_trip_requests_path=None):
        """
        Initialize the decentralized MaaS model with blockchain integration.
        
        Args:
            grid_width, grid_height: Dimensions of the simulation grid
            num_commuters: Number of commuter agents
            income_weights: Distribution of income levels (low, middle, high)
            health_weights: Distribution of health status (good, poor)
            payment_weights: Distribution of payment schemes (PAYG, subscription)
            age_distribution: Distribution of age ranges
            disability_weights: Distribution of disability status
            tech_access_weights: Distribution of technology access
            uber_like1/2_capacity/price: Capacity and pricing for car services
            bike_share1/2_capacity/price: Capacity and pricing for bike services
            stations: Public transport stations (optional)
            routes: Public transport routes (optional)
            transfers: Public transport transfers (optional)
            blockchain_config: Configuration file for blockchain interface
            time_decay_factor: Rate of price decay as service time approaches
            min_price_ratio: Minimum price as ratio of initial price
        """
        super().__init__()

        # SET RANDOM SEEDS FIRST - CRITICAL FOR REPRODUCIBILITY
        random.seed(run_seed)
        np.random.seed(run_seed)
        self.run_seed = run_seed
        reset_pt_router_stats()
        if num_commuters != NUM_COMMUTERS:
            print(
                f"Using fixed-input/world commuter count={num_commuters} "
                f"instead of canonical NUM_COMMUTERS={NUM_COMMUTERS}"
            )
        grid_width = GRID_WIDTH
        grid_height = GRID_HEIGHT
        num_commuters = int(num_commuters)
        self.world_settings = normalize_world_settings(world_settings)
        self.background_traffic_amount = resolve_background_traffic_amount(
            world_settings=self.world_settings,
            baseline_amount=BACKGROUND_TRAFFIC_AMOUNT,
        )

        # Configure logging
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger("DecentralizedMaaSModel")
        self.logger.info(f"🎲 Random seed set to: {run_seed}")
        self.logger.info(f"📊 Grid size: {grid_width}×{grid_height}, Commuters: {num_commuters}")
        self.num_providers = num_providers
        if enable_speculators is None:
            enable_speculators = _env_flag("ENABLE_SPECULATORS", False)
        if enable_resale_market is None:
            enable_resale_market = _env_flag("ENABLE_RESALE_MARKET", False)
        if enable_market_extensions is None:
            enable_market_extensions = _env_flag("ENABLE_MARKET_EXTENSIONS", False)
        self.enable_speculators = bool(enable_speculators)
        self.enable_resale_market = bool(enable_resale_market)
        self.enable_market_extensions = bool(enable_market_extensions)
        self.disable_random_provider_topup = bool(disable_random_provider_topup)
        self.use_v2_supply_config = bool(use_v2_supply_config)
        self.comparison_relaxed_direct_offers = bool(comparison_relaxed_direct_offers)
        self.comparison_offer_exposure_formalized = bool(comparison_offer_exposure_formalized)
        self.comparison_pt_bundle_feasibility = bool(comparison_pt_bundle_feasibility)
        if self.comparison_pt_bundle_feasibility and self.comparison_relaxed_direct_offers:
            self.bundle_walk_radius = 35.0
            self.bundle_time_tolerance = 60.0
        elif self.comparison_pt_bundle_feasibility:
            self.bundle_walk_radius = 15.0
            self.bundle_time_tolerance = 30.0
        else:
            self.bundle_walk_radius = 10.0
            self.bundle_time_tolerance = 30.0
        # v8 parity_audit Arm B2: labelled first/last-mile walk-catchment sweep.
        # Overrides the mode-dependent default so a single knob controls the arm.
        _b2_env = os.environ.get("V8_BUNDLE_WALK_RADIUS")
        if _b2_env is not None:
            try:
                self.bundle_walk_radius = float(_b2_env)
            except ValueError:
                self.logger.warning("V8_BUNDLE_WALK_RADIUS=%r not a float; ignoring", _b2_env)
        # V9 §26.7 Phase 1.2: shared walk_catchment_radius. Mirrors Rep tree.
        try:
            from shared_experiment_config import WALK_CATCHMENT_RADIUS
        except Exception:
            WALK_CATCHMENT_RADIUS = None
        _neutral = os.environ.get("V9_NEUTRAL_SPEC", "").strip().lower() in ("1", "true", "yes", "on")
        if _neutral and _b2_env is None and WALK_CATCHMENT_RADIUS is not None:
            self.bundle_walk_radius = float(WALK_CATCHMENT_RADIUS)
            self.logger.info(
                "V9_NEUTRAL_SPEC=1: bundle_walk_radius bound to shared WALK_CATCHMENT_RADIUS=%.2f",
                self.bundle_walk_radius,
            )
        self.logger.info(
            "Market mode flags: speculators=%s resale=%s extensions=%s disable_random_provider_topup=%s use_v2_supply_config=%s relaxed_direct_offers=%s offer_exposure_formalized=%s pt_bundle_feasibility=%s bundle_walk_radius=%.1f bundle_time_tolerance=%.1f",
            self.enable_speculators,
            self.enable_resale_market,
            self.enable_market_extensions,
            self.disable_random_provider_topup,
            self.use_v2_supply_config,
            self.comparison_relaxed_direct_offers,
            self.comparison_offer_exposure_formalized,
            self.comparison_pt_bundle_feasibility,
            self.bundle_walk_radius,
            self.bundle_time_tolerance,
        )
        self.v2_supply_definition = (
            get_v2_supply_definition(world_settings=self.world_settings)
            if self.use_v2_supply_config
            else None
        )
        
        # Basic model setup
        self.grid = MultiGrid(grid_width, grid_height, torus=False)
        self.schedule = RandomActivation(self)
        self.running = True
        self.current_step = 0
        
        # Store model parameters
        self.grid_width = grid_width
        self.grid_height = grid_height
        self.num_commuters = num_commuters
        self.simulation_steps = SIMULATION_STEPS
        self.income_weights = income_weights
        self.health_weights = health_weights
        self.payment_weights = payment_weights
        self.age_distribution = age_distribution
        self.disability_weights = disability_weights
        self.tech_access_weights = tech_access_weights
        self.sw = get_small_world_map(
            p_shortcut=SMALL_WORLD_P,
            seed=RANDOM_SEED,
            grid_width=GRID_WIDTH,
            grid_height=GRID_HEIGHT,
        )
        print("DECENTRALISED MAP FINGERPRINT:", self.sw.meta["fingerprint"])
        expected_fingerprint = os.getenv("EXPECTED_MAP_FINGERPRINT")
        if expected_fingerprint:
            assert self.sw.meta["fingerprint"] == expected_fingerprint, (
                f"Fingerprint mismatch: expected {expected_fingerprint}, got {self.sw.meta['fingerprint']}"
            )
        self.stations = self.sw.stations
        self.routes = self.sw.routes
        self.transfers = self.sw.transfers
        # Keep demand hubs aligned with the canonical map to avoid topology confounds.
        self.hubs = self._build_hubs_from_canonical_map()
        self.trip_plans = {}
        self._emitted_trip_ids = set()
        self._queued_trip_ids = set()
        self._pending_trip_queue = {}
        self.commuter_canonical_index = {}
        self.total_canonical_requests_emitted = 0
        self.last_canonical_requests_emitted = 0
        self.fixed_commuters_path = os.path.abspath(fixed_commuters_path) if fixed_commuters_path else None
        self.fixed_trip_requests_path = os.path.abspath(fixed_trip_requests_path) if fixed_trip_requests_path else None
        self.fixed_inputs_enabled = bool(self.fixed_commuters_path or self.fixed_trip_requests_path)
        self.fixed_commuters_payload = None
        self.fixed_trip_requests_payload = None
        self.fixed_commuters_fingerprint = None
        self.fixed_trip_requests_fingerprint = None
        self.trip_fingerprint_commuters_checked = min(
            self.num_commuters,
            int(os.getenv("TRIP_FINGERPRINT_COMMUTERS", "20")),
        )
        if self.fixed_commuters_path:
            self.fixed_commuters_payload = load_fixed_commuters(
                self.fixed_commuters_path,
                expected_count=self.num_commuters,
                grid_width=self.grid_width,
                grid_height=self.grid_height,
            )
            self.fixed_commuters_fingerprint = self.fixed_commuters_payload["fingerprint"]
            expected_commuter_fp = os.getenv("EXPECTED_FIXED_COMMUTERS_FINGERPRINT")
            if expected_commuter_fp:
                assert self.fixed_commuters_fingerprint == expected_commuter_fp, (
                    f"Fixed commuter fingerprint mismatch: expected {expected_commuter_fp}, "
                    f"got {self.fixed_commuters_fingerprint}"
                )
        expected_trip_commuters = (
            {
                spec.canonical_commuter_id
                for spec in self.fixed_commuters_payload["commuters"]
            }
            if self.fixed_commuters_payload
            else set(range(self.num_commuters))
        )
        if self.fixed_trip_requests_path:
            self.fixed_trip_requests_payload = load_fixed_trip_requests(
                self.fixed_trip_requests_path,
                expected_commuter_ids=expected_trip_commuters,
                grid_width=self.grid_width,
                grid_height=self.grid_height,
                simulation_steps=self.simulation_steps,
            )
            self.fixed_trip_requests_fingerprint = self.fixed_trip_requests_payload["fingerprint"]
            self.trip_fingerprint_commuters_checked = len(expected_trip_commuters)
            trip_fp = self.fixed_trip_requests_fingerprint
            print("DECENTRALISED FIXED TRIP FINGERPRINT:", trip_fp)
            expected_trip_fp = os.getenv("EXPECTED_FIXED_TRIP_REQUESTS_FINGERPRINT") or os.getenv("EXPECTED_TRIP_FINGERPRINT")
            if expected_trip_fp:
                assert trip_fp == expected_trip_fp, (
                    f"Trip fingerprint mismatch: expected {expected_trip_fp}, got {trip_fp}"
                )
        else:
            trip_fp = trip_stream_fingerprint(
                base_seed=RANDOM_SEED,
                grid_w=self.grid_width,
                grid_h=self.grid_height,
                hubs=self.hubs,
                commuters=self.trip_fingerprint_commuters_checked,
                day_index=0,
            )
            print("DECENTRALISED TRIP STREAM FINGERPRINT:", trip_fp)
            expected_trip_fp = os.getenv("EXPECTED_TRIP_FINGERPRINT")
            if expected_trip_fp:
                assert trip_fp == expected_trip_fp, (
                    f"Trip fingerprint mismatch: expected {expected_trip_fp}, got {trip_fp}"
                )
        self.trip_stream_fingerprint = trip_fp
        self.trace_targets = self._load_trace_targets()
        self.trace_output_path = os.getenv("TRACE_OUTPUT_JSONL")
        self.traced_canonical_trip_ids = set()
        
        # Add these to the model's __init__ method after other initialization
        self.transaction_count = 0
        self.active_listings_count = 0
        self.completed_trips_count = 0
        # High-level counters used by run loop for progress display
        self.total_requests = 0
        self.total_matches = 0
        self.total_completed = 0
        # Detailed booking log for downstream visualization
        self.booking_logs = []
        self.detailed_logs = []
        
        # Performance tracking
        self.execution_times = {
            'commuter_decisions': [],
            'provider_offers': [],
            'marketplace_update': [],
            'blockchain_operations': [],
        }
        
        # Initialize blockchain interface
        skip_chain = os.getenv("SKIP_CHAIN_PROCESSING", "").lower() in ("1", "true", "yes")
        # When skipping chain, keep async_mode False so queued tx aren't flushed in background
        self.blockchain_interface = BlockchainInterface(
            blockchain_config,
            async_mode=not skip_chain
        )
        self.blockchain_interface.model = self 

        # Initialize NFT marketplace with specified type (order_book, or hybrid)
        self.marketplace = NFTMarketplace(self, self.blockchain_interface, market_type)
        # Peak hours (ticks in a 144-step day)
        self.peak_hours = [(42, 54), (102, 114)]
        
        
        # Initialize provider agents
        self.providers = {}
        self._create_provider_agents(
            uber_like1_capacity, uber_like1_price, 
            uber_like2_capacity, uber_like2_price,
            bike_share1_capacity, bike_share1_price, 
            bike_share2_capacity, bike_share2_price
        )

        # Optional: public transport providers broadcasting scheduled offers
        self.public_transport_providers = []
        self._create_public_transport_providers()
        self._publish_initial_public_transport_schedules()
        # v8 parity_audit Arm B3 (Route C): SystemOperator canonical PT fallback.
        # See Rep model for docstring.
        if os.environ.get("V8_D_CANONICAL_PT_FALLBACK", "0") == "1":
            self._publish_canonical_pt_shadow_offers()
        
        # Initialize commuter agents
        self.commuters = {}
        self._create_commuter_agents()
        self._build_canonical_trip_plans()

        # Initialize speculators (ticket scalpers) to induce secondary market pressure
        self.speculators = []
        if self.enable_speculators:
            for i in range(5):
                speculator = SpeculatorAgent(5000 + i, self, self.blockchain_interface)
                self.schedule.add(speculator)
                self.speculators.append(speculator)
        else:
            self.logger.info("Speculators disabled (matching-only mode).")
        
        # Set up data collection
        self.datacollector = DataCollector(
            model_reporters={
                "Active Commuters": lambda m: self.count_active_commuters(),
                "Active Providers": lambda m: self.count_active_providers(),
                "Total Transactions": lambda m: len(self.marketplace.transaction_history),
                "Active NFT Listings": lambda m: sum(1 for listing in self.marketplace.listings.values() if listing['status'] == 'active'),
                "Average NFT Price": lambda m: self.calculate_average_nft_price(),
                "Completed Trips": lambda m: self.count_completed_trips(),
                "Execution Time": lambda m: self.get_average_execution_time()
            },
            agent_reporters={
                "Location": lambda a: a.location if hasattr(a, 'location') else None,
                "Current Mode": lambda a: a.current_mode if hasattr(a, 'current_mode') else None
            }
        )
        
        # Batch processing configuration
        self.batch_size = 10  # Process up to 10 requests/transactions in batch
        self.process_blockchain_interval = 5  # Process blockchain every 5 ticks
        
        # Pending operations tracking
        self.pending_requests = []
        self.pending_offers = []
        self.pending_transactions = []
        
        # Popular routes tracking (for AMM)
        self.route_transactions = {}  # Route key -> transaction count
        self.popular_routes = set()   # Set of popular route keys

        # Speculator action log (for secondary market evidence)
        self.speculator_log = []
        
        self.logger.info("DecentralizedMaaSModel initialized with %d commuters and %d providers",
                       len(self.commuters), len(self.providers))

    def _load_trace_targets(self):
        raw = os.getenv("TRACE_CANONICAL_TRIPS", "").strip()
        if not raw:
            return set()
        return {item.strip() for item in raw.split(",") if item.strip()}

    def _find_segment_index(self, mode, route_id, from_station, to_station):
        seq = self.sw.routes.get(mode, {}).get(route_id, [])
        for i in range(len(seq) - 1):
            if seq[i] == from_station and seq[i + 1] == to_station:
                return i
            if seq[i] == to_station and seq[i + 1] == from_station:
                return i
        return None

    def _pt_signature_from_shared_legs(self, legs):
        signature = []
        for leg in legs:
            if leg.get("type") == "transfer":
                signature.append(("XFER", None, leg.get("from"), leg.get("to")))
                continue
            mode = leg.get("mode")
            route_id = leg.get("route_id")
            if mode in ("bus", "train") and route_id:
                seg_idx = self._find_segment_index(mode, route_id, leg.get("from"), leg.get("to"))
                signature.append((route_id, seg_idx, leg.get("from"), leg.get("to")))
        return signature

    def _pt_signature_from_bundle_segments(self, segments):
        signature = []
        for seg in segments or []:
            mode = seg.get("mode")
            if mode not in ("bus", "train"):
                continue
            route_id = seg.get("route_id")
            from_station = seg.get("origin_station")
            to_station = seg.get("destination_station")
            seg_idx = seg.get("segment_index")
            if seg_idx is None and route_id and from_station and to_station:
                seg_idx = self._find_segment_index(mode, route_id, from_station, to_station)
            signature.append((route_id, seg_idx, from_station, to_station))
        return signature

    def _emit_trace_record(self, record):
        payload = json.dumps(record, sort_keys=True)
        print(f"[TRACE][DECENTRALISED] {payload}")
        if self.trace_output_path:
            try:
                with open(self.trace_output_path, "a", encoding="utf-8") as fh:
                    fh.write(payload + "\n")
            except Exception as exc:
                self.logger.warning(f"Failed to write TRACE_OUTPUT_JSONL: {exc}")

    def _trace_request_decision(
        self,
        request,
        commuter_id,
        chosen_mode,
        chosen_total_time,
        chosen_total_cost,
        bundle=None,
        pt_signature_source=None,
    ):
        canonical_trip_id = request.get("canonical_trip_id")
        if not canonical_trip_id:
            return
        if self.trace_targets and canonical_trip_id not in self.trace_targets:
            return
        if canonical_trip_id in self.traced_canonical_trip_ids:
            return

        shared = pt_route_time_between_points(
            origin_xy=tuple(request["origin"]),
            dest_xy=tuple(request["destination"]),
            stations=self.stations,
            routes=self.routes,
            transfers=self.transfers,
            in_vehicle_per_hop=PT_IN_VEHICLE_PER_HOP,
        )
        shared_signature = self._pt_signature_from_shared_legs(shared.legs)
        bundle_segments = (bundle or {}).get("segments", [])
        pt_bundle_segments = [seg for seg in bundle_segments if seg.get("mode") in ("train", "bus")]
        bundle_signature = self._pt_signature_from_bundle_segments(bundle_segments)
        signature_source = pt_signature_source or (bundle or {}).get("pt_signature_source")
        if signature_source is None and bundle_signature:
            signature_source = "offer_payload"
        if signature_source is None:
            signature_source = "none"

        record = {
            "event_type": "TRIP_EXECUTION_START",
            "system": "decentralised",
            "seed": int(self.run_seed),
            "step": int(self.current_step),
            "commuter_id": int(commuter_id),
            "canonical_trip_id": canonical_trip_id,
            "request_id": str(request.get("request_id")),
            "origin": request.get("origin"),
            "destination": request.get("destination"),
            "depart_step": int(request.get("start_time", -1)),
            "chosen_option_mode": chosen_mode,
            "chosen_total_time": chosen_total_time,
            "chosen_total_cost": chosen_total_cost,
            "shared_pt_total_time": shared.total_time,
            "shared_pt_signature": shared_signature,
            "chosen_pt_legs": pt_bundle_segments,
            "chosen_pt_signature": bundle_signature,
            "pt_signature_source": signature_source,
            "pt_signature_match": bundle_signature == shared_signature if bundle_signature else None,
            "bundle_wait_time": (bundle or {}).get("wait_time"),
            "bundle_num_segments": len((bundle or {}).get("segments", [])),
        }
        self._emit_trace_record(record)
        self.traced_canonical_trip_ids.add(canonical_trip_id)

    def _create_provider_agents(self, uber_like1_capacity, uber_like1_price, 
                           uber_like2_capacity, uber_like2_price,
                           bike_share1_capacity, bike_share1_price, 
                           bike_share2_capacity, bike_share2_price):
        """
        Create provider agents with parameters, including both individual providers
        and fractionally-owned fleet providers (like community public transport).
        
        This method creates multiple types of mobility providers, each with their own
        characteristics, service areas, and ownership structures.
        """
        if self.use_v2_supply_config:
            self._create_v2_provider_agents()
            return

        # Car service providers (individual drivers or small companies)
        self._add_provider_agent("UberLike1", "car", uber_like1_price, uber_like1_capacity, 
                            service_area=25, provider_type="individual")
        self._add_provider_agent("UberLike2", "car", uber_like2_price, uber_like2_capacity, 
                            service_area=20, provider_type="individual")
        
        # Bike service providers — bike_speed=1.4 matches centralised bike speed for fair comparison
        bs1 = self._add_provider_agent("BikeShare1", "bike", bike_share1_price, bike_share1_capacity,
                            service_area=15, provider_type="individual")
        if bs1 is not None:
            bs1.bike_speed = 1.4
        bs2 = self._add_provider_agent("BikeShare2", "bike", bike_share2_price, bike_share2_capacity,
                            service_area=15, provider_type="individual")
        if bs2 is not None:
            bs2.bike_speed = 1.4
        
        # City train consortium operated as a DAO
        if hasattr(self, 'train_capacity') and hasattr(self, 'train_price'):
            # Create token holder structure for train DAO
            train_token_holders = {
                # Represents stakeholders in the train service DAO
                2001: 25,  # Major community fund with 25% stake
                2002: 20,  # City development group with 20% stake
                2003: 15,  # Transit advocacy organization with 15%
                # More distributed stakeholders
                **{2004+i: 2 for i in range(20)}  # 20 token holders with 2% each
            }
            
            self._add_provider_agent("TrainDAO", "train", self.train_price, self.train_capacity,
                                service_area=60, provider_type="fractional_fleet",
                                fleet_token_holders=train_token_holders)
        
        # Check if additional provider types are defined in parameters
        if hasattr(self, 'additional_providers'):
            for provider_info in self.additional_providers:
                self._add_provider_agent(
                    provider_info['name'],
                    provider_info['mode_type'],
                    provider_info['base_price'],
                    provider_info['capacity'],
                    service_area=provider_info.get('service_area', 40),
                    provider_type=provider_info.get('provider_type', 'individual'),
                    fleet_token_holders=provider_info.get('token_holders', None)
                )

        # Fill up to target provider count with random providers
        if getattr(self, "disable_random_provider_topup", False):
            self.logger.info(
                "Skipping random provider top-up for parity run; keeping named shared providers only."
            )
            return

        current_count = len(self.providers)
        needed = getattr(self, "num_providers", current_count) - current_count
        if needed > 0:
            self.logger.info(f"Initializing {needed} additional random providers to reach target {self.num_providers}...")
            for i in range(needed):
                # Increase bike share (30%) and make bikes cheaper; cars more expensive
                if random.random() < 0.7:  # 70% chance car
                    name = f"RandomUber_{i}"
                    mode = "car"
                    base_price = random.uniform(1.2, 3.0)  # higher car base
                    capacity = random.randint(3, 5)
                    area = 30
                else:
                    name = f"RandomBike_{i}"
                    mode = "bike"
                    base_price = random.uniform(0.1, 0.4)  # cheaper bikes
                    capacity = random.randint(6, 10)      # slightly more bikes
                    area = 15
                self._add_provider_agent(
                    company_name=name,
                    mode_type=mode,
                    base_price=base_price,
                    capacity=capacity,
                    service_area=area,
                    provider_type="individual"
                )

    def _zone_center(self, zone_id):
        centers = (self.v2_supply_definition or {}).get("zone_centers", {})
        center = centers.get(zone_id)
        if center is None:
            return [self.grid_width // 2, self.grid_height // 2]
        return [int(center[0]), int(center[1])]

    def _create_v2_provider_agents(self):
        ondemand_defs = (self.v2_supply_definition or {}).get("ondemand_operators", [])
        self.logger.info("Creating V2 Step 1 on-demand providers from deterministic supply config.")
        for profile in ondemand_defs:
            service_center = list(profile.get("service_center") or self._zone_center(profile["preferred_zones"][0]))
            primary_mode = profile["mode_set"][0]
            provider_id = len(self.providers) + 1
            provider = DecentralizedProvider(
                unique_id=provider_id,
                model=self,
                pos=service_center,
                company_name=profile["operator_id"],
                operator_id=profile["operator_id"],
                operator_type=profile["operator_type"],
                mode_type=primary_mode,
                mode_set=profile["mode_set"],
                capacity=profile["fleet_capacity"],
                base_price=profile["base_price"],
                distance_rate=profile["distance_rate"],
                speed=profile["speed"],
                bike_speed=profile.get("bike_speed"),
                reliability=profile["reliability"],
                quality_score=profile.get("quality_score"),
                coverage_type=profile.get("coverage_type"),
                preferred_zones=profile.get("preferred_zones"),
                out_of_preference_penalty_multiplier=profile.get("out_of_preference_penalty_multiplier", 1.0),
                blockchain_interface=self.blockchain_interface,
            )
            provider.service_center = service_center
            _base_area = float(profile.get("service_area", max(self.grid_width, self.grid_height)))
            # v8 parity_audit Arm B4: labelled service-area scaling.
            try:
                _b4_mult = float(os.environ.get("V8_D_SERVICE_AREA_MULT", "1.0"))
            except ValueError:
                _b4_mult = 1.0
            provider.service_area = _base_area * _b4_mult

            self.schedule.add(provider)
            self.providers[provider_id] = provider
            self.grid.place_agent(provider, tuple(service_center))

            success, address = self.blockchain_interface.register_provider(provider)
            if not success:
                self.logger.error(f"Failed to register V2 provider {provider.operator_id}")
            else:
                self.logger.info(f"Registered V2 provider {provider.operator_id} at {address}")

    def _build_hubs_from_canonical_map(self):
        """
        Derive directional demand hubs from canonical train stations.
        This keeps decentralized demand geography tied to the same world as PT routing.
        """
        return build_subcentre_hubs(
            self.stations,
            grid_width=self.grid_width,
            grid_height=self.grid_height,
        )

    def _create_public_transport_providers(self):
        """
        Create PT providers directly from canonical route adjacency.
        One provider per canonical route to preserve supply parity.
        """
        if self.use_v2_supply_config:
            self._create_v2_public_transport_providers()
            return

        station_lookup = {}
        for mode in ("train", "bus"):
            for station_id, xy in self.stations.get(mode, {}).items():
                station_lookup[station_id] = xy

        created = 0
        for mode in ("train", "bus"):
            for route_id, station_seq in self.routes.get(mode, {}).items():
                valid_station_ids = [sid for sid in station_seq if sid in self.stations.get(mode, {})]
                if len(valid_station_ids) < 2:
                    self.logger.warning(
                        f"Skipping canonical PT route {route_id} ({mode}) due to insufficient valid stations"
                    )
                    continue

                route_coords = [self.stations[mode][sid] for sid in valid_station_ids]
                schedule_interval = 4 if mode == "bus" else 10
                capacity_per_trip = 8 if mode == "bus" else 90
                base_fare = 1.2 if mode == "bus" else 5.0

                pt = PublicTransportProvider(
                    unique_id=9000 + created,
                    model=self,
                    pos=route_coords[0],
                    route_stations=route_coords,
                    route_station_ids=valid_station_ids,
                    route_id=route_id,
                    station_lookup=station_lookup,
                    schedule_interval=schedule_interval,
                    capacity_per_trip=capacity_per_trip,
                    base_fare=base_fare,
                    company_name=f"{mode.upper()}_{route_id}",
                    blockchain_interface=self.blockchain_interface,
                    mode_type=mode,
                    speed_modifier=1.0,
                    in_vehicle_per_hop=PT_IN_VEHICLE_PER_HOP,
                )
                self.schedule.add(pt)
                self.public_transport_providers.append(pt)
                created += 1

        self.logger.info(
            "Added %d canonical PT providers derived from sw.routes",
            len(self.public_transport_providers),
        )

    def _create_v2_public_transport_providers(self):
        station_lookup = {}
        for mode in ("train", "bus"):
            for station_id, xy in self.stations.get(mode, {}).items():
                station_lookup[station_id] = xy

        created = 0
        rail_def = (self.v2_supply_definition or {}).get("rail_operator", {})
        for corridor in rail_def.get("corridors", []):
            valid_station_ids = [sid for sid in corridor.get("station_ids", []) if sid in self.stations.get("train", {})]
            if len(valid_station_ids) < 2:
                self.logger.warning("Skipping V2 rail corridor %s due to insufficient valid stations", corridor.get("corridor_id"))
                continue
            route_coords = [self.stations["train"][sid] for sid in valid_station_ids]
            pt = PublicTransportProvider(
                unique_id=9000 + created,
                model=self,
                pos=route_coords[0],
                route_stations=route_coords,
                route_station_ids=valid_station_ids,
                route_id=corridor.get("route_id", corridor["corridor_id"]),
                station_lookup=station_lookup,
                schedule_interval=corridor["schedule_interval"],
                capacity_per_trip=corridor["capacity_per_departure"],
                base_fare=corridor["base_fare"],
                company_name=f"{rail_def['operator_id']}__{corridor['corridor_id']}",
                operator_id=rail_def["operator_id"],
                operator_type="rail",
                corridor_id=corridor["corridor_id"],
                service_scope="corridor",
                corridor_ids=[corridor["corridor_id"]],
                distance_rate=corridor["distance_rate"],
                reliability=corridor["reliability"],
                quality_score=88,
                blockchain_interface=self.blockchain_interface,
                mode_type="train",
                speed_modifier=1.0,
                in_vehicle_per_hop=corridor.get("in_vehicle_per_hop", PT_IN_VEHICLE_PER_HOP),
            )
            self.schedule.add(pt)
            self.public_transport_providers.append(pt)
            created += 1

        for bus_profile in (self.v2_supply_definition or {}).get("bus_operators", []):
            for route_def in bus_profile.get("route_definitions", []):
                valid_station_ids = [
                    sid for sid in route_def.get("station_ids", [])
                    if sid in self.stations.get("bus", {})
                ]
                if len(valid_station_ids) < 2:
                    self.logger.warning(
                        "Skipping V2 bus route %s for operator %s due to insufficient valid stations",
                        route_def.get("route_id"),
                        bus_profile.get("operator_id"),
                    )
                    continue
                route_coords = [self.stations["bus"][sid] for sid in valid_station_ids]
                pt = PublicTransportProvider(
                    unique_id=9000 + created,
                    model=self,
                    pos=route_coords[0],
                    route_stations=route_coords,
                    route_station_ids=valid_station_ids,
                    route_id=route_def["route_id"],
                    station_lookup=station_lookup,
                    schedule_interval=bus_profile["schedule_interval"],
                    capacity_per_trip=bus_profile["capacity_per_departure"],
                    base_fare=bus_profile["base_fare"],
                    company_name=f"{bus_profile['operator_id']}__{route_def['route_id']}",
                    operator_id=bus_profile["operator_id"],
                    operator_type="bus",
                    zone_id=bus_profile["zone_id"],
                    zone_bounds=bus_profile["zone_bounds"],
                    service_scope=route_def.get("service_scope", "local"),
                    local_route_ids=bus_profile.get("local_route_ids"),
                    feeder_route_ids=bus_profile.get("feeder_route_ids"),
                    distance_rate=bus_profile["distance_rate"],
                    reliability=bus_profile["reliability"],
                    quality_score=82,
                    blockchain_interface=self.blockchain_interface,
                    mode_type="bus",
                    speed_modifier=1.0,
                    in_vehicle_per_hop=bus_profile.get("in_vehicle_per_hop", PT_IN_VEHICLE_PER_HOP),
                )
                self.schedule.add(pt)
                self.public_transport_providers.append(pt)
                created += 1

        self.logger.info(
            "Added %d V2 Step 1 PT provider instances from deterministic supply config",
            len(self.public_transport_providers),
        )

    def _expected_pt_adjacency_edge_count(self):
        if getattr(self, "public_transport_providers", None):
            return 2 * sum(
                max(0, len(getattr(pt, "route_station_ids", []) or []) - 1)
                for pt in self.public_transport_providers
            )
        return 0

    def _current_pt_offer_count(self):
        pt_provider_ids = {pt.unique_id for pt in self.public_transport_providers}
        if not pt_provider_ids:
            return 0
        with self.blockchain_interface.marketplace_db_lock:
            offers = self.blockchain_interface.marketplace_db.get("offers", {})
            return sum(
                1
                for offer in offers.values()
                if offer.get("provider_id") in pt_provider_ids and offer.get("type") == "segment"
            )

    def _publish_canonical_pt_shadow_offers(self):
        """
        v8 parity_audit Arm B3 (Route C): mutate existing PT providers to have
        infinite capacity and publish the entire simulation horizon at 1-tick
        intervals. See Rep model docstring.
        """
        if not getattr(self, "public_transport_providers", None):
            return
        horizon = int(getattr(self, "simulation_steps", SIMULATION_STEPS))
        for pt in self.public_transport_providers:
            try:
                pt.capacity_per_trip = 999999
                pt.schedule_interval = 1
                pt.publish_future_schedules(horizon=horizon)
            except Exception as e:
                self.logger.warning(f"Route C shadow publish failed for PT provider {pt.unique_id}: {e}")
        self.logger.info(
            f"Route C: Mutated {len(self.public_transport_providers)} PT providers to canonical-shadow "
            f"(capacity=inf, interval=1, published horizon={horizon})"
        )

    def _publish_initial_public_transport_schedules(self, horizon=1):
        """
        Immediately publish a horizon of public transport schedules at initialization
        so the router has segments from the first step.
        """
        if not getattr(self, "public_transport_providers", None):
            return
        for pt in self.public_transport_providers:
            try:
                pt.publish_future_schedules(horizon=horizon)
                self.logger.info(f"Bootstrapped PT schedules for provider {pt.unique_id} (horizon={horizon})")
            except Exception as e:
                self.logger.warning(f"Failed to bootstrap PT schedules for provider {pt.unique_id}: {e}")

        expected = self._expected_pt_adjacency_edge_count()
        actual = self._current_pt_offer_count()
        self.logger.info("PT adjacency offers: expected=%d, actual=%d", expected, actual)
        assert actual == expected, f"PT offer count mismatch: expected {expected}, got {actual}"

    def export_provider_inventory(self, json_path=None, csv_path=None):
        inventory = {}

        for provider in list(self.providers.values()) + list(getattr(self, "public_transport_providers", [])):
            operator_id = getattr(provider, "operator_id", getattr(provider, "company_name", str(provider.unique_id)))
            record = inventory.setdefault(
                operator_id,
                {
                    "operator_id": operator_id,
                    "operator_type": getattr(provider, "operator_type", "unknown"),
                    "company_names": set(),
                    "mode": getattr(provider, "mode_type", None),
                    "mode_set": set(getattr(provider, "mode_set", [getattr(provider, "mode_type", None)])),
                    "instance_count": 0,
                    "capacity": None,
                    "base_price": getattr(provider, "base_price", None),
                    "distance_rate": getattr(provider, "distance_rate", None),
                    "speed": getattr(provider, "speed", None),
                    "bike_speed": getattr(provider, "bike_speed", None),
                    "reliability_profile": getattr(provider, "reliability_profile", None),
                    "runtime_reliability_score": getattr(provider, "reliability", None),
                    "service_area": getattr(provider, "service_area", None),
                    "coverage_type": getattr(provider, "coverage_type", None),
                    "preferred_zones": set(getattr(provider, "preferred_zones", [])),
                    "zone_id": getattr(provider, "zone_id", None),
                    "zone_bounds": getattr(provider, "zone_bounds", None),
                    "corridor_ids": set(getattr(provider, "corridor_ids", [])),
                    "local_route_ids": set(getattr(provider, "local_route_ids", [])),
                    "feeder_route_ids": set(getattr(provider, "feeder_route_ids", [])),
                    "route_ids": set(),
                },
            )
            record["instance_count"] += 1
            record["company_names"].add(getattr(provider, "company_name", operator_id))
            record["mode_set"].update(getattr(provider, "mode_set", [getattr(provider, "mode_type", None)]))
            record["preferred_zones"].update(getattr(provider, "preferred_zones", []))
            record["corridor_ids"].update(getattr(provider, "corridor_ids", []))
            record["local_route_ids"].update(getattr(provider, "local_route_ids", []))
            record["feeder_route_ids"].update(getattr(provider, "feeder_route_ids", []))
            route_id = getattr(provider, "route_id", None)
            if route_id:
                record["route_ids"].add(route_id)
            capacity = getattr(provider, "capacity", None)
            if record["capacity"] is None:
                record["capacity"] = capacity

        records = []
        for operator_id in sorted(inventory.keys()):
            row = inventory[operator_id]
            row["company_names"] = sorted(row["company_names"])
            row["mode_set"] = sorted(m for m in row["mode_set"] if m is not None)
            row["preferred_zones"] = sorted(row["preferred_zones"])
            row["corridor_ids"] = sorted(row["corridor_ids"])
            row["local_route_ids"] = sorted(row["local_route_ids"])
            row["feeder_route_ids"] = sorted(row["feeder_route_ids"])
            row["route_ids"] = sorted(row["route_ids"])
            records.append(row)

        if json_path:
            os.makedirs(os.path.dirname(json_path), exist_ok=True)
            with open(json_path, "w", encoding="utf-8") as fh:
                json.dump(records, fh, indent=2, sort_keys=True)

        if csv_path:
            import csv

            os.makedirs(os.path.dirname(csv_path), exist_ok=True)
            fieldnames = [
                "operator_id",
                "operator_type",
                "company_names",
                "mode",
                "mode_set",
                "instance_count",
                "route_ids",
                "capacity",
                "base_price",
                "distance_rate",
                "speed",
                "bike_speed",
                "reliability_profile",
                "runtime_reliability_score",
                "service_area",
                "coverage_type",
                "preferred_zones",
                "zone_id",
                "zone_bounds",
                "corridor_ids",
                "local_route_ids",
                "feeder_route_ids",
            ]
            with open(csv_path, "w", encoding="utf-8", newline="") as fh:
                writer = csv.DictWriter(fh, fieldnames=fieldnames)
                writer.writeheader()
                for row in records:
                    writer.writerow(
                        {
                            key: json.dumps(row[key], sort_keys=True)
                            if isinstance(row[key], (list, dict))
                            else row[key]
                            for key in fieldnames
                        }
                    )

        return records

    def evaluate_pt_route_time(self, origin_xy, destination_xy):
        result = pt_route_time_between_points(
            origin_xy=origin_xy,
            dest_xy=destination_xy,
            stations=self.stations,
            routes=self.routes,
            transfers=self.transfers,
            in_vehicle_per_hop=PT_IN_VEHICLE_PER_HOP,
        )
        return result.total_time, result

    def _add_provider_agent(self, company_name, mode_type, base_price, capacity, 
                       service_area=40, provider_type="individual", 
                       fleet_token_holders=None):
        """
        Add a provider agent to the model with full support for decentralized ownership.
        
        Args:
            company_name: Name of the provider/company
            mode_type: Transport mode ('car', 'bike', 'bus', 'train', etc.)
            base_price: Base price per unit distance
            capacity: Maximum service capacity
            service_area: Service coverage radius
            provider_type: Either "individual" or "fractional_fleet"
            fleet_token_holders: For fractional fleets, a dict of token holder IDs and stakes
        
        Returns:
            The created provider agent
        """
        provider_id = len(self.providers) + 1
        
        # Generate a service center location appropriate to the provider type
        if provider_type == "fractional_fleet" and mode_type in ["bus", "train"]:
            # Public transport typically has more central service centers
            center_x = self.grid_width // 2
            center_y = self.grid_height // 2
            # Place near center with some randomness
            service_center = [
                int(center_x + random.uniform(-0.2, 0.2) * self.grid_width),
                int(center_y + random.uniform(-0.2, 0.2) * self.grid_height)
            ]
        else:
            # Individual providers are more dispersed
            service_center = [
                random.randint(0, self.grid_width - 1),
                random.randint(0, self.grid_height - 1)
            ]
        
        # Create provider agent with appropriate parameters
        provider = DecentralizedProvider(
            unique_id=provider_id,
            model=self,
            pos=service_center,
            company_name=company_name,
            mode_type=mode_type,
            capacity=capacity,
            base_price=base_price,
            blockchain_interface=self.blockchain_interface
        )
        
        # Set service center
        provider.service_center = service_center
        provider.service_area = service_area
        
        # For fractional fleets like public transport, create predefined routes
        if provider_type == "fractional_fleet" and mode_type in ["bus", "train"]:
            # Create route corridor for this public transport service
            if not hasattr(provider, 'location_preferences'):
                provider.location_preferences = {}
                
            # Generate endpoints for the route corridor
            if mode_type == "train":
                # Trains typically connect distant points
                route_length = min(self.grid_width, self.grid_height) * 0.7
                angle = random.uniform(0, 2 * math.pi)
                
                # Generate endpoints from center outward
                center = [self.grid_width // 2, self.grid_height // 2]
                start = [
                    int(center[0] + route_length * 0.5 * math.cos(angle)),
                    int(center[1] + route_length * 0.5 * math.sin(angle))
                ]
                end = [
                    int(center[0] - route_length * 0.5 * math.cos(angle)),
                    int(center[1] - route_length * 0.5 * math.sin(angle))
                ]
                
                # Keep within grid bounds
                start[0] = max(0, min(start[0], self.grid_width - 1))
                start[1] = max(0, min(start[1], self.grid_height - 1))
                end[0] = max(0, min(end[0], self.grid_width - 1))
                end[1] = max(0, min(end[1], self.grid_height - 1))
                
                # Set route corridor with narrow width (trains have fixed routes)
                provider.location_preferences['route_corridor'] = {
                    'start': start,
                    'end': end,
                    'width': service_area * 0.3  # Narrow corridor for trains
                }
            elif mode_type == "bus":
                # Buses typically serve more areas with wider corridors
                # Create multiple corridors for bus routes
                corridors = []
                
                # Create 2-3 corridors for this bus service
                for _ in range(random.randint(2, 3)):
                    angle = random.uniform(0, 2 * math.pi)
                    route_length = min(self.grid_width, self.grid_height) * 0.5
                    
                    center = [self.grid_width // 2, self.grid_height // 2]
                    start = [
                        int(center[0] + route_length * 0.5 * math.cos(angle)),
                        int(center[1] + route_length * 0.5 * math.sin(angle))
                    ]
                    end = [
                        int(center[0] - route_length * 0.5 * math.cos(angle)),
                        int(center[1] - route_length * 0.5 * math.sin(angle))
                    ]
                    
                    # Keep within grid bounds
                    start[0] = max(0, min(start[0], self.grid_width - 1))
                    start[1] = max(0, min(start[1], self.grid_height - 1))
                    end[0] = max(0, min(end[0], self.grid_width - 1))
                    end[1] = max(0, min(end[1], self.grid_height - 1))
                    
                    corridors.append({
                        'start': start,
                        'end': end,
                        'width': service_area * 0.6  # Wider corridor for buses
                    })
                
                # Set primary corridor
                provider.location_preferences['route_corridor'] = corridors[0]
                # Store additional corridors
                provider.location_preferences['additional_corridors'] = corridors[1:]
        
        # Add provider to scheduler
        self.schedule.add(provider)
        
        # Store provider in our records
        self.providers[provider_id] = provider
        
        # Generate a random location in the grid for visualization
        x = random.randrange(self.grid_width)
        y = random.randrange(self.grid_height)
        self.grid.place_agent(provider, (x, y))
        # CRITICAL: Register provider on blockchain
        success, address = self.blockchain_interface.register_provider(provider)
        if not success:
            self.logger.error(f"Failed to register provider {provider_id}")
        else:
            self.logger.info(f"Successfully registered provider {provider_id} at {address}")
        
        # Log different messages based on provider type
        if provider_type == "individual":
            self.logger.info(f"Added individual provider {company_name} with mode {mode_type}, "
                        f"base price {base_price}, capacity {capacity}")
        else:
            stakeholder_count = len(fleet_token_holders) if fleet_token_holders else 0
            self.logger.info(f"Added fractional fleet {company_name} with mode {mode_type}, "
                        f"base price {base_price}, capacity {capacity}, "
                        f"stakeholders: {stakeholder_count}")
        
        return provider

    def _create_commuter_agents(self):
        """Create commuter agents based on population parameters"""
        provider_count = len(getattr(self, "providers", {}))
        commuter_specs = None
        if self.fixed_commuters_payload:
            commuter_specs = self.fixed_commuters_payload["commuters"]
        for i in range(self.num_commuters):
            # Offset commuter IDs so they don't collide with provider IDs in account mapping
            commuter_id = provider_count + i + 1
            if commuter_specs is not None:
                spec = commuter_specs[i]
                canonical_commuter_id = spec.canonical_commuter_id
                x, y = spec.initial_location
                income_level = spec.income_level
                health_status = spec.health_status
                payment_scheme = spec.payment_scheme
                age = spec.age
                has_disability = spec.has_disability
                tech_access = spec.tech_access
            else:
                canonical_commuter_id = i
                # Cluster commuters around hubs/CBD
                if random.random() < 0.8:
                    home_hub = random.choice(["NorthHub", "SouthHub", "EastHub", "WestHub"])
                else:
                    home_hub = "CBD"
                center = self.hubs[home_hub]
                x = int(random.gauss(center[0], 3))
                y = int(random.gauss(center[1], 3))
                x = max(0, min(x, self.grid_width - 1))
                y = max(0, min(y, self.grid_height - 1))

                income_levels = ['low', 'middle', 'high']
                income_level = random.choices(income_levels, self.income_weights)[0]

                health_statuses = ['good', 'poor']
                health_status = random.choices(health_statuses, self.health_weights)[0]

                payment_schemes = ['PAYG', 'subscription']
                payment_scheme = random.choices(payment_schemes, self.payment_weights)[0]

                age = self._generate_age_from_distribution()
                has_disability = random.choices([True, False], self.disability_weights)[0]
                tech_access = random.choices([True, False], self.tech_access_weights)[0]
            
            # Create commuter agent
            commuter = DecentralizedCommuter(
                commuter_id,
                self,
                (x, y),
                age,
                income_level,
                has_disability,
                tech_access,
                health_status,
                payment_scheme,
                self.blockchain_interface
            )
            
            # Add commuter to scheduler
            self.schedule.add(commuter)
            
            # Store commuter in our records
            self.commuters[commuter_id] = commuter
            self.commuter_canonical_index[commuter_id] = canonical_commuter_id
            
            # Place commuter on grid
            self.grid.place_agent(commuter, (x, y))

            # CRITICAL: Register commuter on blockchain
            success, address = self.blockchain_interface.register_commuter(commuter)
            if not success:
                self.logger.error(f"Failed to register commuter {commuter_id}")
            else:
                self.logger.info(f"Successfully registered commuter {commuter_id} at {address}")

    def _build_canonical_trip_plans(self):
        # Canonical trip IDs use stable commuter index (0..N-1), not internal agent IDs.
        if self.fixed_trip_requests_payload:
            grouped = group_trips_by_canonical_commuter(
                self.fixed_trip_requests_payload["trip_requests"]
            )
            self.trip_plans = {}
            self._queued_trip_ids = set()
            self._pending_trip_queue = {}
            for commuter_id in self.commuters:
                canonical_idx = self.commuter_canonical_index.get(commuter_id, 0)
                self.trip_plans[int(commuter_id)] = list(grouped.get(canonical_idx, []))
                self._pending_trip_queue[int(commuter_id)] = []
            return
        days = max(1, (self.simulation_steps + 143) // 144)
        self.trip_plans = {}
        self._queued_trip_ids = set()
        self._pending_trip_queue = {}
        for commuter_id, commuter in self.commuters.items():
            canonical_idx = self.commuter_canonical_index.get(commuter_id, 0)
            plans = []
            for day_idx in range(days):
                t0, t1 = generate_two_trip_day(
                    base_seed=RANDOM_SEED,
                    commuter_id=canonical_idx,
                    grid_w=self.grid_width,
                    grid_h=self.grid_height,
                    hubs=self.hubs,
                    day_index=day_idx,
                )
                plans.extend([t0, t1])
            self.trip_plans[int(commuter_id)] = plans
            self._pending_trip_queue[int(commuter_id)] = []

    def _canonical_request_id(self, canonical_idx, trip):
        # Keep request IDs numeric to preserve downstream offer_id arithmetic.
        return int(trip.depart_step * 100000 + canonical_idx * 10 + trip.trip_index)

    def _generate_age_from_distribution(self):
        """Generate age based on age distribution"""
        age_ranges = list(self.age_distribution.keys())
        weights = list(self.age_distribution.values())
        
        selected_range = random.choices(age_ranges, weights=weights)[0]
        
        return random.randint(selected_range[0], selected_range[1])

    def check_is_peak(self, time_value=None):
        """
        Check if current time is peak hour
        
        Args:
            time_value: Optional time value to check (defaults to current model time)
            
        Returns:
            Boolean indicating if time is peak hour
        """
        if time_value is None:
            time_value = self.current_step
            
        time_of_day = time_value % 144  # 144 ticks per day
        
        # Morning peak (6:30am-10am) or evening peak (3pm-7pm)
        if (36 <= time_of_day < 60) or (90 <= time_of_day < 114):
            return True
        return False

    def count_active_car_trips(self):
        """Count active car trips for BPR volume approximation."""
        count = 0
        # commuters is a dict mapping id->agent
        for commuter in getattr(self, 'commuters', {}).values():
            for trip in getattr(commuter, 'active_trips', {}).values():
                if trip.get('status') == 'in_progress' and trip.get('option', {}).get('mode') == 'car':
                    count += 1
        return count


    def count_active_commuters(self):
        return sum(
            1 for a in self.schedule.agents
            if getattr(a, 'is_commuter', False) and getattr(a, 'active_trips', {})
        )

    def calculate_bpr_time(self, origin, destination, free_flow_time):
        """
        BPR congestion model aligned with centralized model.
        T = T_free * (1 + alpha * (Volume/Capacity)^beta)

        Matches ABM_ETOP_framework agent_MaaS_03.py calculate_congested_travel_time
        """
        # Count active car trips
        current_volume = self.count_active_car_trips()

        # Add background traffic to match centralized
        background_traffic = getattr(
            self,
            'background_traffic_count',
            getattr(self, 'background_traffic_amount', BACKGROUND_TRAFFIC_AMOUNT),
        )
        total_volume = current_volume + background_traffic

        # Use a decentralised-specific effective capacity because this model
        # applies congestion to pooled citywide volume rather than per-segment volume.
        capacity = DECENTRALISED_CONGESTION_CAPACITY

        # BPR parameters aligned with centralized (changed from alpha=0.15, beta=4.0)
        alpha = CONGESTION_ALPHA  # 0.03
        beta = CONGESTION_BETA    # 1.5

        # Apply congestion at all times (not just peak)
        congestion_factor = 1 + alpha * math.pow((total_volume / max(capacity, 1)), beta)

        congested_time = free_flow_time * congestion_factor

        return congested_time

    def count_active_car_trips(self):
        """Count active car trips for BPR volume calculation."""
        count = 0
        for agent in self.schedule.agents:
            if hasattr(agent, 'is_commuter') and agent.is_commuter:
                if hasattr(agent, 'active_trips'):
                    for trip in agent.active_trips.values():
                        if (trip.get('status') == 'in_progress' and
                            trip.get('option', {}).get('mode') == 'car'):
                            count += 1
        return count

    def insert_background_traffic(self):
        """
        Insert background traffic to simulate ambient congestion.
        Matches centralized model's insert_time_varying_traffic.
        """
        current_step = self.current_step
        ticks_in_day = 144
        current_day_tick = current_step % ticks_in_day

        # Define traffic intensity based on time of day
        if 36 <= current_day_tick < 48:  # Early morning rush
            traffic_multiplier = 3.0
        elif 48 <= current_day_tick < 60:  # Late morning rush
            traffic_multiplier = 2.5
        elif 90 <= current_day_tick < 102:  # Early evening rush
            traffic_multiplier = 2.5
        elif 102 <= current_day_tick < 114:  # Late evening rush
            traffic_multiplier = 3.0
        elif (60 <= current_day_tick < 90) or (114 <= current_day_tick < 130):
            traffic_multiplier = 1.0
        else:  # Night/early morning
            traffic_multiplier = 0.3

        # Calculate traffic amount
        adjusted_traffic_amount = int(
            getattr(self, "background_traffic_amount", BACKGROUND_TRAFFIC_AMOUNT)
            * traffic_multiplier
        )

        # Store for BPR calculation
        self.background_traffic_count = adjusted_traffic_amount

        return adjusted_traffic_amount

    def get_demand_factor(self, time_value, mode_type):
        """
        Get demand multiplier for a given time and mode
        
        Args:
            time_value: Time value to check
            mode_type: Transport mode type
            
        Returns:
            Demand factor (multiplier)
        """
        time_of_day = time_value % 144  # 144 ticks per day
        
        # Base demand factors by time of day
        if 36 <= time_of_day < 60:  # Morning peak
            base_factor = 1.4
        elif 90 <= time_of_day < 114:  # Evening peak
            base_factor = 1.3
        elif 60 <= time_of_day < 90:  # Daytime
            base_factor = 1.0
        elif 114 <= time_of_day < 126:  # Evening
            base_factor = 0.9
        else:  # Night
            base_factor = 0.7
        
        # Mode-specific adjustments
        if mode_type == "car":
            if self.check_is_peak(time_value):
                return base_factor * 1.2  # Cars more in demand during peaks
            return base_factor
        elif mode_type == "bike":
            if 60 <= time_of_day < 114:  # Daytime and evening peak (good weather assumed)
                return base_factor * 1.1
            return base_factor * 0.8  # Less demand at night/early morning
        else:
            return base_factor

    def _compose_car_pt_bundle(self, request):
        """
        Compose a first-mile-car + PT + last-mile-walk bundle for a request.

        Returns bundle dict in the same shape as blockchain_interface.build_bundles
        entries, or None if no viable composition exists.

        Reserves capacity on the chosen ondemand car provider IMMEDIATELY. Caller
        must call release_car_pt_bundle_reservation(bundle) if the bundle ends
        up not being selected.
        """
        try:
            origin = tuple(request['origin'])
            destination = tuple(request['destination'])
            start_time = int(request['start_time'])

            # Cache the Sydney topology once.
            if not hasattr(self, '_composed_bundle_topology'):
                from topology import get_shared_topology_v2  # local import to avoid boot-time cost
                self._composed_bundle_topology = get_shared_topology_v2()
            topo = self._composed_bundle_topology
            all_stations = {**topo.stations['train'], **topo.stations['bus']}

            def _dist(a, b):
                return ((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2) ** 0.5

            # Nearest station to origin
            origin_station_id, origin_station_coord, origin_walk = None, None, float('inf')
            for sid, coord in all_stations.items():
                d = _dist(coord, origin)
                if d < origin_walk:
                    origin_walk, origin_station_id, origin_station_coord = d, sid, coord
            # Walkable origin -> no need for car first-mile
            if origin_walk < 5:
                return None
            # Car+PT combo useful only when origin far from station
            if origin_walk > 30:
                return None

            # Nearest station to destination
            dest_station_id, dest_station_coord, dest_walk = None, None, float('inf')
            for sid, coord in all_stations.items():
                d = _dist(coord, destination)
                if d < dest_walk:
                    dest_walk, dest_station_id, dest_station_coord = d, sid, coord
            if dest_walk > 15:
                return None
            if origin_station_id == dest_station_id:
                return None

            # Get real blockchain PT bundle between the two stations. This gives us
            # segments with 'offer_' prefixed IDs that can pass through mint_and_buy.
            try:
                pt_bundles = self.blockchain_interface.build_bundles(
                    origin=list(origin_station_coord),
                    destination=list(dest_station_coord),
                    start_time=start_time,
                    max_transfers=10,
                    time_tolerance=self.bundle_time_tolerance,
                    walk_radius=self.bundle_walk_radius,
                )
            except Exception:
                pt_bundles = []
            if not pt_bundles:
                return None
            pt_bundle = pt_bundles[0]
            pt_segments_from_bundle = [
                seg for seg in pt_bundle.get('segments', [])
                if seg.get('mode') in ('train', 'bus')
                and str(seg.get('segment_id') or seg.get('offer_id') or '').startswith('offer_')
            ]
            if not pt_segments_from_bundle:
                return None
            pt_time = float(pt_bundle.get('total_duration', 0))
            if pt_time <= 0:
                return None

            # Solicit first-mile car offer from any available ondemand car provider.
            car_offer = None
            for pid, provider in self.providers.items():
                if getattr(provider, 'mode_type', None) != 'car':
                    continue
                if getattr(provider, 'operator_type', None) != 'ondemand':
                    continue
                if getattr(provider, 'available_capacity', 0) <= 0:
                    continue
                # District coverage check
                if hasattr(provider, 'can_serve_trip') and callable(provider.can_serve_trip):
                    if not provider.can_serve_trip(list(origin), list(origin_station_coord)):
                        continue
                trip_distance = _dist(origin, origin_station_coord)
                base_rate = float(getattr(provider, 'distance_rate', 1.0) or 1.0)
                base_price = float(getattr(provider, 'base_price', 1.0) or 1.0)
                speed = float(getattr(provider, 'speed', 6.5) or 6.5)
                travel_time = max(1, int(trip_distance / speed))
                price = base_price * 0.5 + trip_distance * base_rate
                if car_offer is None or price < car_offer['price']:
                    car_offer = {
                        'provider_id': pid,
                        'price': round(price, 2),
                        'duration': travel_time,
                    }
            if not car_offer:
                return None

            # Reserve capacity on the chosen car provider
            chosen_provider = self.providers.get(car_offer['provider_id'])
            if chosen_provider is None:
                return None
            car_reservation_id = f"carbundle_{request['request_id']}"
            if not chosen_provider.reserve_capacity_slot(car_reservation_id, source='car_pt_bundle'):
                return None

            # Assemble bundle segments
            car_segment = {
                'segment_id': f"carbundle_{car_offer['provider_id']}_{request['request_id']}",
                'mode': 'car',
                'origin': list(origin),
                'destination': list(origin_station_coord),
                'depart_time': start_time,
                'arrive_time': start_time + car_offer['duration'],
                'duration': car_offer['duration'],
                'price': car_offer['price'],
                'provider_id': car_offer['provider_id'],
                'operator_type': 'ondemand',
                'route_id': 'CAR_FIRST_MILE',
                'origin_station': None,
                'destination_station': origin_station_id,
                'capacity': 1,
                'status': 'available',
                'type': 'car_first_mile',
                'owning_operator_id': f"ondemand_{car_offer['provider_id']}",
            }

            # PT segments — sourced from blockchain PT bundle so they mint_and_buy properly
            pt_segments = list(pt_segments_from_bundle)
            pt_price = sum(float(seg.get('price') or 0.0) for seg in pt_segments)

            walk_duration = max(1, int(dest_walk / 4.0))
            walk_segment = {
                'segment_id': None,
                'mode': 'walk',
                'origin': list(dest_station_coord),
                'destination': list(destination),
                'depart_time': start_time + car_offer['duration'] + int(pt_time),
                'arrive_time': start_time + car_offer['duration'] + int(pt_time) + walk_duration,
                'duration': walk_duration,
                'price': 0.0,
            }

            all_segs = [car_segment] + pt_segments + [walk_segment]
            total_price = float(car_offer['price']) + float(pt_price)
            total_duration = float(car_offer['duration']) + float(pt_time) + float(walk_duration)

            return {
                'bundle_id': f"carpt_{request['request_id']}",
                'segments': all_segs,
                'total_price': round(total_price, 2),
                'total_duration': total_duration,
                'num_transfers': max(1, len(all_segs) - 1),
                'utility_score': -total_price - total_duration * 0.1,  # lower price + faster preferred
                'car_reservation_id': car_reservation_id,
                'composed_type': 'car_pt_first_mile',
            }
        except Exception as e:
            self.logger.debug(f"_compose_car_pt_bundle exception: {e}")
            return None

    def _release_car_pt_bundle_reservation(self, bundle):
        """Release the car provider reservation if the composed bundle was not chosen."""
        if not bundle:
            return
        res_id = bundle.get('car_reservation_id')
        if not res_id:
            return
        pid = None
        for seg in bundle.get('segments', []):
            if seg.get('mode') == 'car' and seg.get('provider_id') is not None:
                pid = seg['provider_id']
                break
        if pid is None:
            return
        provider = self.providers.get(pid)
        if provider is None:
            return
        try:
            provider.release_capacity_slot(res_id, source='car_pt_bundle_not_chosen')
        except Exception as e:
            self.logger.debug(f"release_capacity_slot failed for {res_id}: {e}")

    def step(self):
        """Main model step function with batched operations"""
        if self.current_step == 0:
            # On first step, ensure registrations are processed
            self._ensure_commuter_registrations()

        # Increment current step
        self.current_step += 1

        # Insert background traffic to match centralized model
        self.insert_background_traffic()

        # Process blockchain operations every step for more responsive state updates
        start_time = time.time()
        if hasattr(self.blockchain_interface, "update_cache"):
            self.blockchain_interface.update_cache()
        
        # IMPORTANT FIX: Process transaction queue more aggressively
        if self.blockchain_interface.tx_queue and len(self.blockchain_interface.tx_queue) > 0:
            self.blockchain_interface._process_transaction_batch()  # Process transactions every step
        
        self._check_blockchain_results()
        self.execution_times['blockchain_operations'].append(time.time() - start_time)
        
            
        # Process commuter decisions in batches
        start_time = time.time()
        self._process_commuter_decisions()
        self.execution_times['commuter_decisions'].append(time.time() - start_time)
        
        # Run marketplace matching periodically to settle requests/offers
        if self.current_step % 5 == 0:
            start_time = time.time()
            self._run_market_matching()
            self.execution_times['provider_offers'].append(time.time() - start_time)
        
        # Update NFT marketplace
        start_time = time.time()
        self.marketplace.update_listings()
        self.execution_times['marketplace_update'].append(time.time() - start_time)
        

        # Update popular routes
        if self.enable_market_extensions and self.current_step % 20 == 0:  # Every 20 steps
            self._update_popular_routes()
        
        # Update all agents
        self.schedule.step()
        
        # Collect data
        self.transaction_count = max(self.transaction_count, len(self.marketplace.transaction_history))
        self.completed_trips_count = len([tx for tx in self.marketplace.transaction_history 
                                        if tx.get('status') == 'completed'])
        self.datacollector.collect(self)
        
        # Update model statistics from blockchain interface
        if hasattr(self.blockchain_interface, 'stats'):
            tx_confirmed = self.blockchain_interface.stats.get('transactions_confirmed', 0)
            if tx_confirmed > 0 and self.transaction_count == 0:
                self.transaction_count = tx_confirmed
                self.logger.info(f"Updated transaction count from blockchain: {tx_confirmed}")
        # In step() method:
        if len(self.blockchain_interface.tx_queue) > 0 and self.current_step % 10 == 0:
            # Process transaction queue every 10 steps
            self.blockchain_interface._process_transaction_batch()

        # Log progress periodically
        if self.current_step % 50 == 0:
            self.logger.info(f"Step {self.current_step}: {len(self.commuters)} commuters, "
                            f"{self.transaction_count} transactions, "
                            f"{len(self.popular_routes)} popular routes")

        # Process blockchain operations more aggressively
        for _ in range(3):  # Try multiple times per step
            if hasattr(self.blockchain_interface, "_check_pending_transactions"):
                self.blockchain_interface._check_pending_transactions()
            if hasattr(self.blockchain_interface, "update_cache"):
                self.blockchain_interface.update_cache()

    def _run_market_matching(self):
        """Run matching for all active requests."""
        active_requests = self.blockchain_interface.get_marketplace_requests(status='active')
        for req in active_requests:
            req_id = req.get('request_id')
            if not req_id:
                continue
            offers = self.blockchain_interface.get_request_offers(req_id)
            if offers:
                success, match = self.blockchain_interface.run_marketplace_matching(req_id)
                if success and match:
                    self.logger.info(f"✅ Matched Request {req_id} with Offer {match.get('winning_offer_id')}")
                    self.transaction_count += 1

    def _check_blockchain_results(self):
        """Check and process blockchain transaction results"""
        # Check pending commuter registrations
        if hasattr(self.blockchain_interface, 'pending_registrations'):
            for commuter_id, reg_data in list(self.blockchain_interface.pending_registrations.items()):
                if reg_data['status'] == 'confirmed' and commuter_id in self.commuters:
                    commuter = self.commuters[commuter_id]
                    # Update commuter state to reflect successful registration
                    if hasattr(commuter, 'blockchain_status'):
                        commuter.blockchain_status = 'registered'
        
        # Check pending transactions
        for tx_hash, tx_data in list(self.blockchain_interface.pending_transactions.items()):
            if hasattr(tx_data, 'status') and tx_data.status == 'confirmed':
                # Process confirmed transaction based on type
                if tx_data.tx_type == 'request':
                    request_id = tx_data.params.get('requestId')
                    if request_id and hasattr(self.blockchain_interface, 'state_cache') and 'requests' in self.blockchain_interface.state_cache:
                        if request_id in self.blockchain_interface.state_cache['requests']:
                            # Update request status
                            self.blockchain_interface.state_cache['requests'][request_id]['status'] = 'active'
                            # Add to transaction count
                            self.transaction_count += 1
                elif tx_data.tx_type == 'marketplace' and tx_data.function_name == 'purchaseNFT':
                    # Update transaction count
                    self.transaction_count += 1

    def _process_commuter_decisions(self):
        """Process commuter decisions in batches"""
        # Create new travel requests
        self._generate_commuter_requests()
        
        # Process pending requests in batches
        if self.pending_requests:
            # Take a batch of requests
            batch = self.pending_requests[:self.batch_size]
            self.pending_requests = self.pending_requests[self.batch_size:]
            
            # Create requests as a batch to optimize blockchain transactions
            request_batch = []
            # Process each request in the batch
            for request in batch:
                commuter_id = request['commuter_id']
                commuter = self.commuters.get(commuter_id)
                
                if not commuter:
                    continue

                # Record every emitted canonical request, even if it is fulfilled
                # immediately via bundle purchase (no direct marketplace request row).
                if not hasattr(commuter, 'requests'):
                    commuter.requests = {}
                commuter.requests[request['request_id']] = request
                # ================= Attempt PT bundle before direct request =================
                request_diag = request.setdefault('market_diagnostics', {})
                try:
                    active_segments = self.blockchain_interface.get_active_segments()
                    request_diag['active_segment_count'] = len(active_segments)
                    request_diag['pt_segment_count'] = sum(
                        1 for seg in active_segments if seg.get('mode') in ('bus', 'train')
                    )
                    try:
                        canonical_pt_time, canonical_pt_route = self.evaluate_pt_route_time(
                            tuple(request['origin']),
                            tuple(request['destination']),
                        )
                        request_diag['canonical_pt_time'] = canonical_pt_time
                        request_diag['canonical_pt_edge_count'] = len([
                            leg for leg in canonical_pt_route.legs
                            if leg.get('mode') in ('bus', 'train')
                        ])
                    except Exception:
                        request_diag['canonical_pt_time'] = None
                        request_diag['canonical_pt_edge_count'] = None
                    bundles = self.blockchain_interface.build_bundles(
                        origin=request['origin'],
                        destination=request['destination'],
                        start_time=request['start_time'],
                        max_transfers=10,
                        time_tolerance=self.bundle_time_tolerance,
                        segments_override=active_segments,
                        walk_radius=self.bundle_walk_radius,
                    )
                    # Option B (Sydney): try first-mile-car + PT + walk composition
                    # when PT-only bundle search fails or when origin is far from stations.
                    composed = self._compose_car_pt_bundle(request)
                    if composed:
                        # Prepend if cheaper, else append so PT-only wins ties by default
                        if not bundles or float(composed['total_price']) < float(bundles[0].get('total_price', 1e18)):
                            bundles = [composed] + list(bundles)
                        else:
                            bundles = list(bundles) + [composed]
                        request_diag['car_pt_bundle_composed'] = True
                    request_diag['candidate_bundle_count'] = len(bundles)
                    if not bundles:
                        request_diag['failure_stage'] = (
                            'no_offer'
                            if request_diag.get('active_segment_count', 0) == 0
                            else 'no_feasible_pt_bundle_path'
                        )
                except Exception as e:
                    bundles = []
                    request_diag['candidate_bundle_count'] = 0
                    request_diag['failure_stage'] = 'no_feasible_pt_bundle_path'
                    request_diag['bundle_error'] = str(e)
                    self.logger.debug(f"Bundle search failed for commuter {commuter_id}: {e}")

                booked_segments = 0
                if bundles:
                    best_bundle = bundles[0]
                    segments = best_bundle.get('segments', [])
                    purchasable_segments = [
                        seg for seg in segments
                        if seg.get('mode') != 'walk'
                        and str(seg.get('segment_id') or seg.get('offer_id') or "").startswith("offer_")
                    ]
                    for seg in segments:
                        seg_id = seg.get('segment_id') or seg.get('offer_id') or ""
                        if seg.get('mode') == 'walk' or not str(seg_id).startswith("offer_"):
                            continue
                        if seg_id.startswith("offer_"):
                            seg_id = seg_id.replace("offer_", "")
                        depart_val = seg.get('depart_time') or seg.get('start_time')
                        duration_val = seg.get('duration') or seg.get('estimated_time')
                        mint_success, nft_id = self.blockchain_interface.mint_and_buy(
                            seg_id,
                            commuter_id,
                            start_time=depart_val,
                            duration=duration_val,
                            source_override='jit_mint'
                        )
                        if mint_success:
                            booked_segments += 1
                            if hasattr(commuter, 'owned_nfts'):
                                commuter.owned_nfts[nft_id] = {
                                    'status': 'active',
                                    'mode': seg.get('mode'),
                                    'service_time': depart_val,
                                    'price': seg.get('price')
                                }
                    if purchasable_segments and booked_segments == len(purchasable_segments):
                        # ================= Intelligent mode classification =================
                        seg_modes = set()
                        for seg in best_bundle.get('segments', []):
                            m = seg.get('mode', 'unknown')
                            if m not in ['walk', 'unknown']:
                                seg_modes.add(m)
                        if len(seg_modes) == 1:
                            final_mode = list(seg_modes)[0]
                            is_bundle_flag = False
                        elif len(seg_modes) > 1:
                            final_mode = 'bundle'
                            is_bundle_flag = True
                        else:
                            final_mode = 'walk'
                            is_bundle_flag = False

                        seg_mode_list = [
                            str(s.get('mode'))
                            for s in best_bundle.get('segments', [])
                            if s.get('mode') and s.get('mode') not in ('walk', 'unknown')
                        ]
                        mode_detailed_value = "_".join(seg_mode_list) if seg_mode_list else final_mode
                        self.log_booking(
                            tick=self.current_step,
                            request_id=request['request_id'],
                            commuter_id=commuter_id,
                            provider_id=segments[0].get('provider_id') if segments else None,
                            mode=final_mode,
                            mode_detailed=mode_detailed_value,
                            price=best_bundle.get('total_price'),
                            duration=best_bundle.get('total_duration'),
                            is_bundle=is_bundle_flag,
                            start_time=request['start_time'],
                            free_flow_travel_time=sum(
                                float(
                                    seg.get('free_flow_time')
                                    or seg.get('estimated_time')
                                    or seg.get('duration')
                                    or 0
                                )
                                for seg in segments
                            ),
                            congestion_adjusted_travel_time=best_bundle.get('total_duration'),
                            scored_travel_time_basis="congestion_adjusted_travel_time",
                        )
                        self._trace_request_decision(
                            request=request,
                            commuter_id=commuter_id,
                            chosen_mode=final_mode,
                            chosen_total_time=best_bundle.get('total_duration'),
                            chosen_total_cost=best_bundle.get('total_price'),
                            bundle=best_bundle,
                        )
                        # Release car reservations for composed bundles that were NOT the winner
                        for _b in bundles:
                            if _b is best_bundle:
                                continue
                            if _b.get('composed_type') == 'car_pt_first_mile':
                                self._release_car_pt_bundle_reservation(_b)
                        # Mark commuter as handled; skip direct request
                        commuter.active_request_id = None
                        continue
                    elif purchasable_segments:
                        request['comparison_failure_reason'] = 'booking_execution_failed'
                        request_diag['failure_stage'] = 'booking_execution_failure'
                        request_diag['purchasable_segment_count'] = len(purchasable_segments)
                        request_diag['booked_segment_count'] = booked_segments

                # Release car reservations for any composed bundles that reached here
                # unconsumed (either the composed bundle was not the winner, or booking failed).
                if bundles:
                    for _b in bundles:
                        if _b.get('composed_type') == 'car_pt_first_mile':
                            self._release_car_pt_bundle_reservation(_b)

                # Store for batch processing (direct/Auction flow)
                request_batch.append(request)
                # Check marketplace for existing NFTs matching needs
                market_options = self.marketplace.search_nfts({
                    'origin_area': [request['origin'], 5],
                    'destination_area': [request['destination'], 5],
                    'time_window': [request['start_time'] - 1800, request['start_time'] + 1800]
                })
                
                # For popular routes, check if AMM is available
                route_key = self._get_route_key(request['origin'], request['destination'], request['start_time'])

                
                if self.enable_resale_market and market_options and hasattr(commuter, 'evaluate_marketplace_options'):
                    # Choose NFT from market based on commuter's strategy weights
                    strategy_weights = getattr(commuter, 'strategy_weights', {'market_purchase': 0.3})
                    if strategy_weights.get('market_purchase', 0) > random.random():
                        # Get request ID for evaluation
                        request_id = request.get('request_id', 0)
                        
                        # Create request object if needed for evaluation
                        if request_id not in commuter.requests:
                            commuter.requests[request_id] = request
                        
                        # Evaluate options using utility function
                        ranked_options = commuter.evaluate_marketplace_options(request_id)
                        
                        if ranked_options:
                            # Select highest utility option
                            selected_nft = ranked_options[0][1]
                            success = self.blockchain_interface.purchase_nft(selected_nft['nft_id'], commuter_id)
                            if success:
                                self.logger.info(f"Commuter {commuter_id} purchased NFT {selected_nft['nft_id']} from marketplace")
                                # Update transaction count
                                self.transaction_count += 1
                else:
                    # Standard service request
                    success = self.blockchain_interface.create_travel_request(commuter, request)
                    self.logger.debug(f"Commuter {commuter_id} created travel request, success: {success}")
            # Process batch of requests
            if request_batch:
                self.blockchain_interface.process_requests_batch(request_batch)
                self._submit_intervention_direct_provider_offers(request_batch)

    def _submit_intervention_direct_provider_offers(self, request_batch):
        """
        Bounded fulfillment intervention: expose already-eligible on-demand
        providers at request time instead of relying only on local notification
        queue filtering.
        """
        if not (
            self.comparison_relaxed_direct_offers
            or self.comparison_offer_exposure_formalized
        ):
            return

        for request in request_batch:
            request_id = request.get('request_id')
            if request_id is None:
                continue
            diag = request.setdefault('market_diagnostics', {})
            baseline_offer_count = len(self.blockchain_interface.get_request_offers(request_id))
            eligible_count = 0
            submitted_count = 0

            for provider in self.providers.values():
                mode = getattr(provider, 'mode_type', None)
                if mode not in ('car', 'bike'):
                    continue
                if request_id in getattr(provider, 'active_offers', {}):
                    continue
                if not self._provider_can_make_relaxed_direct_offer(provider, request):
                    continue

                eligible_count += 1
                if provider.submit_offer_for_request(request_id):
                    submitted_count += 1

            final_offer_count = len(self.blockchain_interface.get_request_offers(request_id))
            diag['request_offer_count'] = final_offer_count
            diag['request_offer_count_before_intervention'] = baseline_offer_count
            diag['request_offer_count_after_intervention'] = final_offer_count
            diag['relaxed_direct_offer_eligible_count'] = eligible_count
            diag['relaxed_direct_offer_submitted_count'] = submitted_count

    def _provider_can_make_relaxed_direct_offer(self, provider, request):
        """Feasibility gate for the comparison-only direct-offer relaxation."""
        if hasattr(provider, "can_make_offer_exposure_offer"):
            return provider.can_make_offer_exposure_offer(request)

        origin = request.get('origin')
        destination = request.get('destination')
        if not origin or not destination:
            return False

        service_center = getattr(provider, 'service_center', getattr(provider, 'pos', None))
        if not service_center:
            return False

        service_area = float(getattr(provider, 'service_area', 10))
        origin_distance = math.sqrt(
            (float(origin[0]) - float(service_center[0])) ** 2
            + (float(origin[1]) - float(service_center[1])) ** 2
        )
        trip_distance = math.sqrt(
            (float(destination[0]) - float(origin[0])) ** 2
            + (float(destination[1]) - float(origin[1])) ** 2
        )
        if origin_distance > service_area:
            return False
        if getattr(provider, 'mode_type', None) == 'bike' and trip_distance > 20:
            return False
        return True
    
    
    def _generate_commuter_requests(self):
        """
        Emit canonical, deterministic commuter requests when trips are due.
        If a commuter is busy when a trip becomes due, keep it queued and emit once free.
        """
        generated_count = 0

        # Queue all due-but-not-yet-emitted trips so they are not silently dropped.
        for commuter_id in self.commuters.keys():
            plans = self.trip_plans.get(int(commuter_id), [])
            queue = self._pending_trip_queue.setdefault(int(commuter_id), [])
            for trip in plans:
                if trip.trip_id in self._emitted_trip_ids or trip.trip_id in self._queued_trip_ids:
                    continue
                if self.current_step >= trip.depart_step:
                    queue.append(trip)
                    self._queued_trip_ids.add(trip.trip_id)
            if len(queue) > 1:
                queue.sort(key=lambda t: (t.depart_step, t.trip_index))

        for commuter_id, commuter in self.commuters.items():
            if getattr(commuter, 'active_request_id', None) is not None:
                continue
            if hasattr(commuter, 'active_trips') and commuter.active_trips:
                continue

            canonical_idx = self.commuter_canonical_index.get(commuter_id, 0)
            queue = self._pending_trip_queue.get(int(commuter_id), [])
            if not queue:
                continue

            trip = queue.pop(0)
            self._queued_trip_ids.discard(trip.trip_id)
            request_id = self._canonical_request_id(canonical_idx, trip)
            request = {
                'request_id': request_id,
                'commuter_id': int(commuter_id),
                'origin': list(trip.origin_xy),
                'destination': list(trip.dest_xy),
                'start_time': trip.depart_step,
                'travel_purpose': trip.purpose,
                'flexible_time': commuter.determine_schedule_flexibility(trip.purpose),
                'status': 'active',
                'created_at': self.current_step,
                'canonical_trip_id': trip.trip_id,
                'depart_delay': max(0, int(self.current_step - trip.depart_step)),
            }
            self.pending_requests.append(request)
            commuter.active_request_id = request_id
            self._emitted_trip_ids.add(trip.trip_id)
            generated_count += 1

        if generated_count > 0:
            self.logger.info(
                f"Tick {self.current_step}: Generated {generated_count} canonical travel requests."
            )
        self.last_canonical_requests_emitted = generated_count
        self.total_canonical_requests_emitted += generated_count
        if self.current_step % 10 == 0:
            print(
                f"[TRIP EMIT] step={self.current_step} "
                f"new={generated_count} "
                f"total={self.total_canonical_requests_emitted}"
            )

    def _generate_request_id(self):
        """Generate a unique request ID"""
        # Use timestamp and random number for uniqueness
        return int(time.time() * 1000 + random.randint(0, 999))

    def log_booking(
        self,
        tick,
        request_id,
        commuter_id,
        provider_id,
        mode,
        price,
        duration,
        is_bundle=False,
        mode_detailed=None,
        start_time=None,
        end_tick=None,
        free_flow_travel_time=None,
        congestion_adjusted_travel_time=None,
        scored_travel_time_basis=None,
    ):
        """Record detailed booking info for post-analysis."""
        start_val = start_time if start_time is not None else tick
        dur_val = duration if duration is not None else 0
        end_val = end_tick if end_tick is not None else start_val + dur_val
        free_flow_val = free_flow_travel_time if free_flow_travel_time is not None else dur_val
        congestion_val = (
            congestion_adjusted_travel_time if congestion_adjusted_travel_time is not None else dur_val
        )
        basis_val = scored_travel_time_basis or "congestion_adjusted_travel_time"
        if basis_val == "free_flow_travel_time":
            scored_travel_time = free_flow_val
        elif basis_val == "travel_time":
            scored_travel_time = dur_val
        else:
            basis_val = "congestion_adjusted_travel_time"
            scored_travel_time = congestion_val
        entry = {
            "tick": tick,
            "start_tick": start_val,
            "end_tick": end_val,
            "request_id": request_id,
            "commuter_id": commuter_id,
            "provider_id": provider_id,
            # Store canonical mode fields so downstream export does not fall back to 'unknown'
            "mode": mode,
            "provider_type": mode,
            "mode_category": "bundle" if is_bundle else mode,
            "mode_detailed": mode_detailed or mode,
            "price": round(price or 0, 2),
            "duration": dur_val,
            "free_flow_travel_time": free_flow_val,
            "congestion_adjusted_travel_time": congestion_val,
            "travel_time": scored_travel_time,
            "scored_travel_time_basis": basis_val,
        }
        self.booking_logs.append(entry)

    def log_booking_detailed(self, tick, duration, mode, price, commuter_id, is_bundle=False, provider_id=None):
        """More structured logger for duration-based mode share plots."""
        clean_mode = "Bundle" if is_bundle else mode
        if not is_bundle:
            if "bus" in str(mode) or "train" in str(mode):
                clean_mode = "Public Transport"
            elif "car" in str(mode) or "uber" in str(mode):
                clean_mode = "Car"
            elif "bike" in str(mode):
                clean_mode = "Bike"
        self.detailed_logs.append({
            "start_tick": tick,
            "duration": duration,
            "end_tick": tick + duration,
            "mode": clean_mode,
            "raw_mode": mode,
            "price": price,
            "commuter_id": commuter_id,
            "provider_id": provider_id,
            # Canonical mode fields for consistency with simpler booking export
            "provider_type": clean_mode,
            "mode_category": clean_mode
        })

    def save_detailed_logs(self, filename="bookings_detailed.csv"):
        """Persist detailed duration-based booking logs to CSV."""
        import pandas as pd
        if not getattr(self, "detailed_logs", None):
            self.logger.warning("No detailed logs to save.")
            return
        df = pd.DataFrame(self.detailed_logs)
        df.to_csv(filename, index=False)
        self.logger.info(f"Saved {len(df)} detailed booking records to {filename}")

    def _determine_travel_purpose(self, current_time):
        """
        Determine likely travel purpose based on time of day
        
        Args:
            current_time: Current simulation time
            
        Returns:
            Travel purpose code (0: work, 1: school, 2: shopping, etc.)
        """
        time_of_day = current_time % 144  # 144 ticks per day
        
        # Morning peak (likely work/school)
        if 36 <= time_of_day < 60:
            return random.choices([0, 1], weights=[0.8, 0.2])[0]  # 80% work, 20% school
        # Mid-day (likely shopping/errands/medical)
        elif 60 <= time_of_day < 90:
            return random.choices([2, 3, 6], weights=[0.5, 0.3, 0.2])[0]  # Shopping, medical, leisure
        # Evening peak (likely return from work/leisure)
        elif 90 <= time_of_day < 114:
            return random.choices([0, 6], weights=[0.6, 0.4])[0]  # Work, leisure
        # Evening (likely leisure)
        elif 114 <= time_of_day < 126:
            return 6  # Leisure
        # Night/early morning (likely other)
        else:
            return 7  # Other

    def _should_create_trip(self, commuter):
        """
        Determine if commuter should create a trip based on smoother
        time-of-day probabilities (0-144 ticks = 24h).
        """
        # If busy or already requesting, skip
        if getattr(commuter, 'active_trips', None):
            return False
        if getattr(commuter, 'active_request_id', None):
            return False

        time_of_day = self.current_step % 144
        prob = 0.001  # default very low
        if 30 <= time_of_day < 60:   # morning peak
            prob = 0.15
        elif 90 <= time_of_day < 120:  # evening peak
            prob = 0.12
        elif 60 <= time_of_day < 90:   # mid-day
            prob = 0.03
        elif 120 <= time_of_day < 144: # late evening
            prob = 0.01

        # Simple heterogeneity offset
        offset = hash(commuter.unique_id) % 10
        if (time_of_day + offset) % 20 == 0:
            prob *= 1.5

        if commuter.income_level == 'high':
            prob *= 1.2
        elif commuter.income_level == 'low':
            prob *= 0.8

        return random.random() < prob

    def _generate_destination(self, commuter):
        """Generate a destination with hub/CBD bias."""
        current_pos = commuter.location
        cbd_pos = self.hubs["CBD"]
        dist_to_cbd = math.sqrt((current_pos[0]-cbd_pos[0])**2 + (current_pos[1]-cbd_pos[1])**2)

        if dist_to_cbd > 15:
            # Live in hub -> 80% go to CBD, else other hub
            if random.random() < 0.8:
                target = cbd_pos
            else:
                target = self.hubs[random.choice(["NorthHub", "SouthHub", "EastHub", "WestHub"])]
        else:
            # Live near CBD -> go to a hub
            target = self.hubs[random.choice(["NorthHub", "SouthHub", "EastHub", "WestHub"])]

        dx = int(random.gauss(0, 4))
        dy = int(random.gauss(0, 4))
        dest_x = max(0, min(target[0] + dx, self.grid_width - 1))
        dest_y = max(0, min(target[1] + dy, self.grid_height - 1))
        return (dest_x, dest_y)

    def _process_provider_offers(self):
        """Process provider offers in batches"""
        # Use a combination of pending and cached active requests
        active_requests = []
        
        # Add pending requests that are marked active
        active_requests.extend([
            request for request in self.pending_requests 
            if request.get('status', 'active') == 'active'
        ])
        
        # Also check blockchain interface cache for active requests
        if hasattr(self.blockchain_interface, 'state_cache') and 'requests' in self.blockchain_interface.state_cache:
            self.logger.info(f"Total requests in state cache: {len(self.blockchain_interface.state_cache.get('requests', {}))}")
            self.logger.info(f"Requests with 'active' status: {sum(1 for r in self.blockchain_interface.state_cache.get('requests', {}).values() if r.get('status') == 'active')}")

            for req_id, req_data in self.blockchain_interface.state_cache['requests'].items():
                if req_data.get('status') == 'active':
                    # Convert cached request to proper format
                    
                    try:
                        request_data = req_data.get('data', {})
                        if isinstance(request_data, dict) and 'origin' in request_data and 'destination' in request_data:
                            request = {
                                'request_id': req_id,
                                'origin': request_data.get('origin', [0, 0]),
                                'destination': request_data.get('destination', [0, 0]),
                                'start_time': request_data.get('startTime', 0),
                                'status': 'active'
                            }
                            active_requests.append(request)
                    except Exception as e:
                        self.logger.error(f"Error processing cached request: {e}")
        
        self.logger.info(f"Processing provider offers for {len(active_requests)} active requests")
        # For each provider, generate offers
        for provider_id, provider in self.providers.items():
            # Each provider considers a subset of requests based on capacity
            provider_capacity = provider.available_capacity
            requests_to_consider = random.sample(
                active_requests, 
                min(provider_capacity, len(active_requests))
            ) if active_requests else []
            
            # Filter requests by service area
            requests_to_consider = [
                req for req in requests_to_consider
                if provider._can_service_route(req['origin'], req['destination'])
            ]
            
            # Generate offers
            for request in requests_to_consider:
                offer = provider.generate_offer(request)
                if offer:
                    self.pending_offers.append(offer)
                    self.logger.info(f"Provider {provider_id} generated offer for request {request['request_id']}")
        
        # Process offers in batches
        if self.pending_offers:
            # Take a batch of offers
            batch = self.pending_offers[:self.batch_size]
            self.pending_offers = self.pending_offers[self.batch_size:]
            
            # Process each offer in the batch
            for offer in batch:
                if 'provider_id' not in offer:
                    continue
                    
                provider_id = offer['provider_id']
                provider = self.providers.get(provider_id)
                
                if not provider:
                    continue
                
                # Submit offer via blockchain
                success = provider.blockchain_interface.submit_offer(
                    provider, 
                    offer['request_id'], 
                    offer['price'], 
                    {
                        'route': offer['route'],
                        'time': offer['estimated_time'],
                        'start_time': offer['start_time'],
                        'mode': provider.mode_type
                    }
                )
                
                if success:
                    self.logger.info(f"Provider {provider_id} submitted offer for request {offer['request_id']} at price {offer['price']}")
                else:
                    self.logger.warning(f"Failed to submit offer for request {offer['request_id']}")

    
    def _check_provider_liquidity_opportunities(self):
        """Check for providers who could benefit from adding liquidity to AMM pools"""
        # This simulates providers deciding to participate in AMM liquidity provision
        # Only check occasionally to reduce computational overhead
        if self.current_step % 15 != 0:
            return
            
        # For each provider, check if they should add liquidity to any pool
        for provider_id, provider in self.providers.items():
            # Only consider providers with sufficient capacity
            if provider.available_capacity < provider.capacity * 0.3:
                continue
                
            # Check which routes the provider can service
            for route_key in self.popular_routes:
                # Extract route information
                origin, destination, _ = self._parse_route_key(route_key)
                
                # Check if provider can service this route
                if not provider._can_service_route(origin, destination):
                    continue
                    
                # Decide whether to add liquidity (30% chance if eligible)
                if random.random() < 0.3:
                    # Calculate amount based on capacity and price
                    liquidity_amount = provider.base_price * 10
                    

    def _check_arbitrage_opportunities(self):
        """
        Check for price differences between market listings and AMM pools
        that could be exploited for arbitrage
        """
        # Only check occasionally
        if self.current_step % 10 != 0:
            return
            
        # For each popular route with an AMM pool
        for route_key in self.popular_routes:
                
            
            # Extract route information
            origin, destination, time_window = self._parse_route_key(route_key)
            
            # Find market listings for similar route
            market_listings = self.marketplace.search_nfts({
                'origin_area': [origin, 5],
                'destination_area': [destination, 5],
                'time_window': [time_window - 3600, time_window + 3600]
            })
            
            if not market_listings:
                continue
                
            # Calculate average market price
            market_prices = [listing['price'] for listing in market_listings]
            avg_market_price = sum(market_prices) / len(market_prices)
            
                
                # In a more complex model, agents could exploit this opportunity

    def _update_popular_routes(self):
        """Update the set of popular routes based on transaction history"""
        # Count transactions by route
        self.route_transactions = {}
        
        # Analyze transaction history
        for tx in self.marketplace.transaction_history:
            nft_id = tx.get('nft_id')
            if nft_id in self.marketplace.listings:
                listing = self.marketplace.listings[nft_id]
                if 'details' in listing:
                    # Get route details
                    details = listing['details']
                    route_key = self._get_route_key(
                        details.get('origin', [0, 0]),
                        details.get('destination', [0, 0]),
                        details.get('service_time', 0)
                    )
                    
                    # Count transaction
                    self.route_transactions[route_key] = self.route_transactions.get(route_key, 0) + 1
        
       

    def _get_route_key(self, origin, destination, time_window=None):
        """
        Create a standardized key for a route
        
        Args:
            origin: Origin coordinates [x, y]
            destination: Destination coordinates [x, y]
            time_window: Optional time window
            
        Returns:
            Route key string
        """
        # Convert to tuples
        origin = tuple(origin)
        destination = tuple(destination)
        
        if time_window is not None:
            # Round time to nearest hour (simplifies clustering similar times)
            rounded_time = round(time_window / 12) * 12  # 12 ticks per hour
            return f"{origin}_{destination}_{rounded_time}"
        else:
            return f"{origin}_{destination}"

    def _parse_route_key(self, route_key):
        """
        Parse a route key into origin, destination, and time
        
        Args:
            route_key: Route key string
            
        Returns:
            Tuple of (origin, destination, time_window)
        """
        parts = route_key.split('_')
        if len(parts) >= 5:  # Full format with coordinates and time
            # Format is like "(x,y)_(x,y)_time"
            origin_str = parts[0] + '_' + parts[1]
            dest_str = parts[2] + '_' + parts[3]
            time_window = int(parts[4]) if len(parts) > 4 and parts[4].isdigit() else 0
            
            # Parse coordinates
            try:
                origin = eval(origin_str)
                destination = eval(dest_str)
                return origin, destination, time_window
            except:
                self.logger.warning(f"Error parsing route key: {route_key}")
                return (0, 0), (0, 0), 0
        else:
            # Simple format or parsing error
            self.logger.warning(f"Unsupported route key format: {route_key}")
            return (0, 0), (0, 0), 0

    def _estimate_route_price(self, origin, destination):
        """
        Estimate price for a route based on distance and market conditions
        
        Args:
            origin: Origin coordinates
            destination: Destination coordinates
            
        Returns:
            Estimated price
        """
        # Calculate distance
        distance = ((destination[0] - origin[0])**2 + (destination[1] - origin[1])**2)**0.5
        
        # Base price calculation
        base_price = max(5, distance * 0.8)
        
        # Check if this is a popular route with existing transactions
        route_key = self._get_route_key(origin, destination)
        
        # If we have market data, use it to influence the price
        market_price = self.marketplace.get_market_price({
            'origin': origin,
            'destination': destination,
            'service_time': self.current_step + 24  # 2 hours in future
        })
        
        if market_price:
            # Blend market price with base price (60% market, 40% base)
            return 0.6 * market_price + 0.4 * base_price
        
        # Apply time-of-day factor
        time_factor = 1.0
        if self.check_is_peak():
            time_factor = 1.2  # 20% premium during peak hours
        
        return base_price * time_factor

    def calculate_average_nft_price(self):
        """Calculate average price of active NFT listings"""
        self.logger.info(f"Current marketplace transactions: {len(self.marketplace.transaction_history)}")
        active_listings = [listing for listing in self.marketplace.listings.values() 
                        if listing.get('status') == 'active']
        
        # IMPORTANT FIX: Sync transaction count with blockchain before calculating stats
        if self.transaction_count == 0 and hasattr(self.blockchain_interface, 'stats'):
            confirmed_tx = self.blockchain_interface.stats.get('transactions_confirmed', 0)
            if confirmed_tx > 0:
                self.transaction_count = confirmed_tx
                self.logger.info(f"Synced transaction count from blockchain: {confirmed_tx}")
                
        # IMPORTANT FIX: Update completed trips count if it's zero but we have transactions
        if self.completed_trips_count == 0 and self.transaction_count > 0:
            self.completed_trips_count = self.transaction_count
            self.logger.info(f"Synced completed trips count from transactions: {self.transaction_count}")
        
        if not active_listings:
            return 0
        
        # Update active listings count for statistics
        self.active_listings_count = len(active_listings)
            
        return sum(listing.get('current_price', 0) for listing in active_listings) / len(active_listings)
    
    def count_active_commuters(self):
        """Count active commuters with ongoing requests"""
        return sum(1 for commuter in self.commuters.values() 
                 if hasattr(commuter, 'has_active_request') and commuter.has_active_request())

    def count_active_providers(self):
        """Count providers with available capacity"""
        return sum(1 for provider in self.providers.values() 
                 if provider.available_capacity > 0)

    def count_completed_trips(self):
        """Count total completed trips"""
        # Instead of calculating this every time, use the tracked counter
        return self.completed_trips_count

    def _init_sydney_topology(self):
        """Initialize Sydney-like hubs and peak hours for directional demand."""
        self.hubs = self._build_hubs_from_canonical_map()
        # Peak hours (ticks in a 144-step day)
        self.peak_hours = [(42, 54), (102, 114)]
        self.logger.info("Initialized Sydney Topology and Peak Hours.")

    def get_average_execution_time(self):
        """Get average execution time across all components"""
        execution_times = {}
        
        for component, times in self.execution_times.items():
            if times:
                execution_times[component] = sum(times) / len(times)
                
        return execution_times

    def on_service_completed(self, provider_id, commuter_id, was_on_time, nft_id):
        """
        Callback for completed service to update statistics and agent behavior
        
        Args:
            provider_id: ID of service provider
            commuter_id: ID of commuter
            was_on_time: Whether service was provided on time
            nft_id: ID of the service NFT
        """
        # Update provider statistics
        if provider_id in self.providers:
            provider = self.providers[provider_id]
            
            # Update provider reliability based on performance
            if was_on_time:
                provider.reliability = min(100, provider.reliability + 0.5)
            else:
                provider.reliability = max(50, provider.reliability - 1.0)
            
            # Restore capacity
            provider.available_capacity = min(provider.capacity, provider.available_capacity + 1)
        
        # Update commuter satisfaction
        if commuter_id in self.commuters:
            commuter = self.commuters[commuter_id]
            
            if hasattr(commuter, 'update_provider_satisfaction'):
                satisfaction = 1.0 if was_on_time else 0.5
                commuter.update_provider_satisfaction(provider_id, satisfaction)
        
        # IMPORTANT FIX: Update trip count directly 
        self.completed_trips_count += 1
        self.logger.info(f"Service completion callback: Incremented trips to {self.completed_trips_count}")
        
        # Update route transaction counts
        if nft_id in self.marketplace.listings:
            listing = self.marketplace.listings[nft_id]
            if 'details' in listing:
                # Get route details
                details = listing['details']
                route_key = self._get_route_key(
                    details.get('origin', [0, 0]),
                    details.get('destination', [0, 0]),
                    details.get('service_time', 0)
                )
                
                # Count transaction
                self.route_transactions[route_key] = self.route_transactions.get(route_key, 0) + 1
        
        self.logger.info(f"Service completed: Provider {provider_id}, Commuter {commuter_id}, NFT {nft_id}, On time: {was_on_time}")
        
    def log_speculator_action(self, agent_id, action, nft_id, price, tick):
        """
        Record speculator actions for later analysis/visualization.
        """
        record = {
            "tick": tick,
            "agent_id": agent_id,
            "action": action,
            "nft_id": nft_id,
            "price": price,
            "timestamp": datetime.now().strftime("%H:%M:%S")
        }
        self.speculator_log.append(record)
        # Console highlight for easy spotting
        if action == "scalp":
            print(f"🕵️ [SCALPER] Agent {agent_id} 囤积了 NFT {nft_id} (成本 ${price:.2f})")
        elif action == "list":
            print(f"📢 [SCALPER] Agent {agent_id} 挂单 NFT {nft_id} (标价 ${price:.2f})")
        elif action == "sell":
            print(f"💸 [SCALPER] Agent {agent_id} 卖出 NFT {nft_id} (成交 ${price:.2f})")

    def run_model(self, steps):
        """Run model for specified number of steps"""
        # Ensure registrations are confirmed before starting simulation
        self._ensure_commuter_registrations()
        
        for i in range(steps):
            self.step()
            
            # Log progress
            if (i+1) % 20 == 0:
                self.logger.info(f"Completed step {i+1}/{steps}")
                
        self.logger.info(f"Model run completed: {steps} steps executed")
        return self.datacollector.get_model_vars_dataframe()

    def _ensure_commuter_registrations(self):
        """Wait for commuter registrations to be confirmed"""
        self.logger.info("Ensuring all commuter registrations are confirmed (lightweight check)...")
        # Without a pending-tx helper, just verify accounts exist in the local map
        missing = [
            cid for cid in self.commuters
            if not self.blockchain_interface.is_commuter_registered(cid)
        ]
        if missing:
            self.logger.warning(f"Commuter accounts not present in cache: {missing[:5]}")
        else:
            self.logger.info("All commuter registrations confirmed in cache.")
        
        self.logger.warning("Not all registrations confirmed. Proceeding with caution.")
