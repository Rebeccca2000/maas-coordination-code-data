# File: abm/agents/decentralized_provider.py
# SIMPLIFIED VERSION - Uses marketplace API for all operations

import logging
import random
import math
import os
import sys
from contextlib import nullcontext
from mesa import Agent

REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../../"))
if REPO_ROOT not in sys.path:
    sys.path.insert(0, REPO_ROOT)

from shared_experiment_config import PT_IN_VEHICLE_PER_HOP, WALK_SPEED_UNITS_PER_TICK
from shared_pt_operating_assumptions import compute_pt_segment_fare, get_pt_expected_wait_time
from shared_cross_world_runtime import resolve_pt_price_factor
from shared_pt_router import pt_route_time_between_points, door_to_door_walk_time

# V8 bug #3 instrumentation (§23 ruling 2026-07-13). Warn-limit throttle removed;
# every fingerprint event is dropped to $V8_BUG3_EVENT_PATH as JSONL so post-hoc
# station_path attribution is possible. The hard fix in submit_offer_for_request
# refuses to post the PT offer when shared_total_time is None/non-finite; the
# gate ("residual_no_decline == 0") verifies the fix.
V8_BUG3_FALLBACK_COUNT = 0
_V8_BUG3_EVENTS: list = []


def _v8_bug3_event_path():
    return os.environ.get(
        "V8_BUG3_EVENT_PATH",
        os.path.join(os.getcwd(), "v8_bug3_fallback_events.jsonl"),
    )


def _v8_bug3_fallback_hit(provider, request_id, surviving_travel_time,
                          shared_total_time, *, origin=None, destination=None,
                          station_path=None, shared_total_price=None,
                          pt_legs=None, decline_action=None):
    global V8_BUG3_FALLBACK_COUNT
    V8_BUG3_FALLBACK_COUNT += 1
    payload = {
        "request_id": request_id,
        "provider_id": getattr(provider, "unique_id", None),
        "mode_type": getattr(provider, "mode_type", None),
        "current_step": getattr(getattr(provider, "model", None), "current_step", None),
        "shared_total_time": shared_total_time,
        "shared_total_price": shared_total_price,
        "surviving_travel_time": float(surviving_travel_time) if surviving_travel_time is not None else None,
        "origin": [origin[0], origin[1]] if origin is not None else None,
        "destination": [destination[0], destination[1]] if destination is not None else None,
        "station_path": list(station_path) if station_path is not None else None,
        "pt_legs_count": len(pt_legs) if pt_legs is not None else None,
        "decline_action": decline_action,
    }
    _V8_BUG3_EVENTS.append(payload)
    try:
        import json as _json
        with open(_v8_bug3_event_path(), "a") as fh:
            fh.write(_json.dumps(payload) + "\n")
    except Exception:
        pass
    try:
        provider.logger.warning(
            "V8 bug #3 fingerprint on request %s (provider=%s, mode=%s, decline=%s): "
            "shared_total_time=%r, surviving travel_time=%.3f, station_path_len=%s",
            request_id, getattr(provider, "unique_id", None),
            getattr(provider, "mode_type", None), decline_action,
            shared_total_time,
            float(surviving_travel_time) if surviving_travel_time is not None else float("nan"),
            None if station_path is None else len(station_path),
        )
    except Exception:
        pass


def _v8_bug3_write_report():
    try:
        import json
        report_path = os.environ.get(
            "V8_BUG3_REPORT_PATH",
            os.path.join(os.getcwd(), "v8_bug3_fallback_report.json"),
        )
        by_decline: dict = {}
        for ev in _V8_BUG3_EVENTS:
            key = ev.get("decline_action") or "residual_no_decline"
            by_decline[key] = by_decline.get(key, 0) + 1
        with open(report_path, "w") as f:
            json.dump({
                "fallback_count": V8_BUG3_FALLBACK_COUNT,
                "events_recorded": len(_V8_BUG3_EVENTS),
                "by_decline_action": by_decline,
                "gate_pass": by_decline.get("residual_no_decline", 0) == 0,
                "event_log_path": _v8_bug3_event_path(),
            }, f, indent=2)
    except Exception:
        pass


import atexit as _atexit
_atexit.register(_v8_bug3_write_report)

class DecentralizedProvider(Agent):
    """
    Simplified provider agent that uses marketplace API

    Now supports proactive NFT segment creation for bundle routing
    """

    def __init__(self, unique_id, model, pos, company_name, mode_type,
                 capacity, base_price, blockchain_interface=None,
                 operator_id=None, operator_type="ondemand", mode_set=None,
                 distance_rate=None, speed=None, bike_speed=None,
                 reliability=None, quality_score=None, coverage_type=None,
                 preferred_zones=None, out_of_preference_penalty_multiplier=1.0,
                 zone_id=None, zone_bounds=None, corridor_ids=None,
                 local_route_ids=None, feeder_route_ids=None):
        super().__init__(unique_id, model)

        # Agent type identifier for database export
        self.is_provider = True
        # Basic attributes
        self.pos = pos
        self.company_name = company_name
        self.operator_id = operator_id or company_name
        self.operator_type = operator_type
        self.mode_type = mode_type
        self.mode_set = list(mode_set) if mode_set else [mode_type]
        self.capacity = capacity
        self.available_capacity = capacity
        self.base_price = base_price
        self.distance_rate = distance_rate
        self.speed = speed
        self.bike_speed = bike_speed
        self.coverage_type = coverage_type
        self.preferred_zones = list(preferred_zones) if preferred_zones else []
        self.out_of_preference_penalty_multiplier = out_of_preference_penalty_multiplier
        self.zone_id = zone_id
        self.zone_bounds = zone_bounds
        self.corridor_ids = list(corridor_ids) if corridor_ids else []
        self.local_route_ids = list(local_route_ids) if local_route_ids else []
        self.feeder_route_ids = list(feeder_route_ids) if feeder_route_ids else []

        # Marketplace interface
        self.marketplace = blockchain_interface  # This is actually the marketplace API
        self.blockchain_interface = blockchain_interface

        # Service tracking
        self.active_offers = {}
        self.completed_services = 0
        self.total_revenue = 0
        self.processed_request_notifications = set()
        self.active_capacity_reservations = {}
        self.capacity_accounting_events = []
        self.travel_time_diagnostics = []
        self.capacity_reservation_attempts = 0
        self.successful_capacity_reservations = 0
        self.failed_capacity_reservations = 0
        self.capacity_release_count = 0
        self.capacity_release_noop_count = 0
        self.min_available_capacity_observed = capacity
        self.max_active_reservations_observed = 0
        self.negative_capacity_event_count = 0

        # Quality metrics
        self.quality_score = quality_score if quality_score is not None else random.randint(60, 90)
        if reliability is None:
            self.reliability = random.randint(70, 95)
            self.reliability_profile = self.reliability / 100.0
        else:
            self.reliability_profile = float(reliability)
            self.reliability = int(round(float(reliability) * 100)) if float(reliability) <= 1.0 else int(round(float(reliability)))
        self.service_center = list(pos)

        # Bundle segment tracking
        self.active_segments = {}  # Track created NFT segments
        self.segment_creation_interval = 10  # Create segments every N steps
        self.last_segment_creation = 0

        # Logging
        self.logger = logging.getLogger(f"Provider-{unique_id}-{company_name}")
        
    def step(self):
        """Main step function - simplified flow"""
        # Register with marketplace if not registered
        if not hasattr(self, 'registered'):
            success, address = self.marketplace.register_provider(self)
            if success:
                self.registered = True
                self.address = address

                # Store detailed provider profile for booking analysis
                profile_data = {
                    'provider_id': self.unique_id,
                    'name': f"{self.company_name}-{self.unique_id}",
                    'operator_id': self.operator_id,
                    'operator_type': self.operator_type,
                    'mode': self.mode_type,
                    'mode_set': list(self.mode_set),
                    'capacity': self.capacity,
                    'base_price': self.base_price,
                    'distance_rate': self.distance_rate,
                    'speed': self.speed,
                    'bike_speed': self.bike_speed,
                    'quality_score': self.quality_score,
                    'reliability': self.reliability,
                    'reliability_profile': self.reliability_profile,
                    'service_center': self.service_center,
                    'company_name': self.company_name,
                    'coverage_type': self.coverage_type,
                    'preferred_zones': list(self.preferred_zones),
                    'zone_id': self.zone_id,
                    'zone_bounds': self.zone_bounds,
                    'corridor_ids': list(self.corridor_ids),
                    'local_route_ids': list(self.local_route_ids),
                    'feeder_route_ids': list(self.feeder_route_ids),
                }
                self.marketplace.store_provider_profile(self.unique_id, profile_data)

        # Check for notifications from marketplace
        if hasattr(self, 'registered') and self.registered:
            self.check_marketplace_notifications()

            # Arbitrage scan every 3 steps to add liquidity
            if self.model.current_step % 3 == 0:
                self._run_arbitrage_logic()

    def accept_booking(self, commuter_id, request_id, price, start_time, route=None):
        """
        Handle a direct booking request and record it with explicit mode information.
        """
        if not self.reserve_capacity_slot(request_id, source="direct_booking"):
            self.logger.warning(f"Provider {self.unique_id} has no capacity for request {request_id}")
            return False

        # Derive duration from route distance and mode speed
        origin = route[0] if route else self.service_center
        destination = route[-1] if route else self.service_center
        trip_distance = self._calculate_distance(origin, destination)
        if self.mode_type == 'car':
            speed = float(self.speed) if self.speed is not None else 2.0
        elif self.mode_type == 'bike':
            speed = float(self.bike_speed) if self.bike_speed is not None else 0.8
        else:
            speed = float(self.speed) if self.speed is not None else 1.0
        duration = max(1, int(trip_distance / speed)) if trip_distance else 1
        end_time = start_time + duration

        match_id = f"direct_{self.unique_id}_{request_id}"
        match_data = {
            'match_id': match_id,
            'request_id': request_id,
            'commuter_id': commuter_id,
            'provider_id': self.unique_id,
            'price': price,
            'timestamp': self.model.schedule.time,
            'status': 'completed',
            'source': 'direct',
            'mode': self.mode_type,
            'provider_type': self.mode_type,
            'origin': origin,
            'destination': destination,
            'route_details': {'route': route or [origin, destination], 'duration': duration},
            'start_time': start_time,
            'end_time': end_time,
        }

        # Record match details and transaction with explicit mode
        if hasattr(self.blockchain_interface, "store_match_details"):
            self.blockchain_interface.store_match_details(match_id, match_data)
        if hasattr(self.blockchain_interface, "_record_transaction"):
            self.blockchain_interface._record_transaction(
                offer_id=f"direct_{request_id}",
                buyer_id=commuter_id,
                price=price,
                tx_type="direct_booking",
                explicit_tick=self.model.current_step,
                source_override='direct',
                start_time=start_time,
                duration=duration,
                mode_override=self.mode_type
            )

        self.active_offers[request_id] = {
            'price': price,
            'details': {
                'route': [origin, destination],
                'time': duration,
                'mode': self.mode_type
            },
            'submitted_at': self.model.schedule.time
        }

        self.logger.info(f"Direct booking accepted by {self.unique_id} ({self.mode_type}) for request {request_id}")
        return True
    
    def check_marketplace_notifications(self):
        """Check for request notifications from marketplace"""
        notifications = self.marketplace.get_provider_notifications(self.unique_id)

        if (
            getattr(self.model, "comparison_offer_exposure_formalized", False)
            or getattr(self.model, "comparison_relaxed_direct_offers", False)
        ):
            pending_notifications = notifications
        else:
            pending_notifications = notifications[-5:]

        for notification in pending_notifications:
            request_id = notification['request_id']
            if request_id in self.processed_request_notifications:
                continue
            if request_id in self.active_offers:
                self.processed_request_notifications.add(request_id)
                continue
            self.submit_offer_for_request(request_id)
            self.processed_request_notifications.add(request_id)

    def can_make_offer_exposure_offer(self, request):
        """
        Request-time eligibility gate for the bounded fulfillment intervention.

        This does not relax topology or ownership. It only determines whether an
        already-existing on-demand provider should be exposed to the request.
        """
        if self.available_capacity <= 0:
            return False
        if self.mode_type not in ("car", "bike"):
            return False

        origin = request.get("origin")
        destination = request.get("destination")
        if not origin or not destination:
            return False

        service_center = getattr(self, "service_center", getattr(self, "pos", None))
        if not service_center:
            return False

        coverage_type = getattr(self, "coverage_type", None)
        service_area = float(getattr(self, "service_area", 0) or 0)

        origin_distance = self._calculate_distance(origin, service_center)
        destination_distance = self._calculate_distance(destination, service_center)
        trip_distance = self._calculate_distance(origin, destination)

        if coverage_type != "city_wide":
            if service_area <= 0:
                return False
            if min(origin_distance, destination_distance) > service_area:
                return False

        if self.mode_type == "bike" and trip_distance > 55:
            return False

        return True

    def _record_capacity_event(self, event_type, request_id, before_capacity, after_capacity, source):
        if after_capacity < 0:
            self.negative_capacity_event_count += 1
        self.min_available_capacity_observed = min(self.min_available_capacity_observed, after_capacity)
        self.max_active_reservations_observed = max(
            self.max_active_reservations_observed,
            len(self.active_capacity_reservations),
        )
        self.capacity_accounting_events.append(
            {
                "step": getattr(self.model, "current_step", None),
                "event_type": event_type,
                "request_id": request_id,
                "source": source,
                "before_capacity": before_capacity,
                "after_capacity": after_capacity,
                "active_reservation_count": len(self.active_capacity_reservations),
            }
        )

    def has_capacity_reservation(self, request_id):
        return str(request_id) in self.active_capacity_reservations

    def reserve_capacity_slot(self, request_id, source="unknown"):
        request_key = str(request_id)
        self.capacity_reservation_attempts += 1
        if request_key in self.active_capacity_reservations:
            self._record_capacity_event(
                "reserve_idempotent",
                request_key,
                self.available_capacity,
                self.available_capacity,
                source,
            )
            return True
        if self.available_capacity <= 0:
            self.failed_capacity_reservations += 1
            self._record_capacity_event(
                "reserve_failed_no_capacity",
                request_key,
                self.available_capacity,
                self.available_capacity,
                source,
            )
            return False
        before_capacity = self.available_capacity
        self.available_capacity = max(0, self.available_capacity - 1)
        self.active_capacity_reservations[request_key] = {
            "source": source,
            "reserved_at_step": getattr(self.model, "current_step", None),
        }
        self.successful_capacity_reservations += 1
        self._record_capacity_event(
            "reserve_success",
            request_key,
            before_capacity,
            self.available_capacity,
            source,
        )
        return True

    def release_capacity_slot(self, request_id, source="unknown"):
        request_key = str(request_id)
        if request_key not in self.active_capacity_reservations:
            self.capacity_release_noop_count += 1
            self._record_capacity_event(
                "release_noop",
                request_key,
                self.available_capacity,
                self.available_capacity,
                source,
            )
            return False
        before_capacity = self.available_capacity
        del self.active_capacity_reservations[request_key]
        self.available_capacity = min(self.capacity, self.available_capacity + 1)
        self.capacity_release_count += 1
        self._record_capacity_event(
            "release_success",
            request_key,
            before_capacity,
            self.available_capacity,
            source,
        )
        return True

    def _compute_direct_offer_travel_time(self, request, trip_distance, speed):
        free_flow_time = max(1, int(trip_distance / max(float(speed), 1e-9)))
        if self.mode_type != "car" or not hasattr(self.model, "calculate_bpr_time"):
            return float(free_flow_time), float(free_flow_time), False
        congested_time = self.model.calculate_bpr_time(
            request["origin"],
            request["destination"],
            free_flow_time,
        )
        congested_time = max(1.0, float(congested_time))
        return congested_time, float(free_flow_time), True
    
    def submit_offer_for_request(self, request_id):
        """Submit an offer through marketplace API"""
        # Get request details from marketplace
        requests = self.marketplace.get_marketplace_requests()
        request = next((r for r in requests if r['request_id'] == request_id), None)
        
        if not request:
            return False

        # Calculate trip distance origin->destination for pricing/time
        trip_distance = self._calculate_distance(request['origin'], request['destination'])
        # Use requested start_time when available so downstream logging has a real depart_time
        depart_time = request.get('start_time', self.model.current_step)

        # Utilization for dynamic pricing
        utilization = 1.0 - (self.available_capacity / max(1, self.capacity))

        # V9 §1.2b Phase 1.3 wiring: Layer A card override. Mirrors Rep tree.
        def _v9_env_flag(name: str) -> bool:
            return os.environ.get(name, "").strip().lower() in ("1", "true", "yes", "on")
        _v9_neutral = _v9_env_flag("V9_NEUTRAL_SPEC")
        _v9_layer_b_neutral = _v9_env_flag("V9_LAYER_B_NEUTRAL")

        # §1.4 STOP #2(bis) 2026-07-14: Layer-A inputs come from the shared world
        # publisher (`shared_fare_card.card_distance_units` + `card_time_ticks_direct`).
        # Alignment target is C's consumption / world canonical — NOT the reporter.
        # Under `V9_NEUTRAL_SPEC=1` a card-import/mode failure MUST refuse the
        # offer (no silent legacy fallback). CSV `travel_time` remains D-side
        # realism (BPR for car, distance/speed for bike); only the fare's
        # time_ticks input is canonicalised.
        if self.mode_type == 'car':
            speed_base = float(self.speed) if self.speed is not None else 2.4
            speed = speed_base * random.uniform(0.85, 1.15)
            travel_time, free_flow_time, includes_congestion = self._compute_direct_offer_travel_time(
                request,
                trip_distance,
                speed,
            )
        elif self.mode_type == 'bike':
            speed = float(self.bike_speed) if self.bike_speed is not None else 1.4
            _orig_bike = request.get('origin', [0, 0])
            _dest_bike = request.get('destination', [0, 0])
            _bike_manhattan = float(abs(_orig_bike[0] - _dest_bike[0]) + abs(_orig_bike[1] - _dest_bike[1]))
            travel_time = max(1, int(_bike_manhattan / speed))
            free_flow_time = float(travel_time)
            includes_congestion = False
        else:
            speed_base = float(self.speed) if self.speed is not None else 1.0
            speed = speed_base * random.uniform(0.8, 1.2)
            travel_time = max(1, int(trip_distance / speed))
            free_flow_time = float(travel_time)
            includes_congestion = False

        if self.mode_type == 'car':
            base_rate = float(self.distance_rate) if self.distance_rate is not None else 1.4
            if utilization > 0.8:
                surge = 2.5
            elif utilization < 0.2:
                surge = 0.4  # even deeper discount when idle
            else:
                surge = 1.0
            if _v9_neutral:
                try:
                    from shared_fare_card import (
                        compute_fare as _cf,
                        card_distance_units as _cdu,
                        card_time_ticks_direct as _cttd,
                    )
                    _card_d = _cdu(request.get('origin'), request.get('destination'))
                    _card_t = _cttd("car", _card_d, depart_time)
                    _layer_a = float(_cf("ride_hail", distance_units=_card_d, time_ticks=_card_t))
                except Exception as _card_exc:
                    _v8_bug3_fallback_hit(
                        self, request_id, travel_time, None,
                        origin=request.get('origin'), destination=request.get('destination'),
                        station_path=None, shared_total_price=None,
                        pt_legs=None, decline_action="refused_no_card",
                    )
                    self.logger.debug(
                        "Refusing car direct offer for request %s under V9_NEUTRAL_SPEC=1: card failure (%s).",
                        request_id, _card_exc,
                    )
                    return False
                price = _layer_a if _v9_layer_b_neutral else _layer_a * surge
            else:
                price = (self.base_price * 0.5 + trip_distance * base_rate) * surge
        elif self.mode_type == 'bike':
            bike_rate = float(self.distance_rate) if self.distance_rate is not None else 0.4
            bike_base = float(self.base_price) if self.base_price is not None else 0.0
            if _v9_neutral:
                try:
                    from shared_fare_card import (
                        compute_fare as _cf,
                        card_distance_units as _cdu,
                        card_time_ticks_direct as _cttd,
                    )
                    _card_d = _cdu(request.get('origin'), request.get('destination'))
                    _card_t = _cttd("bike", _card_d, depart_time)
                    price = float(_cf("micromobility", distance_units=_card_d, time_ticks=_card_t))
                except Exception as _card_exc:
                    _v8_bug3_fallback_hit(
                        self, request_id, travel_time, None,
                        origin=request.get('origin'), destination=request.get('destination'),
                        station_path=None, shared_total_price=None,
                        pt_legs=None, decline_action="refused_no_card",
                    )
                    self.logger.debug(
                        "Refusing bike direct offer for request %s under V9_NEUTRAL_SPEC=1: card failure (%s).",
                        request_id, _card_exc,
                    )
                    return False
            else:
                _orig_bike_legacy = request.get('origin', [0, 0])
                _dest_bike_legacy = request.get('destination', [0, 0])
                _bike_manhattan_legacy = float(abs(_orig_bike_legacy[0] - _dest_bike_legacy[0]) + abs(_orig_bike_legacy[1] - _dest_bike_legacy[1]))
                price = bike_base + _bike_manhattan_legacy * bike_rate
        else:
            other_rate = float(self.distance_rate) if self.distance_rate is not None else 2.0
            price = self.base_price + trip_distance * other_rate

        # Layer B noise: stays unless V9_LAYER_B_NEUTRAL=1.
        if not _v9_layer_b_neutral:
            price *= random.uniform(0.9, 1.1)
        price = max(1.0, round(price, 2))

        arrive_time = depart_time + travel_time

        pt_legs = []
        if self.mode_type in ("train", "bus"):
            pt_legs, shared_total_time, shared_total_price, _station_path = \
                self._build_canonical_pt_legs(request['origin'], request['destination'])
            # Do not submit PT direct offers without canonical station-leg metadata.
            # This avoids matched-offer records with null PT signatures.
            if not pt_legs:
                _v8_bug3_fallback_hit(
                    self, request_id, travel_time, shared_total_time,
                    origin=request.get('origin'), destination=request.get('destination'),
                    station_path=_station_path, shared_total_price=shared_total_price,
                    pt_legs=pt_legs, decline_action="refused_no_pt_legs",
                )
                self.logger.debug(
                    "Skipping PT direct offer for request %s: no canonical PT legs (%s).",
                    request_id,
                    self.mode_type,
                )
                return False
            # §23.1 hard fix: canonical PT time must be finite; otherwise refuse
            # to post the offer rather than propagating fallback dist/speed time.
            if shared_total_time is None or not math.isfinite(shared_total_time):
                _v8_bug3_fallback_hit(
                    self, request_id, travel_time, shared_total_time,
                    origin=request.get('origin'), destination=request.get('destination'),
                    station_path=_station_path, shared_total_price=shared_total_price,
                    pt_legs=pt_legs, decline_action="refused_no_canonical_time",
                )
                self.logger.debug(
                    "Refusing PT direct offer for request %s (%s): shared_total_time=%r "
                    "(bug#3 hard fix, §23.1).",
                    request_id, self.mode_type, shared_total_time,
                )
                return False
            travel_time = max(1.0, float(shared_total_time))
            free_flow_time = float(travel_time)
            includes_congestion = False
            arrive_time = depart_time + travel_time
            if shared_total_price is not None and math.isfinite(shared_total_price) and shared_total_price > 0:
                # Sum of compute_pt_segment_fare() across all canonical hops, matching
                # compute_pt_itinerary_time_and_price() exactly. Replaces the simple
                # base_price + distance formula for PT direct offers.
                price = float(shared_total_price)

        # Prepare offer details
        offer_details = {
            'route': [request['origin'], request['destination']],
            'time': travel_time,
            'mode': self.mode_type,
            'depart_time': depart_time,
            'start_time': depart_time,
            'estimated_time': travel_time,
            'free_flow_time': free_flow_time,
            'travel_time_includes_congestion': includes_congestion,
            'arrive_time': arrive_time,
        }
        if pt_legs:
            offer_details['pt_legs'] = pt_legs
            pt_signature = [
                (
                    leg.get('route_id'),
                    leg.get('segment_index'),
                    leg.get('origin_station'),
                    leg.get('destination_station'),
                )
                for leg in pt_legs
                if leg.get('mode') in ('train', 'bus')
            ]
            if pt_signature:
                offer_details['pt_signature'] = pt_signature
                offer_details['origin_station'] = pt_legs[0].get('origin_station')
                offer_details['destination_station'] = pt_legs[-1].get('destination_station')
                if len(pt_legs) == 1:
                    offer_details['route_id'] = pt_legs[0].get('route_id')
                    offer_details['segment_index'] = pt_legs[0].get('segment_index')
        
        # Submit offer through marketplace API (not blockchain directly!)
        success = self.marketplace.submit_offer(
            self,
            request_id,
            price,
            offer_details
        )
        
        if success:
            self.active_offers[request_id] = {
                'price': price,
                'details': offer_details,
                'submitted_at': self.model.schedule.time
            }

            # Store detailed offer information for booking analysis
            offer_id = f"{request_id}{self.unique_id}"  # Create unique offer ID
            offer_data = {
                'offer_id': offer_id,
                'provider_id': self.unique_id,
                'request_id': request_id,
                'price': price,
                'estimated_time': offer_details['time'],
                'free_flow_time': offer_details.get('free_flow_time'),
                'travel_time_includes_congestion': offer_details.get('travel_time_includes_congestion', False),
                'mode': self.mode_type,
                'route': offer_details['route'],
                'depart_time': depart_time,
                'start_time': depart_time,
                'arrive_time': arrive_time,
                'distance': trip_distance,
                'submitted_at': self.model.schedule.time,
                'provider_location': self.service_center
            }
            self.marketplace.store_offer_details(offer_id, offer_data)
            self.travel_time_diagnostics.append(
                {
                    "step": getattr(self.model, "current_step", None),
                    "request_id": request_id,
                    "mode": self.mode_type,
                    "provider_id": self.unique_id,
                    "free_flow_time": free_flow_time,
                    "estimated_time": travel_time,
                    "travel_time_includes_congestion": includes_congestion,
                }
            )

            self.logger.info(f"Submitted offer for request {request_id} at price {price:.2f}")

        return success

    def _find_segment_index(self, mode, route_id, origin_station, destination_station):
        routes = getattr(self.model, 'routes', {})
        seq = routes.get(mode, {}).get(route_id, [])
        for idx in range(len(seq) - 1):
            if seq[idx] == origin_station and seq[idx + 1] == destination_station:
                return idx
            if seq[idx] == destination_station and seq[idx + 1] == origin_station:
                return idx
        return None

    def _build_canonical_pt_legs(self, origin, destination):
        """Return (pt_legs, total_time, total_price, station_path).

        ``station_path`` is returned so callers can pair D's Dijkstra chain
        against C's cached shared route for the same OD (§23.2 transfer_wait
        attribution). Returns ``([], None, None, None)`` on any failure path.
        """
        stations = getattr(self.model, 'stations', None)
        routes = getattr(self.model, 'routes', None)
        transfers = getattr(self.model, 'transfers', None)
        if not stations or not routes or transfers is None:
            return [], None, None, None
        try:
            route = pt_route_time_between_points(
                origin_xy=tuple(origin),
                dest_xy=tuple(destination),
                stations=stations,
                routes=routes,
                transfers=transfers,
                in_vehicle_per_hop=PT_IN_VEHICLE_PER_HOP,
            )
        except Exception as exc:
            self.logger.debug(f"Failed canonical PT leg build for request path: {exc}")
            return [], None, None, None

        # Add wait time per route boarding to match centralised PT time accounting.
        # The router's total_time only includes in-vehicle + transfer time (no wait).
        # compute_pt_itinerary_time_and_price() in the centralised path adds
        # get_pt_expected_wait_time(route_id) once per route boarding.
        wait_time_factor = float(
            (getattr(self.model, 'world_settings', None) or {}).get('pt_wait_time_factor', 1.0)
        )
        price_factor = resolve_pt_price_factor(
            world_settings=getattr(self.model, 'world_settings', None)
        )
        total_wait = 0.0
        current_route_id = None
        total_price = 0.0
        # V9 §1.4.1 wiring. Mirrors Rep tree — see there for full commentary.
        _v9_neutral = os.environ.get("V9_NEUTRAL_SPEC", "").strip().lower() in ("1", "true", "yes", "on")
        _journey_legs: list = []
        _cur_journey_first_xy = None
        _cur_journey_last_xy = None
        _cur_journey_mode = None
        _cur_journey_route_id = None

        def _flush_journey_leg():
            nonlocal _cur_journey_first_xy, _cur_journey_last_xy, _cur_journey_mode, _cur_journey_route_id
            if _cur_journey_mode is None or _cur_journey_first_xy is None or _cur_journey_last_xy is None:
                return
            d = (
                (_cur_journey_first_xy[0] - _cur_journey_last_xy[0]) ** 2
                + (_cur_journey_first_xy[1] - _cur_journey_last_xy[1]) ** 2
            ) ** 0.5
            _journey_legs.append({"mode": _cur_journey_mode, "distance_units": float(d)})
            _cur_journey_first_xy = None
            _cur_journey_last_xy = None
            _cur_journey_mode = None
            _cur_journey_route_id = None

        for leg in route.legs:
            if leg.get('type') == 'transfer':
                _flush_journey_leg()
            if leg.get('type') == 'in_vehicle':
                rid = leg.get('route_id')
                if rid != current_route_id:
                    current_route_id = rid
                    total_wait += get_pt_expected_wait_time(rid) * wait_time_factor
                mode = leg.get('mode')
                if mode in ('train', 'bus'):
                    u_station = leg.get('from')
                    v_station = leg.get('to')
                    u_xy = self._station_xy(u_station, stations)
                    v_xy = self._station_xy(v_station, stations)
                    if u_xy is not None and v_xy is not None:
                        if not _v9_neutral:
                            total_price += compute_pt_segment_fare(
                                mode=mode,
                                origin_xy=u_xy,
                                destination_xy=v_xy,
                                depart_step=self.model.current_step,
                                price_factor=price_factor,
                            )
                        if rid != _cur_journey_route_id or mode != _cur_journey_mode:
                            _flush_journey_leg()
                            _cur_journey_first_xy = u_xy
                            _cur_journey_mode = mode
                            _cur_journey_route_id = rid
                        _cur_journey_last_xy = v_xy
            else:
                current_route_id = None
        _flush_journey_leg()

        if _v9_neutral:
            try:
                from shared_fare_card import compute_pt_journey_fare
                total_price = float(compute_pt_journey_fare(_journey_legs))
            except Exception:
                total_price = 0.0

        legs = []
        for leg in route.legs:
            mode = leg.get('mode')
            if mode not in ('train', 'bus'):
                continue
            route_id = leg.get('route_id')
            origin_station = leg.get('from')
            destination_station = leg.get('to')
            segment_index = self._find_segment_index(mode, route_id, origin_station, destination_station)
            legs.append({
                'mode': mode,
                'route_id': route_id,
                'segment_index': segment_index,
                'origin_station': origin_station,
                'destination_station': destination_station,
                'time': leg.get('time'),
            })
        station_path = list(getattr(route, "station_path", []) or [])
        # V9 §27 Phase 1.1: door-to-door metric parity. Mirrors Rep tree —
        # extend total_time by endpoint walk so posted PT offers carry the
        # walk-INCLUSIVE convention required by the Phase 1.5 gate.
        walk_endpoints = door_to_door_walk_time(
            origin_xy=tuple(origin),
            dest_xy=tuple(destination),
            station_path=station_path,
            stations=stations,
            walk_speed=WALK_SPEED_UNITS_PER_TICK,
        )
        return legs, route.total_time + total_wait + walk_endpoints, total_price, station_path

    @staticmethod
    def _station_xy(station_id, stations):
        if not station_id:
            return None
        if station_id.startswith('T_') and 'train' in stations:
            return stations['train'].get(station_id)
        if station_id.startswith('B_') and 'bus' in stations:
            return stations['bus'].get(station_id)
        for mode_map in stations.values():
            if station_id in mode_map:
                return mode_map[station_id]
        return None
    
    def complete_service(self, request_id, price):
        """Complete a service, update metrics, and relocate provider"""
        self.completed_services += 1
        self.total_revenue += price

        # Relocate to destination of the served trip
        if request_id in self.active_offers:
            details = self.active_offers[request_id]['details']
            dest = details.get('route', [])[-1] if details.get('route') else None
            if dest:
                try:
                    self.model.grid.move_agent(self, dest)
                except Exception:
                    pass
                self.pos = dest
                self.service_center = list(dest)
            del self.active_offers[request_id]

        self.release_capacity_slot(request_id, source="service_completion")

        self.logger.info(f"Completed service for request {request_id}, relocated to {self.pos}")
        return True

    def _run_arbitrage_logic(self):
        """Market making: force scan and buy active listings."""
        try:
            # Read listings from marketplace_db
            db = getattr(self.marketplace, 'marketplace_db', {})
            all_listings = db.get('listings', {})

            # DEBUG: how many listings does this provider see?
            if len(all_listings) > 0:
                self.logger.info(f"DEBUG: Provider {self.unique_id} sees {len(all_listings)} listings.")

            # Active listings, exclude own sales
            listings = [
                l for l in all_listings.values()
                if l.get('status') == 'active' and str(l.get('seller_id')) != str(self.unique_id)
            ]
        except Exception as e:
            self.logger.error(f"Arbitrage logic error: {e}")
            return

        for listing in listings:
            details = listing.get('details', {})
            origin = details.get('origin', self.service_center)
            dest = details.get('destination', self.service_center)
            dist = self._calculate_distance(origin, dest)
            base_value = dist * self.base_price

            service_time = details.get('service_time', self.model.current_step)
            time_premium = 1.5 if self.model.check_is_peak(service_time) else 1.0
            fair_value = base_value * time_premium
            time_left = service_time - self.model.current_step

            ask = listing.get('current_price', listing.get('price', 1e9))
            nft_id = listing.get('nft_id')

            # Rational buy: require at least ~10% discount vs fair value
            if ask < fair_value * 0.90 and time_left > 0:
                self.logger.info(f"💰 Arbitrage! Buying NFT {nft_id} at {ask:.2f} (FV: {fair_value:.2f})")
                success = self.marketplace.purchase_nft(nft_id, self.unique_id)

                if success:
                    new_price = ask * 1.2  # relist at 20% premium
                    time_params = {
                        'initial_price': new_price,
                        'final_price': new_price * 0.8,
                        'decay_rate': 0.05
                    }
                    self.marketplace.list_nft_for_sale(nft_id, new_price, time_params)
                    self.logger.info(f"📈 Re-listed NFT {nft_id} at {new_price:.2f}")
                    break  # buy one and stop to avoid spam
    
    def _calculate_distance(self, point1, point2):
        """Calculate distance between two points"""
        return math.sqrt((point2[0] - point1[0])**2 + (point2[1] - point1[1])**2)
    
    def get_service_offers(self, origin, destination, start_time):
        """Get service offers for a route - used by marketplace"""
        distance = self._calculate_distance(origin, destination)
        price = self.base_price + (distance * 2)

        return [{
            'provider_id': self.unique_id,
            'price': price,
            'time': int(distance * 3),
            'mode': self.mode_type,
            'quality': self.quality_score
        }]

    def _should_create_segments(self):
        """Check if provider should create new route segments"""
        # Only create segments if bundle system is enabled
        if not hasattr(self.model, 'enable_proactive_segments'):
            return False

        if not self.model.enable_proactive_segments:
            return False

        # Create segments periodically
        current_step = self.model.current_step
        if current_step - self.last_segment_creation >= self.segment_creation_interval:
            return True

        return False


class PublicTransportProvider(DecentralizedProvider):
    """
    Public transport provider that publishes fixed-schedule segment offers (no NFT mint until purchase).
    """

    def __init__(self, unique_id, model, pos, route_stations, schedule_interval=20,
                 capacity_per_trip=6, company_name="PublicTransport", base_fare=2.0,
                 blockchain_interface=None, mode_type="bus", speed_modifier=1.5,
                 route_id=None, route_station_ids=None, station_lookup=None,
                 in_vehicle_per_hop=PT_IN_VEHICLE_PER_HOP, operator_id=None,
                 operator_type="public_transport", distance_rate=None,
                 reliability=None, quality_score=None, zone_id=None,
                 zone_bounds=None, corridor_ids=None, local_route_ids=None,
                 feeder_route_ids=None, corridor_id=None, service_scope=None):
        # Use model.blockchain_interface by default to retain register_provider/register_commuter APIs
        bc_if = blockchain_interface or getattr(model, "blockchain_interface", None)
        super().__init__(
            unique_id=unique_id,
            model=model,
            pos=pos,
            company_name=company_name,
            mode_type=mode_type,
            capacity=capacity_per_trip,
            base_price=base_fare,
            blockchain_interface=bc_if,
            operator_id=operator_id,
            operator_type=operator_type,
            mode_set=[mode_type],
            distance_rate=distance_rate,
            speed=None,
            bike_speed=None,
            reliability=reliability,
            quality_score=quality_score,
            coverage_type="fixed_route",
            zone_id=zone_id,
            zone_bounds=zone_bounds,
            corridor_ids=corridor_ids,
            local_route_ids=local_route_ids,
            feeder_route_ids=feeder_route_ids,
        )
        self.route_stations = route_stations
        self.schedule_interval = schedule_interval
        self.capacity_per_trip = capacity_per_trip
        self.base_fare = base_fare
        self.last_publish_step = -1
        self.mode_type = mode_type
        self.route_id = route_id or f"PT_{self.unique_id}"
        self.route_station_ids = route_station_ids or []
        self.station_lookup = station_lookup or {}
        self.in_vehicle_per_hop = float(in_vehicle_per_hop)
        self.corridor_id = corridor_id
        self.service_scope = service_scope or "fixed_route"
        # speed_modifier >1 -> slower than straight-line, <1 -> faster (express/rail)
        self.speed_modifier = speed_modifier

    def step(self):
        # Run base provider logic (registration, bookkeeping)
        super().step()

        # Publish future schedules periodically
        # Avoid re-publishing at t=0 if bootstrapped already; publish thereafter on interval
        if self.model.current_step > 0 and self.model.current_step % self.schedule_interval == 0:
            self.publish_future_schedules()

    def _resolve_route_stop(self, idx):
        station_id = self.route_station_ids[idx] if idx < len(self.route_station_ids) else None
        raw = self.route_stations[idx]

        if isinstance(raw, str):
            station_id = station_id or raw
            if station_id not in self.station_lookup:
                raise ValueError(f"Missing coordinate for station id {station_id}")
            xy = self.station_lookup[station_id]
        else:
            xy = (raw[0], raw[1])
            if station_id and station_id in self.station_lookup:
                xy = self.station_lookup[station_id]

        return station_id, (xy[0], xy[1])

    def publish_future_schedules(self, horizon=None):
        """Publish segment offers for the next `horizon` minutes."""
        current = self.model.current_step
        if horizon is None:
            horizon = max(1, self.schedule_interval)

        published = 0
        for time_offset in range(0, horizon, self.schedule_interval):
            route_depart_time = current + time_offset
            for i in range(len(self.route_stations) - 1):
                origin_station, origin = self._resolve_route_stop(i)
                destination_station, dest = self._resolve_route_stop(i + 1)
                for direction, seg_origin_station, seg_origin, seg_dest_station, seg_dest, hop_offset in (
                    ("F", origin_station, origin, destination_station, dest, i),
                    ("R", destination_station, dest, origin_station, origin, (len(self.route_stations) - 2 - i)),
                ):
                    segment_id = f"{self.mode_type.upper()}_{self.unique_id}_{self.route_id}_{direction}_{i}"
                    duration = self.in_vehicle_per_hop
                    depart_time = route_depart_time + (hop_offset * duration)
                    aligned_price = compute_pt_segment_fare(
                        mode=self.mode_type,
                        origin_xy=seg_origin,
                        destination_xy=seg_dest,
                        depart_step=depart_time,
                        price_factor=resolve_pt_price_factor(
                            world_settings=getattr(self.model, "world_settings", None)
                        ),
                    )

                    offer = {
                        'offer_id': segment_id,
                        'type': 'segment',
                        'provider_id': self.unique_id,
                        'owning_operator_id': self.operator_id,
                        'operator_type': self.operator_type,
                        'mode': self.mode_type,
                        'origin': [seg_origin[0], seg_origin[1]],
                        'destination': [seg_dest[0], seg_dest[1]],
                        'origin_station': seg_origin_station,
                        'destination_station': seg_dest_station,
                        'route_id': self.route_id,
                        'corridor_id': self.corridor_id,
                        'zone_id': self.zone_id,
                        'service_scope': self.service_scope,
                        'segment_index': i,
                        'direction': direction,
                        'depart_time': depart_time,
                        'start_time': depart_time,
                        'estimated_time': duration,
                        'arrive_time': depart_time + duration,
                        'price': aligned_price,
                        'capacity': self.capacity_per_trip,
                        'sold_count': 0,
                        'status': 'available'
                    }
                    if hasattr(self.marketplace, "broadcast_offer"):
                        self.marketplace.broadcast_offer(offer)
                        published += 1
        self.logger.info(
            f"Provider {self.unique_id} published {published} canonical PT adjacency offers "
            f"from t={current} to {current + horizon}"
        )

    def create_route_segments(self):
        """
        Create proactive NFT segments for bundle routing

        This creates intermediate route segments that can be combined
        into multi-modal bundles by the bundle router.
        """
        try:
            current_step = self.model.current_step
            self.last_segment_creation = current_step

            # Generate route segments based on provider's service area
            segments = self._generate_route_segments()

            if not segments:
                return

            # Create offers for each segment
            for segment in segments:
                segment_id = f"{self.unique_id}_{segment['origin']}_{segment['destination']}_{current_step}"

                # Create offer in marketplace database
                offer = {
                    'offer_id': segment_id,
                    'segment_id': segment_id,
                    'type': 'segment',  # Mark as proactive segment
                    'provider_id': self.unique_id,
                    'mode': self.mode_type,
                    'origin': segment['origin'],
                    'destination': segment['destination'],
                    'depart_time': segment['start_time'],
                    'arrive_time': segment['start_time'] + segment['duration'],
                    'estimated_time': segment['duration'],
                    'price': segment['price'],
                    'capacity': 1,
                    'status': 'available',  # Available for bundle routing
                    'created_at': current_step,
                    'route': [segment['origin'], segment['destination']]
                }

                # Store in marketplace database
                with self.marketplace.marketplace_db_lock:
                    self.marketplace.marketplace_db['offers'][segment_id] = offer

                # Track locally
                self.active_segments[segment_id] = offer

            self.logger.info(f"Created {len(segments)} route segments for bundle routing")

        except Exception as e:
            self.logger.error(f"Error creating route segments: {e}")
            import traceback
            traceback.print_exc()

    def _generate_route_segments(self):
        """PT-provider override: emit one segment per adjacent station pair on
        this provider's actual fixed route. Duration = in_vehicle_per_hop
        (0.8 min/hop) — matches the shared PT router used by C.
        Replaces the inherited random-direction generator which produced
        duration = distance * 3, inflating PT trip times ~6x.
        """
        segments = []
        current_step = self.model.current_step
        if not getattr(self, 'route_station_ids', None) or len(self.route_station_ids) < 2:
            return []
        stations = self.station_lookup or {}
        # Build price rules by mode (peak/offpeak surge applied separately
        # by the marketplace fare calc; here just base + distance).
        if self.mode_type == 'bus':
            base = 1.2
            dist_rate = 0.18
        else:
            base = 1.8
            dist_rate = 0.20

        # Emit forward-direction hops. Each consecutive station pair becomes
        # a bookable segment departing at the current step + a small stagger.
        for i in range(len(self.route_station_ids) - 1):
            from_id = self.route_station_ids[i]
            to_id = self.route_station_ids[i + 1]
            from_xy = stations.get(from_id)
            to_xy = stations.get(to_id)
            if not from_xy or not to_xy:
                continue
            from_xy = list(from_xy)
            to_xy = list(to_xy)
            distance = self._calculate_distance(from_xy, to_xy)
            duration = max(1, int(round(self.in_vehicle_per_hop)))
            # Publish a couple of departures so the bundle router has schedule flexibility.
            for k in range(2):
                start_time = current_step + i + k * max(1, int(self.schedule_interval))
                price = base + distance * dist_rate
                segments.append({
                    'origin': from_xy,
                    'destination': to_xy,
                    'start_time': start_time,
                    'duration': duration,
                    'price': round(price, 2),
                    'distance': distance,
                })
        return segments

    def _base_generate_route_segments(self):
        """
        Generate intermediate route segments based on provider's service area

        Creates segments that can connect with other providers' segments
        to form multi-modal bundles.

        Strategy: Create segments along grid lines to increase connectivity
        """
        segments = []
        current_step = self.model.current_step

        # Get grid dimensions
        grid_width = self.model.grid.width
        grid_height = self.model.grid.height

        # Create segments along major grid points for better connectivity
        # Use grid step size to align segments
        grid_step = 3  # Align to 3-unit grid for denser coverage

        # Generate 5-8 route segments for better network density
        num_segments = random.randint(5, 8)

        for i in range(num_segments):
            # Start from service center (rounded to grid)
            origin_x = round(self.service_center[0] / grid_step) * grid_step
            origin_y = round(self.service_center[1] / grid_step) * grid_step
            origin = [origin_x, origin_y]

            # Create destination along cardinal or diagonal directions
            # This creates a network of connecting segments
            direction = random.choice([
                (1, 0),   # East
                (0, 1),   # North
                (-1, 0),  # West
                (0, -1),  # South
                (1, 1),   # Northeast
                (1, -1),  # Southeast
                (-1, 1),  # Northwest
                (-1, -1)  # Southwest
            ])

            # Distance: widen to 1-10 grid steps for broader length/pricing spread
            steps = random.randint(1, 10)
            dest_x = origin_x + (direction[0] * grid_step * steps)
            dest_y = origin_y + (direction[1] * grid_step * steps)

            # Clamp to grid boundaries
            dest_x = max(0, min(grid_width - 1, dest_x))
            dest_y = max(0, min(grid_height - 1, dest_y))

            destination = [dest_x, dest_y]

            # Skip if origin and destination are the same
            if origin == destination:
                continue

            # Calculate segment properties
            segment_distance = self._calculate_distance(origin, destination)
            if segment_distance < 1:  # Skip very short segments
                continue

            # Duration by mode speed. Original code used distance*3 which was
            # 3-6x actual mode speed and grossly inflated bundle travel times.
            if self.mode_type == 'car':
                speed = float(self.speed or 6.5)
                duration = max(1, int(segment_distance / speed))
            elif self.mode_type == 'bike':
                bike_speed = float(self.bike_speed or 1.4)
                duration = max(1, int(segment_distance / bike_speed))
            elif self.mode_type in ('train', 'bus'):
                # PT segments should be per-hop (base class fallback only; PT
                # providers override _generate_route_segments to walk their real route).
                duration = max(1, int(getattr(self, 'in_vehicle_per_hop', 0.8) or 0.8))
            else:
                duration = max(1, int(segment_distance / 3.0))

            # Start time: stagger across a wide range to enable chaining
            # Some segments depart now, some in near future, some later
            # This allows segments to connect: segment1 arrives -> segment2 departs
            time_offset = i * 10  # Stagger by segment index
            start_time = current_step + time_offset + random.randint(-5, 10)

            # Dynamic pricing for PT segments with surge and noise
            if self.mode_type == "bus":
                dist_rate = 0.18
                base = 1.2
            else:
                dist_rate = 0.2
                base = 1.8
            time_of_day = start_time % 144
            is_peak = (30 <= time_of_day <= 60) or (90 <= time_of_day <= 120)
            surge = random.uniform(1.3, 1.7) if is_peak else 1.0
            raw_price = base + (segment_distance * dist_rate)
            price = raw_price * surge + random.uniform(-0.2, 0.8)
            price = max(1.0, round(price, 2))

            segment = {
                'origin': origin,
                'destination': destination,
                'start_time': start_time,
                'duration': duration,
                'price': price,
                'distance': segment_distance
            }

            segments.append(segment)

        return segments
