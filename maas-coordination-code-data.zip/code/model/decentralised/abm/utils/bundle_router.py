"""
Decentralized Bundle Router for MaaS
Implements peer-to-peer bundle discovery and distributed route assembly
"""

import logging
import os
from typing import List, Dict, Tuple, Optional, Set
from collections import defaultdict
import math
import hashlib
import json

try:
    from shared_experiment_config import PT_IN_VEHICLE_PER_HOP
except ImportError:
    PT_IN_VEHICLE_PER_HOP = 0.8
try:
    from shared_pt_operating_assumptions import compute_pt_segment_fare, resolve_pt_price_factor
except ImportError:
    compute_pt_segment_fare = None
    resolve_pt_price_factor = None


class DecentralizedBundleRouter:
    """
    Decentralized bundle routing using peer-to-peer discovery
    
    Instead of a central router, this implements:
    1. Distributed segment discovery via blockchain event logs
    2. Peer-to-peer route assembly using graph traversal
    3. Auction-driven path formation for competitive pricing
    
    This avoids centralization by having each commuter independently:
    - Query blockchain for available segments (NFTs)
    - Assemble routes locally using graph algorithms
    - Participate in auctions for contested segments
    """
    
    def __init__(self, blockchain_interface, logger=None):
        self.blockchain = blockchain_interface
        self.logger = logger or logging.getLogger(__name__)
        
        # Local cache of segment graph (built from blockchain events)
        self.segment_graph = defaultdict(list)  # origin -> [(destination, segment_data)]
        self.segment_index = {}  # segment_id -> segment_data
        
        # Auction tracking for contested segments
        self.active_auctions = {}  # segment_id -> auction_data
        
    def get_active_segments(self, time_window: Tuple[int, int] = None) -> List[Dict]:
        """
        DECENTRALIZED: Query blockchain for active segments via event logs
        
        Instead of querying a central database, this reads NFT mint events
        and offer submissions directly from the blockchain.
        
        Args:
            time_window: (start_tick, end_tick) for filtering segments
            
        Returns:
            List of active segment dictionaries
        """
        try:
            # Query blockchain marketplace for active NFTs/offers
            # This is decentralized - reading from blockchain state
            active_segments = []
            
            # Get all active NFT listings from blockchain
            nfts = self.blockchain.search_nfts(
                origin_area=None,  # Get all
                destination_area=None,
                time_window=time_window,
                max_price=None
            )
            
            # Get all active offers from marketplace
            # Include both regular offers ('submitted') and proactive segments ('available')
            with self.blockchain.marketplace_db_lock:
                offers = [
                    offer for offer in self.blockchain.marketplace_db.get('offers', {}).values()
                    if offer.get('status') in ['submitted', 'available']
                ]
            
            # Convert NFTs to segment format
            for nft in nfts:
                segment = {
                    'segment_id': f"nft_{nft.get('token_id', '')}",
                    'type': 'nft',
                    'provider_id': nft.get('provider_id'),
                    'mode': nft.get('mode', 'unknown'),
                    'origin': nft.get('origin', []),
                    'destination': nft.get('destination', []),
                    'depart_time': nft.get('start_time', 0),
                    'arrive_time': nft.get('start_time', 0) + nft.get('estimated_time', 0),
                    'price': nft.get('price', 0),
                    'capacity': nft.get('capacity', 1),
                    'status': 'available',
                    'nft_token_id': nft.get('token_id')
                }
                active_segments.append(segment)
            
            # Convert offers to segment format
            for offer in offers:
                # Handle both regular offers (start_time) and proactive segments (depart_time)
                origin = offer.get('origin')
                destination = offer.get('destination')
                if not origin or not destination:
                    continue
                if not isinstance(origin, (list, tuple)) or not isinstance(destination, (list, tuple)):
                    continue
                depart_time = offer.get('depart_time', offer.get('start_time', 0))
                arrive_time = offer.get('arrive_time', depart_time + offer.get('estimated_time', 0))

                segment = {
                    'segment_id': f"offer_{offer.get('offer_id', '')}",
                    'type': offer.get('type', 'offer'),  # Preserve 'segment' type for proactive segments
                    'provider_id': offer.get('provider_id'),
                    'owning_operator_id': offer.get('owning_operator_id'),
                    'operator_type': offer.get('operator_type'),
                    'mode': offer.get('mode', 'unknown'),
                    'origin': origin,
                    'destination': destination,
                    'depart_time': depart_time,
                    'arrive_time': arrive_time,
                    'duration': offer.get('estimated_time', arrive_time - depart_time),
                    'price': offer.get('price', 0),
                    'capacity': offer.get('capacity', 1),
                    'status': 'available',
                    'offer_signature': offer.get('signature'),
                    # Preserve canonical PT metadata for path-signature parity checks.
                    'route_id': offer.get('route_id'),
                    'segment_index': offer.get('segment_index'),
                    'origin_station': offer.get('origin_station'),
                    'destination_station': offer.get('destination_station'),
                    'corridor_id': offer.get('corridor_id'),
                    'zone_id': offer.get('zone_id'),
                    'service_scope': offer.get('service_scope'),
                }
                active_segments.append(segment)
            
            self.logger.info(f"Retrieved {len(active_segments)} active segments from blockchain")
            return active_segments
            
        except Exception as e:
            self.logger.error(f"Error getting active segments: {e}")
            return []
    
    def build_segment_graph(self, segments: List[Dict]):
        """
        Build a directed graph of segments for route finding with robust coordinate parsing.
        Graph structure: origin_location -> [(destination_location, segment_data)]
        """
        self.segment_graph.clear()
        self.segment_index.clear()

        skipped = 0
        success_count = 0

        # Debug: show sample raw origin type to diagnose format issues
        if segments:
            first_seg = segments[0]
            self.logger.info(f"DEBUG: Sample Raw Segment Origin: {first_seg.get('origin')} (Type: {type(first_seg.get('origin'))})")

        for segment in segments:
            origin = self._parse_coordinate(segment.get('origin'))
            destination = self._parse_coordinate(segment.get('destination'))

            if not origin or not destination:
                skipped += 1
                continue

            try:
                segment_id = segment.get('segment_id', 'unknown')
                self.segment_graph[origin].append((destination, segment))
                self.segment_index[segment_id] = segment
                success_count += 1
            except Exception as e:
                self.logger.warning(f"Skipping segment due to unexpected error: {e}")
                skipped += 1
                continue

        self._inject_canonical_transfer_edges()
        # v8 parity_audit Arm B3 (Route C wiring): the router-side canonical PT
        # injection was superseded by shadow-provider publication in the model.
        # Old router injection remains callable via V8_D_CANONICAL_ROUTER_INJECT=1
        # for A/B comparison but should not be enabled in production runs.
        if os.environ.get("V8_D_CANONICAL_ROUTER_INJECT", "0") == "1":
            self._inject_canonical_pt_ride_edges()
        self.logger.info(f"Built segment graph: {len(self.segment_graph)} nodes, {success_count} edges loaded. (Skipped {skipped} invalid/malformed)")
    
    def build_bundles(
        self,
        origin: List[float],
        destination: List[float],
        active_segments: List[Dict],
        start_time: int,
        max_transfers: int = 3,
        time_tolerance: int = 5,
        walk_radius: float = 10.0,
    ) -> List[Dict]:
        """
        DECENTRALIZED: Build bundle options using distributed graph traversal
        
        Each commuter independently assembles routes from available segments.
        No central coordinator - pure peer-to-peer discovery.
        
        Args:
            origin: Starting location [x, y]
            destination: Target location [x, y]
            active_segments: Available segments from blockchain
            start_time: Desired departure tick
            max_transfers: Maximum number of segments in bundle
            time_tolerance: Acceptable time deviation (ticks)
            walk_radius: First/last-mile walk connection radius for graph stitching
            
        Returns:
            List of bundle options, each containing:
                - bundle_id: Unique identifier
                - segments: List of segment dictionaries
                - total_price: Sum of segment prices
                - total_duration: Total travel time
                - num_transfers: Number of mode changes
                - utility_score: Calculated utility
        """
        # Build graph from available segments
        self.build_segment_graph(active_segments)

        # Inject virtual walk edges for first/last mile to connect origins/destinations to network
        origin_tuple = (round(origin[0]), round(origin[1]))
        destination_tuple = (round(destination[0]), round(destination[1]))
        self._inject_walk_edges(origin_tuple, destination_tuple, start_time, radius=walk_radius)

        # Find all possible paths using depth-first search
        self.logger.info(f"🔍 Searching for paths from {origin_tuple} to {destination_tuple}")
        self.logger.info(f"   Graph has {len(self.segment_graph)} origin nodes")
        self.logger.info(
            f"   Start time: {start_time}, Max transfers: {max_transfers}, "
            f"Time tolerance: {time_tolerance}, Walk radius: {walk_radius}"
        )

        # Log sample graph nodes
        if self.segment_graph:
            sample_nodes = list(self.segment_graph.items())[:5]
            self.logger.info(f"   Sample graph nodes:")
            for node_origin, edges in sample_nodes:
                self.logger.info(f"     {node_origin} -> {len(edges)} edges to {[dest for dest, _ in edges]}")

        # Check if origin is in graph or nearby
        nearby_origins = [node for node in self.segment_graph.keys()
                         if self._is_close_enough(origin_tuple, node, threshold=4.0)]
        self.logger.info(f"   Found {len(nearby_origins)} nodes near origin: {nearby_origins[:5]}")

        all_paths = self._find_all_paths(
            origin_tuple,
            destination_tuple,
            start_time,
            max_transfers,
            time_tolerance
        )

        self.logger.info(f"   Found {len(all_paths)} valid paths")
        
        # Convert paths to bundle format
        bundles = []
        for path_segments in all_paths:
            bundle = self._create_bundle_from_path(path_segments, origin, destination, start_time)
            if bundle:
                bundles.append(bundle)
        
        # Sort by utility score (highest first)
        bundles.sort(key=lambda b: b.get('utility_score', 0), reverse=True)
        
        self.logger.info(f"Built {len(bundles)} bundle options for {origin} -> {destination}")
        return bundles
    
    def _find_all_paths(
        self,
        current: Tuple[float, float],
        destination: Tuple[float, float],
        current_time: int,
        max_depth: int,
        time_tolerance: int,
        current_path: List[Dict] = None,
        visited: Set[Tuple] = None
    ) -> List[List[Dict]]:
        """
        Recursive depth-first search to find all valid paths
        
        This is the core decentralized routing algorithm - no central coordinator needed
        """
        if current_path is None:
            current_path = []
        if visited is None:
            visited = set()
        
        # Base case: reached destination
        # Use larger threshold to account for grid-aligned segments (3-unit grid)
        if self._is_close_enough(current, destination, threshold=4.0):
            return [current_path] if current_path else []
        
        # Base case: max depth reached
        if len(current_path) >= max_depth:
            return []
        
        # Mark current location as visited
        visited.add(current)
        
        all_paths = []

        # Explore all outgoing segments from current location AND nearby locations
        # This allows matching even when origin/destination don't exactly align with grid
        nearby_segments = []

        # Check exact location first
        nearby_segments.extend(self.segment_graph.get(current, []))

        # For first segment only, also check nearby grid points
        if len(current_path) == 0:
            # Check nearby grid points (within 4 units) for starting segments (3-unit grid)
            for node_loc in self.segment_graph.keys():
                if node_loc != current and self._is_close_enough(current, node_loc, threshold=4.0):
                    nearby_segments.extend(self.segment_graph.get(node_loc, []))

        # Track rejections for debugging (only for first call)
        rejections = {'visited': 0, 'time_early': 0, 'time_late': 0, 'status': 0, 'explored': 0}

        # Explore all found segments
        for next_location, segment in nearby_segments:
            # Skip if already visited (avoid cycles)
            if next_location in visited:
                rejections['visited'] += 1
                continue

            # Check time compatibility
            # For first segment: must depart at or after start time
            # For subsequent segments: must depart after previous arrival (with tolerance for waiting)
            # Walk segments: allow immediate departure; set arrival based on duration
            segment_for_path = segment
            # v8 parity_audit Arm B3: canonical PT ride fallback segments are
            # injected with depart_time=0. Treat them like walk (always
            # available at current tick) so the time filter doesn't reject.
            if segment.get('mode') == 'walk' or segment.get('type') == 'canonical_pt':
                duration = segment.get('duration', 1)
                segment_depart = current_time
                segment_arrive = current_time + duration
                segment_for_path = dict(segment)
                segment_for_path['depart_time'] = segment_depart
                segment_for_path['start_time'] = segment_depart
                segment_for_path['arrive_time'] = segment_arrive
            else:
                segment_depart = segment.get('depart_time', 0)
                segment_arrive = segment.get('arrive_time', segment_depart)

            if len(current_path) == 0:
                # First segment: can depart at or after start time (allow early departure within tolerance)
                if segment_depart < current_time - time_tolerance:
                    rejections['time_early'] += 1
                    continue
                # Don't depart too far in the future
                if segment_depart > current_time + time_tolerance * 2:
                    rejections['time_late'] += 1
                    continue
            else:
                # Subsequent segments: must depart after we arrive from previous segment
                # Allow waiting between segments (up to time_tolerance * 5)
                if segment_depart < current_time:
                    rejections['time_early'] += 1
                    continue
                if segment_depart > current_time + time_tolerance * 5:  # Allow longer wait for transfers
                    rejections['time_late'] += 1
                    continue

            # Check if segment is still available
            if segment.get('status') != 'available':
                rejections['status'] += 1
                continue

            rejections['explored'] += 1

            # Recursively explore from next location
            # Next time is when we ARRIVE at the next location (not current_time + duration)
            next_time = segment_arrive
            
            paths_from_here = self._find_all_paths(
                next_location,
                destination,
                next_time,
                max_depth,
                time_tolerance,
                current_path + [segment_for_path],
                visited.copy()
            )

            all_paths.extend(paths_from_here)

        # Log rejections for first-level search only
        if len(current_path) == 0 and len(nearby_segments) > 0:
            self.logger.info(f"   First-level search: {len(nearby_segments)} segments found, "
                           f"{rejections['explored']} explored, "
                           f"{rejections['visited']} visited, "
                           f"{rejections['time_early']} too early, "
                           f"{rejections['time_late']} too late, "
                           f"{rejections['status']} wrong status")

        return all_paths
    
    def _is_close_enough(self, loc1: Tuple[float, float], loc2: Tuple[float, float], threshold: float = 0.5) -> bool:
        """Check if two locations are within threshold distance"""
        distance = math.sqrt((loc1[0] - loc2[0])**2 + (loc1[1] - loc2[1])**2)
        return distance <= threshold

    def _inject_walk_edges(self, origin: Tuple[float, float], destination: Tuple[float, float], start_time: int, radius: float = 10.0):
        """
        Add virtual walk segments to connect origin/destination to nearby network nodes.
        """
        nodes = list(self.segment_graph.keys())
        for node in nodes:
            # First mile: origin -> node
            dist_o = self._distance(origin, node)
            if dist_o <= radius:
                # Walk speed 0.76 unit/step (matches centralised C-model walk speed);
                # replaces the previous *3 which was ~4x too slow and inflated PT trips.
                duration = max(1, int(round(dist_o / 0.76)))
                walk_seg = {
                    'segment_id': f"walk_{origin}_{node}",
                    'type': 'walk',
                    'provider_id': 'walk',
                    'mode': 'walk',
                    'origin': origin,
                    'destination': node,
                    'depart_time': start_time,
                    'arrive_time': start_time + duration,
                    'duration': duration,
                    'price': 0,
                    'capacity': 9999,
                    'status': 'available'
                }
                self.segment_graph[origin].append((node, walk_seg))

            # Last mile: node -> destination
            dist_d = self._distance(node, destination)
            if dist_d <= radius:
                # Walk speed 0.76 unit/step (see _inject_walk_edges above).
                duration = max(1, int(round(dist_d / 0.76)))
                walk_seg = {
                    'segment_id': f"walk_{node}_{destination}",
                    'type': 'walk',
                    'provider_id': 'walk',
                    'mode': 'walk',
                    'origin': node,
                    'destination': destination,
                    'depart_time': start_time,  # will be overridden by DFS timing logic for walk
                    'arrive_time': start_time + duration,
                    'duration': duration,
                    'price': 0,
                    'capacity': 9999,
                    'status': 'available'
                }
                self.segment_graph[node].append((destination, walk_seg))

    def _distance(self, a: Tuple[float, float], b: Tuple[float, float]) -> float:
        return math.sqrt((a[0] - b[0])**2 + (a[1] - b[1])**2)

    def _inject_canonical_transfer_edges(self):
        """
        Add canonical station-transfer walk edges so bundle routing can traverse
        the same transfer links as shared_pt_router without minting tickets.
        """
        model = getattr(self.blockchain, "model", None)
        transfers = getattr(model, "transfers", None)
        stations = getattr(model, "stations", None)
        if not transfers or not stations:
            return

        station_lookup = {}
        for mode in ("train", "bus"):
            for station_id, xy in stations.get(mode, {}).items():
                station_lookup[station_id] = xy

        added = 0
        for (origin_station, destination_station), transfer_time in transfers.items():
            origin_xy = station_lookup.get(origin_station)
            dest_xy = station_lookup.get(destination_station)
            if not origin_xy or not dest_xy:
                continue
            origin = self._parse_coordinate(origin_xy)
            dest = self._parse_coordinate(dest_xy)
            if not origin or not dest:
                continue
            transfer_seg = {
                'segment_id': f"transfer_{origin_station}_{destination_station}",
                'type': 'transfer',
                'provider_id': 'walk',
                'mode': 'walk',
                'origin': origin,
                'destination': dest,
                'origin_station': origin_station,
                'destination_station': destination_station,
                'depart_time': 0,
                'arrive_time': float(transfer_time),
                'duration': float(transfer_time),
                'price': 0,
                'capacity': 9999,
                'status': 'available'
            }
            self.segment_graph[origin].append((dest, transfer_seg))
            added += 1
        if added:
            self.logger.info(f"Injected {added} canonical PT transfer edges")

    def _inject_canonical_pt_ride_edges(self):
        """v8 parity_audit Arm B3 (Sydney): see Rep bundle_router for docstring."""
        model = getattr(self.blockchain, "model", None)
        stations = getattr(model, "stations", None)
        routes = getattr(model, "routes", None)
        if not model or not stations or not routes:
            return
        world_settings = getattr(model, "world_settings", None)
        price_factor = 1.0
        if resolve_pt_price_factor is not None:
            try:
                price_factor = resolve_pt_price_factor(world_settings=world_settings)
            except Exception:
                price_factor = 1.0

        added = 0
        for mode in ("train", "bus"):
            station_map = stations.get(mode, {}) or {}
            route_map = routes.get(mode, {}) or {}
            for route_id, station_seq in route_map.items():
                coords = [station_map.get(sid) for sid in station_seq]
                for i in range(len(coords) - 1):
                    a = coords[i]; b = coords[i + 1]
                    if not a or not b:
                        continue
                    origin_xy = (float(a[0]), float(a[1]))
                    dest_xy = (float(b[0]), float(b[1]))
                    duration = float(PT_IN_VEHICLE_PER_HOP)
                    if compute_pt_segment_fare is not None:
                        try:
                            price = compute_pt_segment_fare(
                                mode=mode,
                                origin_xy=origin_xy,
                                destination_xy=dest_xy,
                                depart_step=0,
                                price_factor=price_factor,
                            )
                        except Exception:
                            price = 2.5 if mode == "bus" else 3.0
                    else:
                        price = 2.5 if mode == "bus" else 3.0
                    for direction, o_xy, d_xy, o_sid, d_sid in (
                        ("F", origin_xy, dest_xy, station_seq[i], station_seq[i + 1]),
                        ("R", dest_xy, origin_xy, station_seq[i + 1], station_seq[i]),
                    ):
                        seg = {
                            'segment_id': f"CANON_{mode.upper()}_{route_id}_{direction}_{i}",
                            'type': 'canonical_pt',
                            'provider_id': 'canonical',
                            'mode': mode,
                            'origin': [o_xy[0], o_xy[1]],
                            'destination': [d_xy[0], d_xy[1]],
                            'origin_station': o_sid,
                            'destination_station': d_sid,
                            'route_id': route_id,
                            'segment_index': i,
                            'direction': direction,
                            'depart_time': 0,
                            'arrive_time': duration,
                            'duration': duration,
                            'estimated_time': duration,
                            'price': float(price),
                            'capacity': 999999,
                            'status': 'available',
                        }
                        self.segment_graph[o_xy].append((d_xy, seg))
                        added += 1
        if added:
            self.logger.info(f"Injected {added} canonical PT ride fallback edges (Arm B3)")

    def _create_bundle_from_path(self, segments: List[Dict], origin: List[float], destination: List[float], start_time: int) -> Optional[Dict]:
        """
        Create a bundle dictionary from a path of segments
        """
        if not segments:
            return None
        
        # Calculate bundle metrics with walk/wait disutility
        total_price = sum(seg.get('price', 0) for seg in segments)
        total_duration = segments[-1].get('arrive_time', 0) - segments[0].get('depart_time', 0)
        num_transfers = len(segments) - 1

        walk_time = 0
        wait_time = 0
        in_vehicle_time = 0

        # First wait: ready at start_time
        first_depart = segments[0].get('depart_time', 0)
        wait_time += max(0, first_depart - start_time)

        for i, seg in enumerate(segments):
            duration = seg.get('duration', 0)
            if seg.get('mode') == 'walk':
                walk_time += duration
            else:
                in_vehicle_time += duration

            if i > 0:
                prev_arrive = segments[i - 1].get('arrive_time', 0)
                curr_depart = seg.get('depart_time', 0)
                wait_time += max(0, curr_depart - prev_arrive)

        # Apply multi-modal discount (5% per additional segment, max 15%)
        discount_rate = min(0.15, num_transfers * 0.05)
        discounted_price = total_price * (1 - discount_rate)

        # V9 §1.4.2 (STOP #4 work-item 1): under the neutral spec the bundle /
        # assembled-PT price is the composite Opal CARD fare, not the per-hop
        # segment sum (which repeats the base fare per hop and applies the
        # Layer-B multi-modal discount). This is the fix for the D public PFD
        # residual: the segment-assembly path (`segment_sum_bundle`) was the one
        # PT price path never wired to compute_pt_journey_fare (§1.4.1 only
        # wired the direct-offer path). Legacy path (flag unset) is untouched.
        if os.environ.get("V9_NEUTRAL_SPEC", "").strip().lower() in ("1", "true", "yes", "on"):
            try:
                from shared_fare_card import compute_bundle_card_price
                discounted_price = compute_bundle_card_price(segments)
                total_price = discounted_price  # no multi-modal discount under neutral
            except Exception:
                pass

        # Calculate utility score (lower is better: price + time penalty)
        weighted_time = in_vehicle_time + (walk_time * 2.5) + (wait_time * 2.0)
        time_penalty = weighted_time * 0.5  # Value of time proxy
        utility_score = -(discounted_price + time_penalty)  # Negative for sorting

        # Generate unique bundle ID
        bundle_id = self._generate_bundle_id(segments)

        return {
            'bundle_id': bundle_id,
            'segments': segments,
            'total_price': discounted_price,
            'original_price': total_price,
            'bundle_discount': total_price - discounted_price,
            'total_duration': total_duration,
            'num_transfers': num_transfers,
            'num_segments': len(segments),
            'utility_score': utility_score,
            'expected_depart_time': segments[0].get('depart_time', 0),
            'expected_arrive_time': segments[-1].get('arrive_time', 0),
            'modes': [seg.get('mode') for seg in segments],
            'walk_time': walk_time,
            'wait_time': wait_time,
            'in_vehicle_time': in_vehicle_time
        }
    
    def _generate_bundle_id(self, segments: List[Dict]) -> str:
        """Generate unique bundle ID from segment composition"""
        segment_ids = [seg.get('segment_id', '') for seg in segments]
        bundle_str = '_'.join(sorted(segment_ids))
        return hashlib.md5(bundle_str.encode()).hexdigest()[:16]

    def _parse_coordinate(self, coord) -> Optional[Tuple[int, int]]:
        """
        Robust coordinate parser handling lists, tuples, and string representations.
        Returns a rounded (x, y) tuple or None if parsing fails.
        """
        if coord is None:
            return None

        try:
            # Already list/tuple
            if isinstance(coord, (list, tuple)):
                if len(coord) >= 2:
                    return (round(float(coord[0])), round(float(coord[1])))

            # String representation: "[10, 20]" or "10,20" etc.
            if isinstance(coord, str):
                clean = coord.replace('[', '').replace(']', '').replace('(', '').replace(')', '')
                parts = [float(x.strip()) for x in clean.split(',') if x.strip() != '']
                if len(parts) >= 2:
                    return (round(parts[0]), round(parts[1]))
        except (ValueError, TypeError, AttributeError):
            return None

        return None
