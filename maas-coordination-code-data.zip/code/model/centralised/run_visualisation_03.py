import os
import sys
# Sydney_Run layout: code/centralised/ -> shared modules in ../shared, network in ../network.
# Bootstrap sys.path FIRST so downstream `from agent_...` imports can resolve
# their `shared_*` transitive dependencies.
_HERE = os.path.dirname(os.path.abspath(__file__))
_SHARED_DIR = os.path.abspath(os.path.join(_HERE, "..", "shared"))
_NETWORK_DIR = os.path.abspath(os.path.join(_HERE, "..", "network"))
for _p in (_SHARED_DIR, _NETWORK_DIR):
    if _p not in sys.path:
        sys.path.insert(0, _p)
REPO_ROOT = _SHARED_DIR  # backward-compat name

from mesa.visualization.modules import CanvasGrid
from mesa.visualization.ModularVisualization import ModularServer
from mesa.visualization.modules import TextElement
from mesa import Model
from mesa.space import MultiGrid
from mesa.time import RandomActivation
from mesa import Agent
from agent_service_provider_03 import ServiceProvider
from agent_commuter_03 import Commuter
from agent_MaaS_03 import MaaS
from sqlalchemy.orm import sessionmaker, scoped_session
from agent_service_provider_initialisation_03 import reset_database
import uuid
import random
import math
import numpy as np
from sqlalchemy import create_engine, func, text
from sqlalchemy.orm import sessionmaker
import time
import gc
import traceback
import argparse

from shared_experiment_config import (
    RANDOM_SEED,
    SIMULATION_STEPS,
    GRID_WIDTH,
    GRID_HEIGHT,
    NUM_COMMUTERS,
    SMALL_WORLD_P,
    PT_IN_VEHICLE_PER_HOP,
)
from shared_topology_v2 import build_subcentre_hubs, get_small_world_map
from shared_pt_router import (
    pt_route_time_between_points,
    get_pt_router_stats,
    reset_pt_router_stats,
)
from shared_trip_generator import generate_two_trip_day, trip_stream_fingerprint
from shared_results_schema import append_run_record_jsonl, write_request_comparison_csv
from shared_comparison_metrics import (
    summarize_mode_share_by_income,
    summarize_price_by_income_group,
    summarize_travel_time_by_income,
)
from shared_operator_heterogeneity import resolve_s1_variant, transform_centralized_price_overrides
from shared_cross_world_runtime import (
    load_world_settings,
    resolve_background_traffic_amount,
    resolve_num_commuters,
    resolve_pt_in_vehicle_time_factor,
    resolve_pt_price_factor,
    resolve_pt_wait_time_factor,
    scale_direct_capacity,
    scale_direct_price,
)
from shared_phase4_central_burden import (
    DEFAULT_CENTRAL_BURDEN_VARIANT,
    build_subsidy_pool_config,
    resolve_central_burden_variant,
)
from shared_matching_validation import (
    compute_full_demand_trip_fingerprint,
    count_planned_trips,
    default_matching_validation_path,
    summarize_income_distribution,
    write_matching_validation_artifact,
)
from shared_frozen_inputs import (
    group_trips_by_canonical_commuter,
    load_fixed_commuters,
    load_fixed_trip_requests,
)

from database_01 import income_weights, \
        health_weights, payment_weights, age_distribution, disability_weights, \
        tech_access_weights,DYNAMIC_MAAS_SURCHARGE_BASE_COEFFICIENTS, DB_CONNECTION_STRING, \
        CONGESTION_ALPHA,CONGESTION_BETA, CONGESTION_CAPACITY, CONGESTION_T_IJ_FREE_FLOW, \
        ASC_VALUES, UTILITY_FUNCTION_HIGH_INCOME_CAR_COEFFICIENTS, \
        UTILITY_FUNCTION_BASE_COEFFICIENTS, PENALTY_COEFFICIENTS, \
        AFFORDABILITY_THRESHOLDS, FLEXIBILITY_ADJUSTMENTS, \
        VALUE_OF_TIME, public_price_table, ALPHA_VALUES, BACKGROUND_TRAFFIC_AMOUNT,\
        UberLike1_cpacity, UberLike1_price, \
        UberLike2_cpacity, UberLike2_price, \
        BikeShare1_capacity, BikeShare1_price, \
        BikeShare2_capacity, BikeShare2_price, \
        subsidy_dataset, daily_config,weekly_config,monthly_config
from sqlalchemy import create_engine
from agent_service_provider_initialisation_03 import CommuterInfoLog, ServiceBookingLog
import json
class StationAgent(Agent):
    def __init__(self, unique_id, model, location, mode):
        super().__init__(unique_id, model)
        self.location = location
        self.mode = mode

    def step(self):
        pass


def _coerce_subsidy_amount(raw_subsidy):
    if raw_subsidy in (None, ""):
        return 0.0
    if isinstance(raw_subsidy, (int, float)):
        return float(raw_subsidy)
    if isinstance(raw_subsidy, dict):
        for key in ("amount", "subsidy_amount", "government_subsidy", "value"):
            value = raw_subsidy.get(key)
            if value not in (None, ""):
                try:
                    return float(value)
                except (TypeError, ValueError):
                    continue
        return 0.0
    try:
        return float(raw_subsidy)
    except (TypeError, ValueError):
        return 0.0


def _net_user_price(total_price, raw_subsidy):
    if total_price is None:
        return None
    return max(float(total_price) - _coerce_subsidy_amount(raw_subsidy), 0.0)


def _maas_time_from_station_path(maas_agent, station_path):
    if not station_path or len(station_path) <= 1:
        return 0.0

    total = 0.0
    for u, v in zip(station_path, station_path[1:]):
        transfer_key = (u, v)
        if transfer_key in maas_agent.transfers:
            total += float(maas_agent.transfers[transfer_key])
        else:
            total += PT_IN_VEHICLE_PER_HOP
    return total


def parity_test_pt_router(maas_agent, sw, grid_w, grid_h, seed=42, n=20, tol=1e-6):
    rnd = random.Random(seed)
    worst = 0.0
    worst_case = None
    checked = 0
    attempts = 0
    max_attempts = n * 20

    while checked < n and attempts < max_attempts:
        attempts += 1
        origin = (rnd.randint(0, grid_w - 1), rnd.randint(0, grid_h - 1))
        dest = (rnd.randint(0, grid_w - 1), rnd.randint(0, grid_h - 1))

        shared = pt_route_time_between_points(
            origin,
            dest,
            sw.stations,
            sw.routes,
            sw.transfers,
            in_vehicle_per_hop=PT_IN_VEHICLE_PER_HOP,
        )
        if not shared.station_path or math.isinf(shared.total_time):
            continue

        maas_path = maas_agent.find_optimal_route(origin, dest)
        if not maas_path:
            continue
        t_maas = _maas_time_from_station_path(maas_agent, maas_path)
        t_shared = shared.total_time

        err = abs(t_maas - t_shared)
        if err > worst:
            worst = err
            worst_case = (origin, dest, t_maas, t_shared)
        checked += 1

    print(f"[PT PARITY][CENTRALISED] checked={checked}, worst_abs_error={worst}")
    if worst_case:
        print("[PT PARITY][CENTRALISED] worst_case:", worst_case)
    assert checked >= n, f"PT parity insufficient OD coverage: {checked} < {n}"
    assert worst <= tol, f"PT routing mismatch too large: {worst} > {tol}"

class MobilityModel(Model):
    def __init__(self, db_connection_string, num_commuters, grid_width, grid_height, data_income_weights , \
                 data_health_weights, data_payment_weights, data_age_distribution,\
                data_disability_weights, data_tech_access_weights, \
                ASC_VALUES, UTILITY_FUNCTION_HIGH_INCOME_CAR_COEFFICIENTS, \
                UTILITY_FUNCTION_BASE_COEFFICIENTS, PENALTY_COEFFICIENTS, \
                AFFORDABILITY_THRESHOLDS, FLEXIBILITY_ADJUSTMENTS, VALUE_OF_TIME,\
                public_price_table, ALPHA_VALUES,\
                DYNAMIC_MAAS_SURCHARGE_BASE_COEFFICIENTS, \
                BACKGROUND_TRAFFIC_AMOUNT, CONGESTION_ALPHA,\
                CONGESTION_BETA, CONGESTION_CAPACITY, CONGESTION_T_IJ_FREE_FLOW, \
                uber_like1_capacity, uber_like1_price, 
                uber_like2_capacity, uber_like2_price, 
                 bike_share1_capacity, bike_share1_price, 
                 bike_share2_capacity, bike_share2_price, 
                 subsidy_dataset,subsidy_config,schema=None, run_seed=RANDOM_SEED,
                 pt_price_factor=1.0,
                 pt_wait_time_factor=1.0,
                 pt_in_vehicle_time_factor=1.0,
                 fixed_commuters_path=None, fixed_trip_requests_path=None):
        self.db_engine = create_engine(db_connection_string)
        self.schema = schema
        
        # If schema is provided, set it in the session
        if self.schema:
            self.engine = create_engine(db_connection_string)
            with self.engine.connect() as connection:
                connection.execute(text(f"SET search_path TO {self.schema}"))
        self.Session = scoped_session(sessionmaker(bind=self.db_engine))
        self.session = self.Session()
        # Step 1: Reset the database with dynamic parameters
        reset_database(self.db_engine, self.session,
                       uber_like1_capacity, uber_like1_price, 
                       uber_like2_capacity, uber_like2_price, 
                       bike_share1_capacity, bike_share1_price, 
                       bike_share2_capacity, bike_share2_price, self.schema)
        
        super().__init__()
        random.seed(run_seed)
        np.random.seed(run_seed)
        self.run_seed = run_seed
        reset_pt_router_stats()
        if num_commuters != NUM_COMMUTERS:
            print(
                f"Using fixed-input/world commuter count={num_commuters} "
                f"instead of canonical NUM_COMMUTERS={NUM_COMMUTERS}"
            )
        if grid_width != GRID_WIDTH or grid_height != GRID_HEIGHT:
            print(
                f"Overriding grid={grid_width}x{grid_height} with canonical "
                f"GRID_WIDTH={GRID_WIDTH}, GRID_HEIGHT={GRID_HEIGHT}"
            )
        num_commuters = int(num_commuters)
        grid_width = GRID_WIDTH
        grid_height = GRID_HEIGHT
        self.db_connection_string = db_connection_string

        self.grid = MultiGrid(grid_width, grid_height, torus=False)
        self.schedule = RandomActivation(self)


        self.num_commuters = num_commuters
        self.grid_width = grid_width
        self.grid_height = grid_height
        self.simulation_steps = SIMULATION_STEPS
        self.data_income_weights = data_income_weights
        self.data_health_weights = data_health_weights
        self.data_payment_weights = data_payment_weights
        self.data_age_distribution = data_age_distribution
        self.data_disability_weights = data_disability_weights
        self.data_tech_access_weights = data_tech_access_weights
        self.subsidy_config = subsidy_config
        ##################################################################################
        ################# Initialisation for the commuter agent###########################
        ##################################################################################
        self.asc_values = ASC_VALUES
        self.utility_function_high_income_car_coefficients = UTILITY_FUNCTION_HIGH_INCOME_CAR_COEFFICIENTS
        self.utility_function_base_coefficients = UTILITY_FUNCTION_BASE_COEFFICIENTS
        self.penalty_coefficients = PENALTY_COEFFICIENTS
        self.affordability_thresholds = AFFORDABILITY_THRESHOLDS
        self.flexibility_adjustments = FLEXIBILITY_ADJUSTMENTS
        self.value_of_time = VALUE_OF_TIME
        ###################################################################################
        ################### Initialisation for ServiceProvider Agent ######################
        ###################################################################################
        self.alpha_values = ALPHA_VALUES
        self.public_price_table = public_price_table
        self.pt_price_factor = float(pt_price_factor)
        self.pt_wait_time_factor = float(pt_wait_time_factor)
        self.pt_in_vehicle_time_factor = float(pt_in_vehicle_time_factor)
        self.service_provider_agent = ServiceProvider(unique_id='service_provider_1', model=self, \
                                                      db_connection_string=db_connection_string,\
                                                    ALPHA_VALUES = self.alpha_values, \
                                                    public_price_table=self.public_price_table,schema=self.schema)
        self.schedule.add(self.service_provider_agent)
        # #######################################################################################
        # Initialize current_step to 0
        self.current_step = 0
        self.total_canonical_requests_emitted = 0
        self.trace_targets = self._load_trace_targets()
        self.trace_output_path = os.getenv("TRACE_OUTPUT_JSONL")
        self.traced_canonical_trip_ids = set()

        sw = get_small_world_map(
            p_shortcut=SMALL_WORLD_P,
            seed=RANDOM_SEED,
            grid_width=GRID_WIDTH,
            grid_height=GRID_HEIGHT,
        )
        self.sw = sw
        print("CENTRALISED MAP FINGERPRINT:", sw.meta["fingerprint"])
        expected_fingerprint = os.getenv("EXPECTED_MAP_FINGERPRINT")
        if expected_fingerprint:
            assert sw.meta["fingerprint"] == expected_fingerprint, (
                f"Fingerprint mismatch: expected {expected_fingerprint}, got {sw.meta['fingerprint']}"
            )
        self.hubs = self._build_hubs_from_canonical_map(sw.stations)
        self.trip_plans = {}
        self._emitted_trip_ids = set()
        self.fixed_commuters_path = os.path.abspath(fixed_commuters_path) if fixed_commuters_path else None
        self.fixed_trip_requests_path = os.path.abspath(fixed_trip_requests_path) if fixed_trip_requests_path else None
        self.fixed_inputs_enabled = bool(self.fixed_commuters_path or self.fixed_trip_requests_path)
        self.fixed_commuters_payload = None
        self.fixed_trip_requests_payload = None
        self.fixed_commuters_fingerprint = None
        self.fixed_trip_requests_fingerprint = None
        self.trip_fingerprint_commuters_checked = min(
            self.num_commuters,
            int(os.getenv("TRIP_FINGERPRINT_COMMUTERS", "20")),
        )
        if self.fixed_commuters_path:
            self.fixed_commuters_payload = load_fixed_commuters(
                self.fixed_commuters_path,
                expected_count=self.num_commuters,
                grid_width=self.grid_width,
                grid_height=self.grid_height,
            )
            self.fixed_commuters_fingerprint = self.fixed_commuters_payload["fingerprint"]
            expected_commuter_fp = os.getenv("EXPECTED_FIXED_COMMUTERS_FINGERPRINT")
            if expected_commuter_fp:
                assert self.fixed_commuters_fingerprint == expected_commuter_fp, (
                    f"Fixed commuter fingerprint mismatch: expected {expected_commuter_fp}, "
                    f"got {self.fixed_commuters_fingerprint}"
                )
        expected_trip_commuters = (
            {
                spec.canonical_commuter_id
                for spec in self.fixed_commuters_payload["commuters"]
            }
            if self.fixed_commuters_payload
            else set(range(self.num_commuters))
        )
        if self.fixed_trip_requests_path:
            self.fixed_trip_requests_payload = load_fixed_trip_requests(
                self.fixed_trip_requests_path,
                expected_commuter_ids=expected_trip_commuters,
                grid_width=self.grid_width,
                grid_height=self.grid_height,
                simulation_steps=self.simulation_steps,
            )
            self.fixed_trip_requests_fingerprint = self.fixed_trip_requests_payload["fingerprint"]
            self.trip_fingerprint_commuters_checked = len(expected_trip_commuters)
            trip_fp = self.fixed_trip_requests_fingerprint
            print("CENTRALISED FIXED TRIP FINGERPRINT:", trip_fp)
            expected_trip_fp = os.getenv("EXPECTED_FIXED_TRIP_REQUESTS_FINGERPRINT") or os.getenv("EXPECTED_TRIP_FINGERPRINT")
            if expected_trip_fp:
                assert trip_fp == expected_trip_fp, (
                    f"Trip fingerprint mismatch: expected {expected_trip_fp}, got {trip_fp}"
                )
        else:
            trip_fp = trip_stream_fingerprint(
                base_seed=RANDOM_SEED,
                grid_w=self.grid_width,
                grid_h=self.grid_height,
                hubs=self.hubs,
                commuters=self.trip_fingerprint_commuters_checked,
                day_index=0,
            )
            print("CENTRALISED TRIP STREAM FINGERPRINT:", trip_fp)
            expected_trip_fp = os.getenv("EXPECTED_TRIP_FINGERPRINT")
            if expected_trip_fp:
                assert trip_fp == expected_trip_fp, (
                    f"Trip fingerprint mismatch: expected {expected_trip_fp}, got {trip_fp}"
                )
        self.trip_stream_fingerprint = trip_fp

        # Add station agents
        for mode, mode_stations in sw.stations.items():
            for station_id, (x, y) in mode_stations.items():
                station_agent = StationAgent(unique_id=f"{mode}_{station_id}", model=self, location=(x, y), mode=mode)
                self.grid.place_agent(station_agent, (x, y))
                self.schedule.add(station_agent)

        self.commuter_agents = []
        self.commuter_canonical_index = {}
        income_levels = ['low', 'middle', 'high']

        # Define health statuses and their respective weights
        health_statuses = ['good', 'poor']

        # Define payment schemes and their respective weights
        payment_schemes = ['PAYG', 'subscription']

        # Define age distribution based on the provided data
        age_distribution = self.data_age_distribution
        # Calculate cumulative weights for age distribution
        cumulative_age_weights = []
        current_weight = 0
        for age_range, weight in age_distribution.items():
            current_weight += weight
            cumulative_age_weights.append((age_range, current_weight))

        def get_random_age():
            rnd = random.random()
            for age_range, cumulative_weight in cumulative_age_weights:
                if rnd <= cumulative_weight:
                    return random.randint(age_range[0], age_range[1])
            return random.randint(0, 70)  # Fallback in case of any issues

        commuter_specs = None
        if self.fixed_commuters_payload:
            commuter_specs = self.fixed_commuters_payload["commuters"]

        for i in range(num_commuters):
            if commuter_specs is not None:
                spec = commuter_specs[i]
                canonical_commuter_id = spec.canonical_commuter_id
                income_level = spec.income_level
                health_status = spec.health_status
                payment_scheme = spec.payment_scheme
                age = spec.age
                has_disability = spec.has_disability
                tech_access = spec.tech_access
                commuter_location = tuple(spec.initial_location)
            else:
                canonical_commuter_id = i
                income_level = random.choices(income_levels, self.data_income_weights)[0]
                health_status = random.choices(health_statuses, self.data_health_weights)[0]
                payment_scheme = random.choices(payment_schemes, self.data_payment_weights)[0]
                age = get_random_age()
                has_disability = random.choices([True, False], self.data_disability_weights)[0]
                tech_access = random.choices([True, False], self.data_tech_access_weights)[0]
                commuter_location = (
                    random.randint(0, self.grid_width - 1),
                    random.randint(0, self.grid_height - 1),
                )

            commuter = Commuter(
                unique_id=i + 2,
                model=self,
                commuter_location=commuter_location,
                age=age,
                income_level=income_level,
                has_disability=has_disability,
                tech_access=tech_access,
                health_status=health_status,
                payment_scheme=payment_scheme,
                ASC_VALUES = self.asc_values,
                UTILITY_FUNCTION_HIGH_INCOME_CAR_COEFFICIENTS = self.utility_function_high_income_car_coefficients,
                UTILITY_FUNCTION_BASE_COEFFICIENTS = self.utility_function_base_coefficients, 
                PENALTY_COEFFICIENTS = self.penalty_coefficients,
                AFFORDABILITY_THRESHOLDS=self.affordability_thresholds,
                FLEXIBILITY_ADJUSTMENTS = self.flexibility_adjustments,
                VALUE_OF_TIME = self.value_of_time,
                subsidy_dataset = subsidy_dataset
            )
            self.commuter_agents.append(commuter)
            self.commuter_canonical_index[commuter.unique_id] = canonical_commuter_id
            self.schedule.add(commuter)
            self.grid.place_agent(commuter, commuter.location)
            self.record_commuter_info(commuter)  # Record commuter info in the database
        self._build_canonical_trip_plans()
        ####################################################################################
        ################### Initialisation for the MaaS agent #############################
        ####################################################################################
        self.congestion_alpha= CONGESTION_ALPHA
        self.congestion_beta= CONGESTION_BETA
        self.congestion_capacity = CONGESTION_CAPACITY
        self.conjestion_t_ij_free_flow = CONGESTION_T_IJ_FREE_FLOW
        self.dynamic_maas_surcharge_base_coefficient = DYNAMIC_MAAS_SURCHARGE_BASE_COEFFICIENTS
        self.background_traffic_amount = BACKGROUND_TRAFFIC_AMOUNT
        self.maas_agent = MaaS(unique_id="maas_1", model=self, \
                               service_provider_agent=self.service_provider_agent, \
                                commuter_agents=self.commuter_agents,\
                                DYNAMIC_MAAS_SURCHARGE_BASE_COEFFICIENTS = self.dynamic_maas_surcharge_base_coefficient , \
                                BACKGROUND_TRAFFIC_AMOUNT = self.background_traffic_amount,\
                                stations = sw.stations, routes = sw.routes, \
                                transfers = sw.transfers, num_commuters = self.num_commuters, \
                                grid_width = self.grid_width, grid_height = self.grid_height, \
                                CONGESTION_ALPHA = self.congestion_alpha,\
                                CONGESTION_BETA= self.congestion_beta, \
                                CONGESTION_CAPACITY = self.congestion_capacity, \
                                CONGESTION_T_IJ_FREE_FLOW = self.conjestion_t_ij_free_flow,\
                                subsidy_config = self.subsidy_config,schema=self.schema)
        self.schedule.add(self.maas_agent)

        parity_n = int(os.getenv("PT_PARITY_N", "20"))
        parity_tol = float(os.getenv("PT_PARITY_TOL", "1e-6"))
        parity_test_pt_router(
            maas_agent=self.maas_agent,
            sw=sw,
            grid_w=self.grid_width,
            grid_h=self.grid_height,
            seed=self.run_seed,
            n=parity_n,
            tol=parity_tol,
        )
        
        

    def record_commuter_info(self, commuter):
        new_commuter_info = CommuterInfoLog(
            commuter_id=commuter.unique_id,
            location=commuter.location,
            age=commuter.age,
            income_level=commuter.income_level,
            has_disability=1 if commuter.has_disability else 0,  # Convert boolean to integer
            tech_access=1 if commuter.tech_access else 0,  # Convert boolean to integer
            health_status=commuter.health_status,
            payment_scheme=commuter.payment_scheme
        )
        with self.Session() as session:
            existing_commuter = session.query(CommuterInfoLog).filter_by(
                commuter_id=commuter.unique_id
            ).first()
            if existing_commuter:
                print(f"Commuter {commuter.unique_id} already exists in the database. Skipping insert.")
            else:
                session.add(new_commuter_info)
                session.commit()
                #print(f"Commuter {commuter.unique_id} info recorded successfully.")


    def update_commuter_info_log(self, commuter):
        """
        Updates the commuter information in the database, including requests and services_owned.
        UUIDs in requests and services_owned will be converted to strings to ensure proper JSON serialization.
        """

        # Convert UUIDs to strings for requests and services_owned before saving
        requests_with_str_keys = {str(k): {**v, 'request_id': str(v['request_id'])} for k, v in commuter.requests.items()}
        services_owned_with_str_keys = {str(k): v for k, v in commuter.services_owned.items()}

        with self.Session() as session:
            # Fetch the commuter's current info from the log
            commuter_log = session.query(CommuterInfoLog).filter_by(commuter_id=commuter.unique_id).first()

            # If the commuter log doesn't exist, create a new entry
            if not commuter_log:
                commuter_log = CommuterInfoLog(
                    commuter_id=commuter.unique_id,  # Use commuter.unique_id directly
                    location={'x': commuter.location[0], 'y': commuter.location[1]},
                    age=commuter.age,
                    income_level=commuter.income_level,
                    has_disability=1 if commuter.has_disability else 0,
                    tech_access=1 if commuter.tech_access else 0,
                    health_status=commuter.health_status,
                    payment_scheme=commuter.payment_scheme,
                    requests=str(requests_with_str_keys),  # Convert UUIDs to strings in requests
                    services_owned=str(services_owned_with_str_keys)  # Convert UUIDs to strings in services_owned
                )
                session.add(commuter_log)
            else:
                # Update the existing commuter log entry
                commuter_log.location = str({'x': commuter.location[0], 'y': commuter.location[1]})
                commuter_log.requests = str(requests_with_str_keys)  # Update requests with converted UUIDs
                commuter_log.services_owned = str(services_owned_with_str_keys)  # Update services_owned with converted UUIDs

            # Commit the session to save changes
            session.commit()


    def check_is_peak(self, current_ticks):
        if (36 <= current_ticks % 144 < 60) or (90 <= current_ticks % 144 < 114):
            return True
        return False

    def _build_hubs_from_canonical_map(self, stations):
        return build_subcentre_hubs(
            stations,
            grid_width=self.grid_width,
            grid_height=self.grid_height,
        )

    def _build_canonical_trip_plans(self):
        # Canonical trip IDs use a stable commuter index (0..N-1), not internal agent IDs.
        if self.fixed_trip_requests_payload:
            grouped = group_trips_by_canonical_commuter(
                self.fixed_trip_requests_payload["trip_requests"]
            )
            self.trip_plans = {}
            for commuter in self.commuter_agents:
                canonical_idx = self.commuter_canonical_index.get(commuter.unique_id, 0)
                self.trip_plans[commuter.unique_id] = list(grouped.get(canonical_idx, []))
            return
        days = max(1, (self.simulation_steps + 143) // 144)
        self.trip_plans = {}
        for commuter in self.commuter_agents:
            canonical_idx = self.commuter_canonical_index.get(commuter.unique_id, 0)
            plans = []
            for day_idx in range(days):
                t0, t1 = generate_two_trip_day(
                    base_seed=RANDOM_SEED,
                    commuter_id=canonical_idx,
                    grid_w=self.grid_width,
                    grid_h=self.grid_height,
                    hubs=self.hubs,
                    day_index=day_idx,
                )
                plans.extend([t0, t1])
            self.trip_plans[commuter.unique_id] = plans

    def _emit_canonical_trip_if_due(self, commuter, current_step):
        plans = self.trip_plans.get(commuter.unique_id, [])
        for trip in plans:
            if trip.trip_id in self._emitted_trip_ids:
                continue
            if current_step == trip.depart_step:
                request_id = trip.trip_id
                commuter.create_request(
                    request_id=trip.trip_id,
                    origin=trip.origin_xy,
                    destination=trip.dest_xy,
                    start_time=trip.depart_step,
                    travel_purpose=trip.purpose,
                )
                if request_id in commuter.requests:
                    commuter.requests[request_id]["canonical_trip_id"] = trip.trip_id
                self._emitted_trip_ids.add(trip.trip_id)
                return True
        return False

    def _load_trace_targets(self):
        raw = os.getenv("TRACE_CANONICAL_TRIPS", "").strip()
        if not raw:
            return set()
        return {item.strip() for item in raw.split(",") if item.strip()}

    def _find_segment_index(self, mode, route_id, from_station, to_station):
        seq = self.sw.routes.get(mode, {}).get(route_id, [])
        for i in range(len(seq) - 1):
            if seq[i] == from_station and seq[i + 1] == to_station:
                return i
            if seq[i] == to_station and seq[i + 1] == from_station:
                return i
        return None

    def _pt_signature_from_itinerary(self, itinerary):
        signature = []
        if not isinstance(itinerary, list):
            return signature
        for segment in itinerary:
            if not isinstance(segment, (list, tuple)) or not segment:
                continue
            seg_type = segment[0]
            if seg_type in ("bus", "train") and len(segment) >= 3:
                route_id = segment[1]
                stops = segment[2] or []
                for a, b in zip(stops, stops[1:]):
                    seg_idx = self._find_segment_index(seg_type, route_id, a, b)
                    signature.append((route_id, seg_idx, a, b))
            elif seg_type == "transfer" and len(segment) >= 2 and len(segment[1]) >= 2:
                signature.append(("XFER", None, segment[1][0], segment[1][1]))
        return signature

    def _pt_signature_from_shared_legs(self, legs):
        signature = []
        for leg in legs:
            if leg.get("type") == "transfer":
                signature.append(("XFER", None, leg.get("from"), leg.get("to")))
                continue
            mode = leg.get("mode")
            route_id = leg.get("route_id")
            if mode in ("bus", "train") and route_id:
                seg_idx = self._find_segment_index(mode, route_id, leg.get("from"), leg.get("to"))
                signature.append((route_id, seg_idx, leg.get("from"), leg.get("to")))
        return signature

    def _emit_trace_record(self, record):
        payload = json.dumps(record, sort_keys=True)
        print(f"[TRACE][CENTRALISED] {payload}")
        if self.trace_output_path:
            try:
                with open(self.trace_output_path, "a", encoding="utf-8") as fh:
                    fh.write(payload + "\n")
            except Exception as exc:
                print(f"[TRACE][CENTRALISED][WARN] failed to write trace file: {exc}")

    def _trace_selected_request(self, commuter, request_id):
        request = commuter.requests.get(request_id)
        if not request:
            return
        canonical_trip_id = request.get("canonical_trip_id")
        if not canonical_trip_id:
            return
        if self.trace_targets and canonical_trip_id not in self.trace_targets:
            return
        if canonical_trip_id in self.traced_canonical_trip_ids:
            return
        if request.get("status") != "Service Selected":
            return

        selected_route = request.get("selected_route") or {}
        selected_itinerary = selected_route.get("route")
        chosen_signature = self._pt_signature_from_itinerary(selected_itinerary)

        shared = pt_route_time_between_points(
            tuple(request["origin"]),
            tuple(request["destination"]),
            self.sw.stations,
            self.sw.routes,
            self.sw.transfers,
            in_vehicle_per_hop=PT_IN_VEHICLE_PER_HOP,
        )
        shared_signature = self._pt_signature_from_shared_legs(shared.legs)

        record = {
            "event_type": "TRIP_EXECUTION_START",
            "system": "centralised",
            "seed": int(self.run_seed),
            "step": int(self.current_step),
            "commuter_id": int(commuter.unique_id),
            "canonical_trip_id": canonical_trip_id,
            "request_id": str(request_id),
            "origin": request.get("origin"),
            "destination": request.get("destination"),
            "depart_step": int(request.get("start_time", -1)),
            "chosen_option_mode": selected_route.get("mode"),
            "chosen_total_time": selected_route.get("time"),
            "chosen_total_cost": selected_route.get("price"),
            "shared_pt_total_time": shared.total_time,
            "shared_pt_signature": shared_signature,
            "chosen_pt_signature": chosen_signature,
            "pt_signature_match": chosen_signature == shared_signature if chosen_signature else None,
        }
        enforce_trace_gate = (
            canonical_trip_id in self.trace_targets
            and str(os.getenv("TRACE_ASSERT_SIGNATURE", "1")).strip().lower() not in ("0", "false", "no")
            and selected_route.get("mode") in ("public_route", "MaaS_Bundle")
        )
        if enforce_trace_gate:
            assert chosen_signature == shared_signature, (
                f"Centralised signature drift for {canonical_trip_id}: "
                f"chosen={chosen_signature} shared={shared_signature}"
            )
        self._emit_trace_record(record)
        self.traced_canonical_trip_ids.add(canonical_trip_id)

    def should_create_trip(self, commuter, current_step):
        """
        Determines if a commuter should create a new trip based on their travel history,
        time of day, demographics, and payment scheme.
        
        Returns:
            bool: True if a new trip should be created, False otherwise
        """
        # Get time context
        ticks_in_day = 144
        current_day_tick = current_step % ticks_in_day
        current_day = current_step // ticks_in_day
        day_of_week = current_day % 7  # 0-4 weekday, 5-6 weekend
        is_weekend = day_of_week >= 5
        
        # Count trips in the current day
        trips_in_current_day = sum(1 for request in commuter.requests.values() 
                                if request['start_time'] // ticks_in_day == current_day)
        
        # Determine the current time period
        if 36 <= current_day_tick < 60:  # 6:30am-10am
            time_period = 'morning_peak'
        elif 60 <= current_day_tick < 90:  # 10am-3pm
            time_period = 'midday'
        elif 90 <= current_day_tick < 114:  # 3pm-7pm
            time_period = 'evening_peak'
        elif 114 <= current_day_tick < 126:  # 7pm-9pm
            time_period = 'evening'
        else:  # Overnight
            time_period = 'night'
        
        # Count trips in the current time period (same day)
        if time_period == 'morning_peak':
            trips_in_period = sum(1 for request in commuter.requests.values() 
                                if request['start_time'] // ticks_in_day == current_day 
                                and 36 <= request['start_time'] % ticks_in_day < 60)
        elif time_period == 'evening_peak':
            trips_in_period = sum(1 for request in commuter.requests.values() 
                                if request['start_time'] // ticks_in_day == current_day 
                                and 90 <= request['start_time'] % ticks_in_day < 114)
        else:
            # For other periods, just check within a 24-tick window (4 hours)
            period_start = max(0, current_day_tick - 12)
            period_end = min(ticks_in_day - 1, current_day_tick + 12)
            trips_in_period = sum(1 for request in commuter.requests.values() 
                                if request['start_time'] // ticks_in_day == current_day 
                                and period_start <= request['start_time'] % ticks_in_day < period_end)
        
        # Base daily limits depending on payment scheme and demographics
        if commuter.payment_scheme == 'subscription':
            base_daily_limit = 8  # Subscription users make more trips
        else:  # PAYG
            base_daily_limit = 6
        
        # Demographic adjustments
        if commuter.income_level == 'high':
            base_daily_limit += 2  # High income makes more trips
        elif commuter.income_level == 'low':
            base_daily_limit -= 1  # Low income makes fewer trips
        
        if commuter.age >= 65 or commuter.has_disability:
            base_daily_limit -= 1  # Older/disabled people may make fewer trips
        
        # Weekend adjustments
        if is_weekend:
            # Fewer trips on weekends, especially for work commuters
            base_daily_limit = max(3, base_daily_limit - 2)
        
        # Determine max trips per time period
        if time_period == 'morning_peak' or time_period == 'evening_peak':
            # During peak, allow more trips for commuters with subscription
            if commuter.payment_scheme == 'subscription':
                period_limit = 3
            else:
                period_limit = 2
        elif time_period == 'midday':
            # Some commuters may do multiple midday trips (lunch, meetings)
            period_limit = 2
        elif time_period == 'evening':
            # Evening activities
            period_limit = 2
        else:  # night
            # Fewer trips at night
            period_limit = 1
        
        # Check if commuter is already traveling (has active non-finished trips)
        has_active_travel = any(request['status'] not in ['finished', 'expired'] 
                            for request in commuter.requests.values())
        if has_active_travel:
            return False  # Can't start a new trip while already traveling
        
        # Special case: If commuter hasn't made any trips yet today, 
        # always allow at least one trip
        if trips_in_current_day == 0:
            # But consider time of day - most people start their day in morning
            if time_period == 'morning_peak' or (is_weekend and time_period == 'midday'):
                return True
            elif time_period == 'night':
                # Very few trips start during night
                return random.random() < 0.1
            else:
                # Some probability of starting first trip later in the day
                return random.random() < 0.4
        
        # Check against limits
        return (trips_in_current_day < base_daily_limit and 
                trips_in_period < period_limit)

    def all_requests_finished(self, commuter):
        return all(request['status'] in ['finished', 'expired'] for request in commuter.requests.values())

    def create_time_based_trip(self, current_step, commuter):
        """Create trip requests with realistic timing patterns based on time of day and commuter attributes"""
        
        # Only create new trips if commuter isn't already traveling
        if not commuter.requests or self.all_requests_finished(commuter):
            # Skip if daily trip limit reached
            if not self.should_create_trip(commuter, current_step):
                return False
                
            # Get time of day context (144 ticks = 1 day, tick 0 = midnight)
            ticks_in_day = 144
            current_day_tick = current_step % ticks_in_day
            current_day = current_step // ticks_in_day
            day_of_week = current_day % 7  # 0-4 weekday, 5-6 weekend
            is_weekend = day_of_week >= 5
            
            # Baseline probabilities influenced by demographics
            base_probability = 0.05
            
            # Income level adjustments (higher income = more trips)
            if commuter.income_level == 'high':
                base_probability *= 1.5
            elif commuter.income_level == 'low':
                base_probability *= 0.8
                
            # Age/disability adjustments
            if commuter.age >= 65 or commuter.has_disability:
                base_probability *= 0.7
                
            # PAYG vs Subscription adjustments
            if commuter.payment_scheme == 'subscription':
                base_probability *= 1.3
                
            # Time of day probability distribution (using normal curves around peak times)
            time_multiplier = 1.0
            
            # Morning peak (centered at 8am = tick 48)
            if not is_weekend:
                morning_peak_center = 48
                morning_intensity = math.exp(-0.5 * ((current_day_tick - morning_peak_center) / 8) ** 2)
                
                # Evening peak (centered at 5:30pm = tick 105)
                evening_peak_center = 105
                evening_intensity = math.exp(-0.5 * ((current_day_tick - evening_peak_center) / 10) ** 2)
                
                # Combine the peaks
                time_multiplier = max(morning_intensity * 3.0, evening_intensity * 2.5, 0.2)
            else:
                # Weekend pattern (midday peak)
                midday_peak_center = 72  # Noon
                midday_intensity = math.exp(-0.5 * ((current_day_tick - midday_peak_center) / 16) ** 2)
                time_multiplier = midday_intensity * 1.5
            
            # Final probability
            trip_probability = base_probability * time_multiplier
            
            # Decide whether to create a trip
            if random.random() < trip_probability:
                # Determine trip purpose based on time of day
                if not is_weekend and current_day_tick < 60:  # Morning on weekday
                    purpose_weights = {'work': 0.7, 'school': 0.2, 'shopping': 0.05, 'medical': 0.03, 'leisure': 0.02}
                elif not is_weekend and current_day_tick >= 90 and current_day_tick < 114:  # Evening on weekday
                    purpose_weights = {'work': 0.1, 'school': 0.05, 'shopping': 0.3, 'leisure': 0.5, 'medical': 0.05}
                elif is_weekend:  # Weekend
                    purpose_weights = {'shopping': 0.4, 'leisure': 0.4, 'medical': 0.05, 'work': 0.1, 'school': 0.05}
                else:  # Middle of weekday
                    purpose_weights = {'work': 0.2, 'school': 0.1, 'shopping': 0.3, 'medical': 0.2, 'leisure': 0.2}
                
                # Select purpose based on weights
                purposes = list(purpose_weights.keys())
                weights = list(purpose_weights.values())
                travel_purpose = random.choices(purposes, weights=weights)[0]
                
                # Generate destination based on purpose
                origin = commuter.location
                destination = self.get_purpose_based_destination(travel_purpose, origin, commuter)
                
                # Set trip timing - more realistic start time distribution
                # Most people don't plan trips exactly at current time - add a buffer
                min_delay = 1
                max_delay = 5
                
                if travel_purpose in ['work', 'school'] and current_day_tick < 30:
                    # Early morning work/school trips might be planned further ahead
                    max_delay = 4
                    
                start_time = current_step + min_delay + random.randint(0, max_delay)
                
                # Double-check that the start_time is valid before creating the request
                if start_time > current_step + 5:
                    # If somehow we ended up with a time too far ahead, adjust it
                    start_time = current_step + 5
                # Create the request
                request_id = uuid.uuid4()
                commuter.create_request(request_id, origin, destination, start_time, travel_purpose)
                return True
            
            return False

    def get_purpose_based_destination(self, purpose, origin, commuter):
        """Generate a realistic destination based on trip purpose"""
        
        # Avoid very short trips
        min_distance = 5
        
        if purpose == 'work' or purpose == 'school':
            # Work trips tend to be to specific locations - can be far away from home
            # Higher income might have longer commutes to specialized jobs
            if commuter.income_level == 'high':
                distance_factor = 0.7  # Can travel farther
            else:
                distance_factor = 0.5
                
            # Get a destination with preference toward business/office districts
            # For simplicity, let's say central areas (middle of grid) are business districts
            grid_center_x = self.grid_width // 2
            grid_center_y = self.grid_height // 2
            
            # Generate with bias toward center
            while True:
                # Biased random point toward center
                x_offset = random.normalvariate(0, self.grid_width * distance_factor)
                y_offset = random.normalvariate(0, self.grid_height * distance_factor)
                
                dest_x = min(max(0, int(grid_center_x + x_offset)), self.grid_width - 1)
                dest_y = min(max(0, int(grid_center_y + y_offset)), self.grid_height - 1)
                destination = (dest_x, dest_y)
                
                # Check if it's far enough away
                distance = math.sqrt((destination[0] - origin[0])**2 + (destination[1] - origin[1])**2)
                if distance >= min_distance:
                    break
            
            return destination
            
        elif purpose == 'shopping':
            # Shopping destinations are often in specific areas like malls or centers
            # Let's say there are a few shopping centers scattered around
            
            # Simple approach - just use a few preset locations
            shopping_centers = [
                (self.grid_width // 4, self.grid_height // 4),
                (self.grid_width // 4, 3 * self.grid_height // 4),
                (3 * self.grid_width // 4, self.grid_height // 4),
                (3 * self.grid_width // 4, 3 * self.grid_height // 4),
                (self.grid_width // 2, self.grid_height // 2)
            ]
            
            # Find closest and furthest shopping centers
            distances = [math.sqrt((center[0] - origin[0])**2 + (center[1] - origin[1])**2) 
                        for center in shopping_centers]
            centers_by_distance = [center for _, center in sorted(zip(distances, shopping_centers))]
            
            # People typically go to reasonably close shopping centers, not always the very closest
            # nor the furthest
            if len(centers_by_distance) >= 3:
                # Skip the very closest and furthest
                choice_centers = centers_by_distance[1:-1]
                return random.choice(choice_centers)
            else:
                return random.choice(shopping_centers)
        
        elif purpose == 'leisure':
            # Leisure trips can be to parks, entertainment venues
            # For simplicity, let's say there are some leisure areas in the outer regions
            
            # Generate a point biased toward edges
            while True:
                if random.random() < 0.5:
                    # Bias toward edges on x-axis
                    x = random.choice([random.randint(0, self.grid_width // 4),
                                    random.randint(3 * self.grid_width // 4, self.grid_width - 1)])
                    y = random.randint(0, self.grid_height - 1)
                else:
                    # Bias toward edges on y-axis
                    y = random.choice([random.randint(0, self.grid_height // 4),
                                    random.randint(3 * self.grid_height // 4, self.grid_height - 1)])
                    x = random.randint(0, self.grid_width - 1)
                    
                destination = (x, y)
                
                # Check if it's far enough away
                distance = math.sqrt((destination[0] - origin[0])**2 + (destination[1] - origin[1])**2)
                if distance >= min_distance:
                    break
                    
            return destination
            
        elif purpose == 'medical':
            # Medical destinations like hospitals are specific and few
            # Let's define a few hospitals
            hospitals = [
                (self.grid_width // 2, self.grid_height // 4),
                (self.grid_width // 4, self.grid_height // 2),
                (3 * self.grid_width // 4, self.grid_height // 2)
            ]
            return random.choice(hospitals)
        
        else:
            # Fallback - completely random
            while True:
                x = random.randint(0, self.grid_width - 1)
                y = random.randint(0, self.grid_height - 1)
                destination = (x, y)
                
                # Check if it's far enough away
                distance = math.sqrt((destination[0] - origin[0])**2 + (destination[1] - origin[1])**2)
                if distance >= min_distance:
                    break
                    
            return destination
            
    def get_current_step(self):
        return self.current_step
    
    def step(self):
        self.current_step += 1
        #print(f"Step {self.current_step}")
        # Update the system's time step
        self.service_provider_agent.update_time_steps()

        availability_dict = self.service_provider_agent.initialize_availability(self.current_step - 1)
        new_requests_created_this_step = 0

        for commuter in self.commuter_agents:
            # Create new request based on commuter's needs
            #print(f"Creating new request for Commuter {commuter.unique_id} at Step {self.current_step}")
            if self._emit_canonical_trip_if_due(commuter, self.current_step):
                new_requests_created_this_step += 1
            
            # First, clean up stale requests
            for request_id, request in list(commuter.requests.items()):
                if request['status'] == 'active' and request['start_time'] < self.current_step:
                    # This request is stale - mark it as expired rather than trying to process it
                    request['status'] = 'expired'
                    if not request.get('comparison_failure_reason'):
                        request['comparison_failure_reason'] = 'expired_before_booking'
                    print(f"Marking stale request {request_id} as expired (start_time: {request['start_time']}, current_step: {self.current_step})")
                    # Add this code to update database
                    try:
                        from sqlalchemy.orm import sessionmaker
                        from agent_service_provider_initialisation_03 import ServiceBookingLog
                        
                        Session = sessionmaker(bind=self.db_engine)
                        with Session() as session:
                            # Check if this request is already in the database
                            existing = session.query(ServiceBookingLog).filter_by(
                                request_id=str(request_id)
                            ).first()
                            
                            if existing:
                                # Update existing record
                                existing.status = 'expired'
                                session.commit()
                            else:
                                # For expired requests that never got a booking, create a minimal record
                                new_record = ServiceBookingLog(
                                    commuter_id=commuter.unique_id,
                                    payment_scheme=commuter.payment_scheme,
                                    request_id=str(request_id),
                                    start_time=request['start_time'],
                                    record_company_name='none',  # No company was selected
                                    route_details={"route": "none"},  # Minimal route info
                                    total_price=0.0,
                                    maas_surcharge=0.0,
                                    total_time=0.0,
                                    origin_coordinates=request['origin'],
                                    destination_coordinates=request['destination'],
                                    status='expired'  # Mark as expired
                                )
                                session.add(new_record)
                                session.commit()
                    except Exception as e:
                        print(f"Error updating expired status in database: {e}")
            # Now process valid active requests
            for request_id, request in list(commuter.requests.items()):
                try:
                    if request['status'] == 'active' and request['start_time'] >= self.current_step:
                        # MaaS agent generates travel options for each request
                        travel_options_without_MaaS = self.maas_agent.options_without_maas(
                            request_id, request['start_time'], request['origin'], request['destination'])
                        
                        travel_options_with_MaaS = self.maas_agent.maas_options(
                            commuter.payment_scheme, request_id, request['start_time'], 
                            request['origin'], request['destination'])

                        # Process the rest as before...
                        ranked_options = commuter.rank_service_options(
                            travel_options_without_MaaS, travel_options_with_MaaS, request_id)
                        
                        if ranked_options:
                            booking_success, availability_dict = self.maas_agent.book_service(
                                request_id, ranked_options, self.current_step, availability_dict)
                            if booking_success:
                                self._trace_selected_request(commuter, request_id)
                            if not booking_success:
                                request['comparison_failure_reason'] = 'booking_failed_after_ranking'
                                print(f"Booking for request {request_id} was not successful.")
                        else:
                            request['comparison_failure_reason'] = 'no_viable_options'
                            print(f"No viable options for request {request_id}.")
                except Exception as e:
                    print(f"Error in MobilityModel processing request {request_id}: {str(e)}")
                    # Add this to help diagnose the specific request causing problems
                    print(f"Problem request details: status={request['status']}, start_time={request['start_time']}, current_step={self.current_step}")
                    
            self.update_commuter_info_log(commuter)
            commuter.update_location()
            commuter.check_travel_status()  # Once the commuter arrives at the destination, increase the availability back

        self.total_canonical_requests_emitted += new_requests_created_this_step
        if self.current_step % 10 == 0:
            print(
                f"[TRIP EMIT] step={self.current_step} "
                f"new={new_requests_created_this_step} "
                f"total={self.total_canonical_requests_emitted}"
            )

        # Update availability based on bookings
        #print(f"Updating availability after bookings")
        self.service_provider_agent.update_availability()
        # Call dynamic_pricing_share to update pricing based on demand
        #print(f"Calling dynamic pricing update")
        self.service_provider_agent.dynamic_pricing_share()
            # Probability of inserting random traffic
        # Time-varying background traffic - always insert but vary amount by time of day
        with self.Session() as session:
            #print(f"Inserting random background traffic at Step {self.current_step}")
            # Insert random traffic with a certain number of routes
            num_routes_inserted = self.maas_agent.insert_time_varying_traffic(session)
        self.schedule.step()

            
    def run_model(self, num_steps):
        if num_steps != SIMULATION_STEPS:
            print(
                f"Overriding num_steps={num_steps} with canonical "
                f"SIMULATION_STEPS={SIMULATION_STEPS}"
            )
        num_steps = SIMULATION_STEPS
        for _ in range(num_steps):
            self.step()

    def process_request(self, request):
        try:
            commuter = self.get_commuter_by_id(request.commuter_id)
            if not commuter:
                print(f"Error: Commuter {request.commuter_id} not found")
                return False
            
            # Debug income weights
            
            if not (0 <= commuter.income_level_index < len(self.data_income_weights)):
                print(f"Invalid income level index: {commuter.income_level_index}")
                return False
            
            # Rest of the processing code
        except Exception as e:
            print(f"Error in process_request: {e}")
            return False


def agent_portrayal(agent):
    portrayal = {}
    if isinstance(agent, Commuter):
        color = ""
        if agent.income_level == 'low':
            color = "green"
        elif agent.income_level == 'middle':
            color = "blue"
        else:  # high income
            color = "red"
        
        if agent.current_mode is None:
            portrayal = {"Shape": "circle", "Color": color, "Filled": "true", "r": 0.7, "Layer": 1, "text": str(agent.unique_id), "text_color": "white"}
        else:
            if agent.current_mode == 'walk':
                portrayal = {"Shape": "circle", "Color": color, "Filled": "true", "r": 0.5, "Layer": 1, "text": str(agent.unique_id), "text_color": "white"}
            elif agent.current_mode == 'bike':
                portrayal = {"Shape": "arrowHead", "Color": color, "Filled": "true","scale": 0.5,"heading_x": 0, "heading_y": 1, "Layer": 1, "text": str(agent.unique_id), "text_color": "white"}
            elif agent.current_mode == 'car':
                portrayal = {"Shape": "arrowHead", "Color": color, "Filled": "true","scale": 0.5,"heading_x": 0, "heading_y": -1, "Layer": 1, "text": str(agent.unique_id), "text_color": "white"}
            elif agent.current_mode == 'bus':
                portrayal = {"Shape": "rect", "Color": color, "Filled": "true", "w": 0.5, "h": 0.5, "Layer": 1, "text": str(agent.unique_id), "text_color": "white"}
            elif agent.current_mode == 'train':
                portrayal = {"Shape": "rect", "Color": color, "Filled": "true", "w": 0.8, "h": 0.3, "Layer": 1, "text": str(agent.unique_id), "text_color": "white"}


    elif isinstance(agent, StationAgent):
        color = "yellow" if agent.mode == 'train' else "orange"
        portrayal = {"Shape": "rect", "Color": color, "Filled": "true", "w": 0.1, "h": 0.3, "Layer": 0}
    return portrayal


class CommuteCountElement(TextElement):
    def __init__(self):
        pass

    def render(self, model):
        return (
            "Number of commuters: " + str(len(model.commuter_agents)) + "<br>" +
            "<span style='color: green;'>●</span> Low income<br>" +
            "<span style='color: blue;'>●</span> Middle income<br>" +
            "<span style='color: red;'>●</span> High income<br>" +
            "<span style='color: black;'>▲</span> Bike<br>" +
            "<span style='color: black;'>▼</span> Car<br>" +
            "<span style='color: black;'>■</span> Bus<br>" +
            "<span style='color: black;'>▭</span> Train<br>" +
            "<span style='color: black;'>●</span> Walk"
        )


def _summarize_requests_by_income(model):
    by_income = {}
    total_requests = 0
    total_matched = 0

    for commuter in model.commuter_agents:
        income = commuter.income_level
        bucket = by_income.setdefault(
            income,
            {"num_requests": 0, "num_matched": 0, "match_rate": 0.0},
        )
        requests = list(getattr(commuter, "requests", {}).values())
        matched = sum(1 for req in requests if req.get("status") == "finished")

        bucket["num_requests"] += len(requests)
        bucket["num_matched"] += matched
        total_requests += len(requests)
        total_matched += matched

    for bucket in by_income.values():
        reqs = bucket["num_requests"]
        bucket["match_rate"] = (bucket["num_matched"] / reqs) if reqs > 0 else 0.0

    return total_requests, total_matched, by_income


def _route_points(route_details):
    payload = route_details
    if payload in (None, "", {}):
        return []
    if isinstance(payload, str):
        try:
            payload = json.loads(payload)
        except Exception:
            return []
    if not isinstance(payload, list):
        return []
    points = []
    for item in payload:
        if isinstance(item, (list, tuple)) and len(item) == 2:
            try:
                points.append((int(item[0]), int(item[1])))
            except Exception:
                return []
        else:
            return []
    return points


def _central_route_congestion_adjusted_time(model, route_details, start_time, mode_name):
    if _canonicalize_request_mode(mode_name) != "car":
        return None
    points = _route_points(route_details)
    if len(points) < 2:
        return None
    maas_agent = getattr(model, "maas_agent", None)
    if maas_agent is None:
        return None
    cache_key = (int(start_time or 0), tuple(points))
    route_cache = getattr(model, "_request_export_route_time_cache", None)
    if route_cache is None:
        route_cache = {}
        model._request_export_route_time_cache = route_cache
    if cache_key in route_cache:
        return route_cache[cache_key]
    traffic_cache = getattr(model, "_request_export_traffic_volume_cache", None)
    if traffic_cache is None:
        traffic_cache = {}
        model._request_export_traffic_volume_cache = traffic_cache
    time_key = int(start_time or 0)
    if time_key not in traffic_cache:
        traffic_cache[time_key] = maas_agent.get_current_traffic_volume(time_key)
    traffic_volume = traffic_cache[time_key]
    segment_free_flow = float(getattr(maas_agent, "conjestion_t_ij_free_flow", 1.0) or 1.0)
    total = 0.0
    for start, end in zip(points, points[1:]):
        segment = (tuple(start), tuple(end))
        volume = traffic_volume.get(segment, 0)
        total += float(
            maas_agent.calculate_congested_travel_time(
                volume,
                getattr(maas_agent, "congestion_capacity", 1),
                segment_free_flow,
            )
        )
    route_cache[cache_key] = total
    return total


def _central_leg_time_components(model, leg_info, start_time):
    if not isinstance(leg_info, (list, tuple)) or len(leg_info) < 4:
        return 0.0, 0.0
    free_flow_time = float(leg_info[1] or 0.0)
    mode_name = leg_info[0]
    route_details = leg_info[3]
    congestion_adjusted = _central_route_congestion_adjusted_time(
        model,
        route_details,
        start_time,
        mode_name,
    )
    if congestion_adjusted is None:
        congestion_adjusted = free_flow_time
    return free_flow_time, float(congestion_adjusted)


def _central_booking_time_fields(model, booking_row):
    free_flow_total = float(booking_row.total_time) if booking_row.total_time is not None else None
    if free_flow_total is None:
        return {
            "free_flow_travel_time": None,
            "congestion_adjusted_travel_time": None,
            "travel_time": None,
            "scored_travel_time_basis": None,
        }

    chosen_mode = _canonicalize_request_mode(booking_row.record_company_name)
    congestion_adjusted_total = free_flow_total

    if chosen_mode == "car":
        direct_congestion = _central_route_congestion_adjusted_time(
            model,
            booking_row.route_details,
            booking_row.start_time,
            booking_row.record_company_name,
        )
        if direct_congestion is not None:
            congestion_adjusted_total = float(direct_congestion)
    elif chosen_mode == "bundle":
        access_free, access_adjusted = _central_leg_time_components(
            model,
            booking_row.to_station,
            booking_row.start_time,
        )
        egress_free_initial, _ = _central_leg_time_components(
            model,
            booking_row.to_destination,
            booking_row.start_time,
        )
        public_component = max(0.0, free_flow_total - access_free - egress_free_initial)
        egress_start = int((booking_row.start_time or 0) + access_adjusted + public_component)
        egress_free, egress_adjusted = _central_leg_time_components(
            model,
            booking_row.to_destination,
            egress_start,
        )
        public_component = max(0.0, free_flow_total - access_free - egress_free)
        congestion_adjusted_total = public_component + access_adjusted + egress_adjusted

    return {
        "free_flow_travel_time": float(free_flow_total),
        "congestion_adjusted_travel_time": float(congestion_adjusted_total),
        "travel_time": float(congestion_adjusted_total),
        "scored_travel_time_basis": "congestion_adjusted_travel_time",
    }


# V9 STOP #1(bis) fix: mode → shared-card mode mapping. Bundle is a proxy
# to ride_hail (bundle usually has a car connector); public → train (Opal
# card is train/bus/light_rail near-identical bases; train picked as canonical).
# Ported verbatim from Rep run_visualisation_03.py (v9-neutral-spec 00444a7);
# only the shared-dir sys.path target is adapted to the Sydney tree layout.
_V9_CARD_MODE_MAP = {
    "car": "ride_hail",
    "bike": "micromobility",
    "public": "train",
    "bundle": "ride_hail",
}

# Canonical direct-mode alias for `card_time_ticks_direct`.
_V9_CARD_MODE_TO_CANON = {
    "car": "car",
    "bike": "bike",
    "bundle": "car",  # bundle uses car connector time basis as its proxy
}


def _v9_compute_card_only_price(mode: str | None, origin_xy, dest_xy, depart_tick) -> float | None:
    """Layer-A card price for a booking row (non-public, non-bundle modes).

    V9 §1.4 STOP #2(bis): inputs come from the shared world publishers
    (`card_distance_units` + `card_time_ticks_direct`). NEVER re-derive
    Manhattan/time inline — that path collapses posted ≡ card_only into a
    trivial tautology. Historical signature accepted `distance_units` /
    `time_ticks`; now takes `(o, d, depart_tick)` and asks the canonical
    publisher directly.
    """
    if not mode:
        return None
    key = str(mode).strip().lower()
    card_mode = _V9_CARD_MODE_MAP.get(key)
    canon_mode = _V9_CARD_MODE_TO_CANON.get(key)
    if card_mode is None or canon_mode is None:
        return None
    try:
        import sys as _sys
        _sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "shared")))
        from shared_fare_card import (
            compute_fare as _cf,
            card_distance_units as _cdu,
            card_time_ticks_direct as _cttd,
        )
        _d = _cdu(origin_xy, dest_xy)
        _t = _cttd(canon_mode, _d, depart_tick)
        return float(_cf(card_mode, distance_units=_d, time_ticks=_t))
    except Exception:
        return None


def _v9_public_journey_legs(model, origin_xy, dest_xy) -> list | None:
    """V9 §1.4.1 analytical replay for public rows. Returns a list of journey
    legs (each: {mode, distance_units}) or None if replay fails."""
    try:
        import sys as _sys
        _sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "shared")))
        from shared_pt_router import pt_route_time_between_points
        # Stations/routes/transfers live on the MaaS agent (per MobilityModel
        # init at line ~469), not on the model itself. Fall back to model
        # attributes for tolerance to any future refactor.
        maas = getattr(model, "maas_agent", None)
        stations = getattr(maas, "stations", None) or getattr(model, "stations", None)
        routes = getattr(maas, "routes", None) or getattr(model, "routes", None)
        transfers = getattr(maas, "transfers", None) or getattr(model, "transfers", None)
        if not stations or not routes or transfers is None:
            return None
        shared = pt_route_time_between_points(
            origin_xy=tuple(origin_xy),
            dest_xy=tuple(dest_xy),
            stations=stations,
            routes=routes,
            transfers=transfers,
        )
    except Exception:
        return None
    if not shared or not shared.legs:
        return None
    # Group consecutive in_vehicle legs by (mode, route_id); tap-on = first, tap-off = last.
    def _station_xy(sid):
        for m in ("train", "bus"):
            if sid in stations.get(m, {}):
                return stations[m][sid]
        return None
    journey: list = []
    cur_mode = None
    cur_route = None
    cur_first = None
    cur_last = None
    for leg in shared.legs:
        if leg.get("type") == "transfer":
            if cur_mode is not None and cur_first is not None and cur_last is not None:
                d = ((cur_first[0] - cur_last[0]) ** 2 + (cur_first[1] - cur_last[1]) ** 2) ** 0.5
                journey.append({"mode": cur_mode, "distance_units": float(d)})
            cur_mode = None; cur_route = None; cur_first = None; cur_last = None
            continue
        mode = leg.get("mode")
        rid = leg.get("route_id")
        if mode not in ("train", "bus"):
            continue
        u = _station_xy(leg.get("from"))
        v = _station_xy(leg.get("to"))
        if u is None or v is None:
            continue
        if rid != cur_route or mode != cur_mode:
            if cur_mode is not None and cur_first is not None and cur_last is not None:
                d = ((cur_first[0] - cur_last[0]) ** 2 + (cur_first[1] - cur_last[1]) ** 2) ** 0.5
                journey.append({"mode": cur_mode, "distance_units": float(d)})
            cur_mode = mode; cur_route = rid; cur_first = u
        cur_last = v
    if cur_mode is not None and cur_first is not None and cur_last is not None:
        d = ((cur_first[0] - cur_last[0]) ** 2 + (cur_first[1] - cur_last[1]) ** 2) ** 0.5
        journey.append({"mode": cur_mode, "distance_units": float(d)})
    return journey


def _v9_card_only_public(model, origin_xy, dest_xy) -> float | None:
    """V9 §1.4.1: public card_only via analytical journey replay."""
    legs = _v9_public_journey_legs(model, origin_xy, dest_xy)
    if legs is None:
        return None
    try:
        import sys as _sys
        _sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "shared")))
        from shared_fare_card import compute_pt_journey_fare
        return float(compute_pt_journey_fare(legs))
    except Exception:
        return None


def _v9_card_only_bundle(model, origin_xy, dest_xy) -> float | None:
    """V9 §1.4.2: bundle composite card_only = PT journey fare + walk connectors.
    Under §1.4.3 unified rule, bundle connectors are WALK on both sides, so the
    connector contribution is 0 (walk has 0 base/rate/time). Returns None if
    PT replay fails."""
    legs = _v9_public_journey_legs(model, origin_xy, dest_xy)
    if legs is None:
        return None
    try:
        import sys as _sys
        _sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "shared")))
        from shared_fare_card import compute_pt_journey_fare, compute_fare
        pt_fare = float(compute_pt_journey_fare(legs))
        # Walk connector card fare = 0 (walk row in FARE_CARD is base 0, rate 0).
        # If §1.4.3 unified rule changes to car/bike connectors, extend here.
        connector_fare = 0.0
        return round(pt_fare + connector_fare, 4)
    except Exception:
        return None


def _central_booking_trip_records(model):
    with model.Session() as session:
        booking_rows = session.query(
            ServiceBookingLog.commuter_id,
            ServiceBookingLog.request_id,
            ServiceBookingLog.record_company_name,
            ServiceBookingLog.total_price,
            ServiceBookingLog.government_subsidy,
            ServiceBookingLog.total_time,
            ServiceBookingLog.status,
            ServiceBookingLog.route_details,
            ServiceBookingLog.start_time,
            ServiceBookingLog.to_station,
            ServiceBookingLog.to_destination,
            ServiceBookingLog.origin_coordinates,
            ServiceBookingLog.destination_coordinates,
        ).all()

        income_rows = session.query(
            CommuterInfoLog.commuter_id,
            CommuterInfoLog.income_level,
        ).all()

    income_by_commuter = {
        row.commuter_id: row.income_level
        for row in income_rows
    }

    trip_records = []
    for row in booking_rows:
        if row.status == "expired":
            continue
        time_fields = _central_booking_time_fields(model, row)
        _subsidy_amount = _coerce_subsidy_amount(row.government_subsidy)
        _total_price_raw = float(row.total_price) if row.total_price is not None else 0.0
        _consumer_price = _net_user_price(row.total_price, row.government_subsidy)
        _canonical_mode = _canonicalize_request_mode(row.record_company_name)
        # V9 §1.4 STOP #2(bis): card_only_price for direct-vehicle rows uses the
        # world-canonical publishers via `_v9_compute_card_only_price(mode, o, d, tick)`.
        # PT/bundle rows still use analytical journey replay. Distance / time
        # inputs are NO LONGER inline-computed here — that was the tautology.
        _mode_key = (_canonical_mode or "").strip().lower()
        if _mode_key == "public":
            _card_only = _v9_card_only_public(model, row.origin_coordinates, row.destination_coordinates)
        elif _mode_key == "bundle":
            _card_only = _v9_card_only_bundle(model, row.origin_coordinates, row.destination_coordinates)
        else:
            _card_only = _v9_compute_card_only_price(
                _canonical_mode,
                row.origin_coordinates,
                row.destination_coordinates,
                row.start_time,
            )
        _pfd = round(_consumer_price - float(_card_only), 4) if _card_only is not None else None
        trip_records.append(
            {
                "commuter_id": row.commuter_id,
                "request_id": str(row.request_id),
                "chosen_mode": _canonical_mode,
                "provider_id": row.record_company_name,
                # `price` remains the consumer-facing net price for backward
                # compatibility with V8-smoke scorers.
                "price": _consumer_price,
                # V9 §1.2b + STOP #1(bis): two-layer accounting columns.
                # `consumer_price` = what commuter paid (post-subsidy);
                # `system_net_cost` = what the system flowed (pre-subsidy);
                # `subsidy` = C's DRC subsidy contribution;
                # `card_only_price` = counterfactual Layer-A card price on
                # this row's mode/distance/time;
                # `price_formation_delta` = consumer_price − card_only_price
                # (Layer-B mechanism attribution).
                "consumer_price": _consumer_price,
                "system_net_cost": _total_price_raw,
                "subsidy": _subsidy_amount,
                "card_only_price": _card_only,
                "price_formation_delta": _pfd,
                **time_fields,
                "income_group": income_by_commuter.get(row.commuter_id),
            }
        )
    return trip_records, income_by_commuter


def _summarize_booking_metrics_from_db(model):
    """
    Build narrowed comparison metrics from the centralised booking database.
    """
    trip_records, income_by_commuter = _central_booking_trip_records(model)
    durations = [
        record["travel_time"]
        for record in trip_records
        if record.get("travel_time") is not None
    ]

    return {
        "avg_travel_time": (sum(durations) / len(durations)) if durations else None,
        "p95_travel_time": float(np.percentile(durations, 95)) if durations else None,
        "total_system_travel_time": sum(durations) if durations else None,
        "mode_share_by_income": summarize_mode_share_by_income(
            [
                {
                    "commuter_id": record["commuter_id"],
                    "mode": record["chosen_mode"],
                    "price": record["price"],
                    "duration": record["travel_time"],
                }
                for record in trip_records
            ],
            income_by_commuter,
        ),
        "travel_time_by_income": summarize_travel_time_by_income(
            [
                {
                    "commuter_id": record["commuter_id"],
                    "mode": record["chosen_mode"],
                    "price": record["price"],
                    "duration": record["travel_time"],
                }
                for record in trip_records
            ],
            income_by_commuter,
        ),
        "price_by_income_group": summarize_price_by_income_group(
            [
                {
                    "commuter_id": record["commuter_id"],
                    "mode": record["chosen_mode"],
                    "price": record["price"],
                    "duration": record["travel_time"],
                }
                for record in trip_records
            ],
            income_by_commuter,
        ),
    }


def _canonicalize_request_mode(raw_mode):
    if raw_mode is None:
        return None
    mode = str(raw_mode).strip()
    lower = mode.lower()
    if "maas" in lower or "bundle" in lower:
        return "bundle"
    if lower in {"public", "public_route"} or "bus" in lower or "train" in lower:
        return "public"
    if "walk" in lower:
        return "walk"
    if "bike" in lower:
        return "bike"
    if "uberlike" in lower or lower == "car":
        return "car"
    return lower


def _build_request_level_rows(model):
    trip_records, _ = _central_booking_trip_records(model)
    booking_by_key = {
        (int(record["commuter_id"]), str(record["request_id"])): record
        for record in trip_records
    }

    def _summarise_options(request):
        """Count distinct (mode, company) offer-equivalents and operator/mode
        counts for the centralised option set. Mirrors what D's competition_rows
        records (offer_count / operator_count / operator_type_count).

        travel_options_without_maas stores keys like '{mode}_{company}_price' for
        shared-mode (car, bike) offers plus 'public_price' for the PT itinerary.
        travel_options_with_maas is a list of MaaS bundle combinations.
        """
        offers = set()
        operators = set()
        mode_types = set()
        opts_no_maas = request.get("travel_options_without_maas") or {}
        if isinstance(opts_no_maas, dict):
            for key in opts_no_maas:
                if not isinstance(key, str) or not key.endswith("_price"):
                    continue
                stem = key[: -len("_price")]
                if stem == "public":
                    offers.add(("public", "public_transit"))
                    operators.add("public_transit")
                    mode_types.add("public")
                else:
                    parts = stem.rsplit("_", 1)
                    if len(parts) == 2:
                        mode, company = parts
                    else:
                        mode, company = stem, stem
                    offers.add((mode, company))
                    operators.add(company)
                    mode_types.add(mode)
        opts_maas = request.get("travel_options_with_maas") or []
        if isinstance(opts_maas, list):
            for i, _ in enumerate(opts_maas):
                offers.add(("bundle", f"MaaS_Bundle_{i}"))
            if opts_maas:
                operators.add("MaaS_Bundle")
                mode_types.add("bundle")
        return len(offers), len(operators), len(mode_types)

    rows = []
    for commuter in sorted(getattr(model, "commuter_agents", []), key=lambda item: int(item.unique_id)):
        requests = getattr(commuter, "requests", {}) or {}
        for request in sorted(
            requests.values(),
            key=lambda item: (int(item.get("start_time", 0)), str(item.get("request_id"))),
        ):
            request_id = str(request.get("request_id"))
            booking = booking_by_key.get((int(commuter.unique_id), request_id))
            offer_count, operator_count, mode_type_count = _summarise_options(request)
            if booking:
                rows.append(
                    {
                        "request_id": request_id,
                        "commuter_id": int(commuter.unique_id),
                        "income_group": commuter.income_level,
                        "model": "centralised",
                        "outcome": "success",
                        "chosen_mode": booking["chosen_mode"],
                        "free_flow_travel_time": booking["free_flow_travel_time"],
                        "congestion_adjusted_travel_time": booking["congestion_adjusted_travel_time"],
                        "travel_time": booking["travel_time"],
                        "scored_travel_time_basis": booking["scored_travel_time_basis"],
                        "price": booking["price"],
                        "failure_reason": None,
                        "bundle_used": booking["chosen_mode"] == "bundle",
                        "operator_usage": booking.get("provider_id") or booking["chosen_mode"],
                        "operator_type": booking["chosen_mode"],
                        "provider_id": booking.get("provider_id") or "",
                        "failure_stage": None,
                        "candidate_bundle_count": None,
                        "request_offer_count": offer_count or None,
                        "operator_count_seen": operator_count or None,
                        "mode_type_count_seen": mode_type_count or None,
                        # V9 §1.2b + STOP #1(bis) two-layer accounting passthrough.
                        "consumer_price": booking.get("consumer_price"),
                        "system_net_cost": booking.get("system_net_cost"),
                        "subsidy": booking.get("subsidy"),
                        "card_only_price": booking.get("card_only_price"),
                        "price_formation_delta": booking.get("price_formation_delta"),
                    }
                )
                continue

            failure_reason = request.get("comparison_failure_reason")
            if not failure_reason and request.get("status") == "expired":
                failure_reason = "expired_before_booking"
            rows.append(
                {
                    "request_id": request_id,
                    "commuter_id": int(commuter.unique_id),
                    "income_group": commuter.income_level,
                    "model": "centralised",
                    "outcome": "fail",
                    "chosen_mode": None,
                    "free_flow_travel_time": None,
                    "congestion_adjusted_travel_time": None,
                    "travel_time": None,
                    "scored_travel_time_basis": None,
                    "price": None,
                    "failure_reason": failure_reason,
                    "bundle_used": False,
                    "operator_usage": "",
                    "operator_type": "",
                    "provider_id": "",
                    "failure_stage": failure_reason,
                    "candidate_bundle_count": None,
                    "request_offer_count": offer_count or None,
                    "operator_count_seen": operator_count or None,
                    "mode_type_count_seen": mode_type_count or None,
                }
            )

    return rows


def _build_matching_validation_record(model):
    trip_fp_commuters = getattr(
        model,
        "trip_fingerprint_commuters_checked",
        min(
            model.num_commuters,
            int(os.getenv("TRIP_FINGERPRINT_COMMUTERS", "20")),
        ),
    )
    return {
        "model_type": "centralised",
        "seed": int(getattr(model, "run_seed", RANDOM_SEED)),
        "map_fingerprint": model.sw.meta.get("fingerprint") if hasattr(model, "sw") else None,
        "sample_trip_fingerprint": getattr(model, "trip_stream_fingerprint", None),
        "trip_fingerprint_commuters_checked": trip_fp_commuters,
        "full_demand_trip_fingerprint": compute_full_demand_trip_fingerprint(
            getattr(model, "trip_plans", {})
        ),
        "planned_trip_count": count_planned_trips(getattr(model, "trip_plans", {})),
        "commuter_count": len(getattr(model, "commuter_agents", [])),
        "income_distribution": summarize_income_distribution(
            commuter.income_level for commuter in getattr(model, "commuter_agents", [])
        ),
        "shared_service_nominal_capacities": {
            "UberLike1": UberLike1_cpacity,
            "UberLike2": UberLike2_cpacity,
            "BikeShare1": BikeShare1_capacity,
            "BikeShare2": BikeShare2_capacity,
        },
        "pt_route_counts": {
            "train": len(getattr(getattr(model, "sw", None), "routes", {}).get("train", {})),
            "bus": len(getattr(getattr(model, "sw", None), "routes", {}).get("bus", {})),
        },
        "fixed_inputs_enabled": bool(getattr(model, "fixed_inputs_enabled", False)),
        "fixed_commuters_path": getattr(model, "fixed_commuters_path", None),
        "fixed_trip_requests_path": getattr(model, "fixed_trip_requests_path", None),
        "fixed_commuters_fingerprint": getattr(model, "fixed_commuters_fingerprint", None),
        "fixed_trip_requests_fingerprint": getattr(model, "fixed_trip_requests_fingerprint", None),
    }

grid = CanvasGrid(agent_portrayal, GRID_WIDTH, GRID_HEIGHT, 1500, 1500)

# engine = create_engine(DB_CONNECTION_STRING)
# Session = sessionmaker(bind=engine)

# server = ModularServer(
#     MobilityModel,
#     [grid, CommuteCountElement()],
#     "Mobility Model",
#     {'db_connection_string': DB_CONNECTION_STRING,
#     'num_commuters': num_commuters,
#     'grid_width': 55,
#     'grid_height': 55,
#     'data_income_weights': [0.5, 0.3, 0.2],
#     'data_health_weights': [0.9, 0.1],
#     'data_payment_weights': [0.8, 0.2],
#     'data_age_distribution': {(18, 25): 0.2, (26, 35): 0.3, (36, 45): 0.2, (46, 55): 0.15, (56, 65): 0.1, (66, 75): 0.05},
#     'data_disability_weights': [0.2, 0.8],
#     'data_tech_access_weights': [0.95, 0.05],
#     'subsidy_dataset': {
#             'low': {'bike': 0.1, 'car': 0.05, 'MaaS_Bundle': 0.4},
#             'middle': {'bike': 0.3, 'car': 0.01, 'MaaS_Bundle': 0.5},
#             'high': {'bike': 0.4, 'car': 0, 'MaaS_Bundle': 0.6}
#         },
#     'ASC_VALUES': {'car': 0, 'bike': 0, 'public': 0, 'walk': 0, 'maas': 0, 'default': 0},
#     'UTILITY_FUNCTION_HIGH_INCOME_CAR_COEFFICIENTS': {'beta_C': -0.05, 'beta_T': -0.06},
#     'UTILITY_FUNCTION_BASE_COEFFICIENTS': {'beta_C': -0.05, 'beta_T': -0.06, 'beta_W': -0.01, 'beta_A': -0.01, 'alpha': -0.01},
#     'PENALTY_COEFFICIENTS': {'disability_bike_walk': 0.8, 'age_health_bike_walk': 0.3, 'no_tech_access_car_bike': 0.1},
#     'AFFORDABILITY_THRESHOLDS': {'low': 25, 'middle': 85, 'high': 250},
#     'FLEXIBILITY_ADJUSTMENTS': {'low': 1.05, 'medium': 1.0, 'high': 0.95},
#     'VALUE_OF_TIME': {'low': 9.64, 'middle': 23.7, 'high': 67.2},
#     'public_price_table': {'train': {'on_peak': 2, 'off_peak': 1.5}, 'bus': {'on_peak': 1, 'off_peak': 0.8}},
#     'ALPHA_VALUES': {'UberLike1': 0.5, 'UberLike2': 0.5, 'BikeShare1': 0.5, 'BikeShare2': 0.5},
#     'DYNAMIC_MAAS_SURCHARGE_BASE_COEFFICIENTS': {'S_base': 0.08, 'alpha': 0.2, 'delta': 0.5},
#     'BACKGROUND_TRAFFIC_AMOUNT': 70,
#     'CONGESTION_ALPHA': 0.25,
#     'CONGESTION_BETA': 4,
#     'CONGESTION_CAPACITY': 4,
#     'CONGESTION_T_IJ_FREE_FLOW': 2,
#     'uber_like1_capacity': 20,
#     'uber_like1_price': 4,
#     'uber_like2_capacity': 19,
#     'uber_like2_price': 3,
#     'bike_share1_capacity': 15,
#     'bike_share1_price': 0.5,
#     'bike_share2_capacity': 12,
#     'bike_share2_price': 0.2,
#     'subsidy_dataset': subsidy_dataset,
#     'subsidy_config': daily_config}
# )

# server.port = 8521
# server.launch()

# if __name__ == "__main__":
#     model = MobilityModel(db_connection_string=DB_CONNECTION_STRING, num_commuters=num_commuters)
#     model.run_model(SIMULATION_STEPS)

# else:
#     server.launch()

# Runner Code for the MobilityModel
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run centralized MaaS ABM")
    parser.add_argument(
        "--seed",
        type=int,
        default=RANDOM_SEED,
        help=f"Run seed for stochastic components (default: {RANDOM_SEED})",
    )
    parser.add_argument(
        "--results",
        type=str,
        default=None,
        help="JSONL output path for normalized run record",
    )
    parser.add_argument(
        "--no-plots",
        action="store_true",
        help="Accepted for symmetry with decentralized runner (no effect here)",
    )
    parser.add_argument(
        "--fixed-commuters",
        type=str,
        default=os.getenv("FIXED_COMMUTERS_JSON"),
        help="Path to shared frozen commuter JSON",
    )
    parser.add_argument(
        "--fixed-trip-requests",
        type=str,
        default=os.getenv("FIXED_TRIP_REQUESTS_JSON"),
        help="Path to shared frozen trip-request JSON",
    )
    parser.add_argument(
        "--request-level-results",
        type=str,
        default=None,
        help="CSV output path for per-request comparison export",
    )
    parser.add_argument(
        "--operator-heterogeneity-variant",
        type=str,
        default=os.getenv("S1_OPERATOR_HETEROGENEITY_VARIANT"),
        help="Optional bounded S1 operator heterogeneity variant name",
    )
    parser.add_argument(
        "--world-config",
        type=str,
        default=os.getenv("CROSS_WORLD_WORLD_CONFIG_JSON"),
        help="Optional cross-world scenario config JSON for exogenous world overrides",
    )
    parser.add_argument(
        "--central-burden-variant",
        type=str,
        default=os.getenv("CENTRAL_BURDEN_VARIANT", DEFAULT_CENTRAL_BURDEN_VARIANT),
        help="Optional bounded Phase 4 central burden-relief variant id",
    )
    args = parser.parse_args()

    resolved_s1_variant = resolve_s1_variant(args.operator_heterogeneity_variant)
    resolved_central_burden_variant = resolve_central_burden_variant(args.central_burden_variant)
    world_settings = load_world_settings(args.world_config)
    fixed_commuters_payload = None
    if args.fixed_commuters:
        fixed_commuters_payload = load_fixed_commuters(
            args.fixed_commuters,
            expected_count=None,
            grid_width=GRID_WIDTH,
            grid_height=GRID_HEIGHT,
        )
    resolved_num_commuters = resolve_num_commuters(
        fixed_commuter_count=(
            fixed_commuters_payload["commuter_count"]
            if fixed_commuters_payload is not None
            else None
        ),
        world_settings=world_settings,
        fallback=NUM_COMMUTERS,
    )
    centralised_ondemand_prices = transform_centralized_price_overrides(
        {
            "UberLike1": UberLike1_price,
            "UberLike2": UberLike2_price,
            "BikeShare1": BikeShare1_price,
            "BikeShare2": BikeShare2_price,
        },
        variant=resolved_s1_variant,
    )
    centralised_ondemand_prices = {
        provider_name: scale_direct_price(price, world_settings=world_settings)
        for provider_name, price in centralised_ondemand_prices.items()
    }
    # V9 §1.2b Phase 1.3 wiring: shared neutral-supply capacity source. Mirrors Rep tree.
    _ub1_cap, _ub2_cap, _bk1_cap, _bk2_cap = (
        UberLike1_cpacity, UberLike2_cpacity, BikeShare1_capacity, BikeShare2_capacity,
    )
    if os.environ.get("V9_NEUTRAL_SPEC", "").strip().lower() in ("1", "true", "yes", "on"):
        try:
            from shared_neutral_supply import NEUTRAL_SUPPLY_SPEC as _NEUTRAL
            _car_p = _NEUTRAL["car"]["providers"]
            _bike_p = _NEUTRAL["bike"]["providers"]
            _ub1_cap = int(_car_p[0]["capacity"])
            _ub2_cap = int(_car_p[1]["capacity"])
            _bk1_cap = int(_bike_p[0]["capacity"])
            _bk2_cap = int(_bike_p[1]["capacity"])
        except Exception as _exc:
            print(f"[V9] shared_neutral_supply bind failed, keeping legacy: {_exc}")
    centralised_ondemand_capacities = {
        "UberLike1": scale_direct_capacity(_ub1_cap, world_settings=world_settings),
        "UberLike2": scale_direct_capacity(_ub2_cap, world_settings=world_settings),
        "BikeShare1": scale_direct_capacity(_bk1_cap, world_settings=world_settings),
        "BikeShare2": scale_direct_capacity(_bk2_cap, world_settings=world_settings),
    }
    background_traffic_amount = resolve_background_traffic_amount(
        world_settings=world_settings,
        baseline_amount=BACKGROUND_TRAFFIC_AMOUNT,
    )
    pt_price_factor = resolve_pt_price_factor(world_settings=world_settings)
    pt_wait_time_factor = resolve_pt_wait_time_factor(world_settings=world_settings)
    pt_in_vehicle_time_factor = resolve_pt_in_vehicle_time_factor(world_settings=world_settings)
    resolved_subsidy_config = build_subsidy_pool_config(
        daily_config.__class__,
        variant=resolved_central_burden_variant,
    )

    model = MobilityModel(
        db_connection_string=DB_CONNECTION_STRING,
        num_commuters=resolved_num_commuters,
        grid_width=GRID_WIDTH,
        grid_height=GRID_HEIGHT,
        data_income_weights=income_weights,
        data_health_weights=health_weights,
        data_payment_weights=payment_weights,
        data_age_distribution=age_distribution,
        data_disability_weights=disability_weights,
        data_tech_access_weights=tech_access_weights,
        ASC_VALUES=ASC_VALUES,
        UTILITY_FUNCTION_HIGH_INCOME_CAR_COEFFICIENTS=UTILITY_FUNCTION_HIGH_INCOME_CAR_COEFFICIENTS,
        UTILITY_FUNCTION_BASE_COEFFICIENTS=UTILITY_FUNCTION_BASE_COEFFICIENTS,
        PENALTY_COEFFICIENTS=PENALTY_COEFFICIENTS,
        AFFORDABILITY_THRESHOLDS=AFFORDABILITY_THRESHOLDS,
        FLEXIBILITY_ADJUSTMENTS=FLEXIBILITY_ADJUSTMENTS,
        VALUE_OF_TIME=VALUE_OF_TIME,
        public_price_table=public_price_table,
        ALPHA_VALUES=ALPHA_VALUES,
        DYNAMIC_MAAS_SURCHARGE_BASE_COEFFICIENTS=DYNAMIC_MAAS_SURCHARGE_BASE_COEFFICIENTS,
        BACKGROUND_TRAFFIC_AMOUNT=background_traffic_amount,
        CONGESTION_ALPHA=CONGESTION_ALPHA,
        CONGESTION_BETA=CONGESTION_BETA,
        CONGESTION_CAPACITY=CONGESTION_CAPACITY,
        CONGESTION_T_IJ_FREE_FLOW=CONGESTION_T_IJ_FREE_FLOW,
        uber_like1_capacity=centralised_ondemand_capacities["UberLike1"], 
        uber_like1_price = centralised_ondemand_prices["UberLike1"], 
        uber_like2_capacity = centralised_ondemand_capacities["UberLike2"], 
        uber_like2_price = centralised_ondemand_prices["UberLike2"], 
        bike_share1_capacity = centralised_ondemand_capacities["BikeShare1"], 
        bike_share1_price = centralised_ondemand_prices["BikeShare1"], 
        bike_share2_capacity = centralised_ondemand_capacities["BikeShare2"],
        bike_share2_price = centralised_ondemand_prices["BikeShare2"], 
        subsidy_dataset = subsidy_dataset,
        subsidy_config = resolved_subsidy_config,
        run_seed=args.seed,
        pt_price_factor=pt_price_factor,
        pt_wait_time_factor=pt_wait_time_factor,
        pt_in_vehicle_time_factor=pt_in_vehicle_time_factor,
        fixed_commuters_path=args.fixed_commuters,
        fixed_trip_requests_path=args.fixed_trip_requests,
    )
    model.run_model(SIMULATION_STEPS)

    total_requests, total_matched, by_income = _summarize_requests_by_income(model)
    booking_metrics = _summarize_booking_metrics_from_db(model)
    results_path = args.results or os.getenv(
        "ABM_RESULTS_JSONL",
        os.path.join(REPO_ROOT, "abm_run_results.jsonl"),
    )
    append_run_record_jsonl(
        {
            "run_id": f"centralised_{int(time.time())}",
            "seed": int(getattr(model, "run_seed", RANDOM_SEED)),
            "model_type": "centralised",
            "map_fingerprint": model.sw.meta.get("fingerprint") if hasattr(model, "sw") else None,
            "trip_fingerprint": getattr(model, "trip_stream_fingerprint", None),
            "num_requests": total_requests,
            "num_matched": total_matched,
            "match_rate": (total_matched / total_requests) if total_requests > 0 else 0.0,
            "avg_travel_time": booking_metrics["avg_travel_time"],
            "p95_travel_time": booking_metrics["p95_travel_time"],
            "avg_wait_time": None,
            "total_system_travel_time": booking_metrics["total_system_travel_time"],
            "by_income_group": by_income,
            "mode_share_by_income": booking_metrics["mode_share_by_income"],
            "travel_time_by_income": booking_metrics["travel_time_by_income"],
            "price_by_income_group": booking_metrics["price_by_income_group"],
            "central_burden_variant": resolved_central_burden_variant["variant_id"],
            "central_burden_pool_type": resolved_central_burden_variant["pool_type"],
            "central_burden_pool_amount": resolved_central_burden_variant["pool_amount"],
        },
        results_path,
    )
    request_level_results_path = args.request_level_results or os.getenv("ABM_REQUEST_LEVEL_RESULTS_CSV")
    if request_level_results_path:
        write_request_comparison_csv(
            _build_request_level_rows(model),
            request_level_results_path,
        )
    validation_path = os.getenv(
        "ABM_MATCHING_VALIDATION_JSON",
        default_matching_validation_path(
            results_path,
            "centralised",
            int(getattr(model, "run_seed", RANDOM_SEED)),
        ),
    )
    write_matching_validation_artifact(
        _build_matching_validation_record(model),
        validation_path,
    )
    pt_router_stats = get_pt_router_stats()
    print(f"[PT ROUTER CALLS][CENTRALISED] count={pt_router_stats.get('call_count', 0)}")
    print(f"[RESULT SCHEMA] wrote run record -> {results_path}")
    if request_level_results_path:
        print(f"[REQUEST EXPORT] wrote request-level CSV -> {request_level_results_path}")
    print(f"[MATCHING VALIDATION] wrote artifact -> {validation_path}")
