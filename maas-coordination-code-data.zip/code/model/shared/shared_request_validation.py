from __future__ import annotations

from collections import Counter
from typing import Any, Iterable, Mapping

from shared_results_schema import REQUEST_COMPARISON_FIELDS


VALID_OUTCOMES = {"success", "fail"}


def validate_request_rows(
    rows: Iterable[Mapping[str, Any]],
    *,
    model_label: str,
    seed: int | None = None,
) -> list[dict[str, Any]]:
    """
    Validate normalized request-level comparison rows and return explicit
    diagnostics instead of silently dropping bad records.
    """
    diagnostics: list[dict[str, Any]] = []
    seen_keys: Counter[tuple[str, str]] = Counter()

    row_list = list(rows)
    for index, row in enumerate(row_list):
        row_seed = _as_text(row.get("seed"))
        request_id = _as_text(row.get("request_id"))
        commuter_id = _as_text(row.get("commuter_id"))
        outcome = _as_text(row.get("outcome")).lower()
        income_group = _as_text(row.get("income_group")).lower()
        chosen_mode = _as_text(row.get("chosen_mode"))
        free_flow_travel_time = row.get("free_flow_travel_time")
        congestion_adjusted_travel_time = row.get("congestion_adjusted_travel_time")
        travel_time = row.get("travel_time")
        scored_travel_time_basis = _as_text(row.get("scored_travel_time_basis"))
        price = row.get("price")

        for field in REQUEST_COMPARISON_FIELDS:
            if field not in row:
                diagnostics.append(
                    _diag(
                        model_label=model_label,
                        seed=row_seed or seed,
                        request_id=request_id,
                        issue_code="missing_required_column",
                        severity="error",
                        detail=f"missing field '{field}' in row payload",
                        row_index=index,
                    )
                )

        if not request_id:
            diagnostics.append(
                _diag(
                    model_label=model_label,
                    seed=row_seed or seed,
                    request_id=request_id,
                    issue_code="missing_request_id",
                    severity="error",
                    detail="request_id is empty",
                    row_index=index,
                )
            )

        if not commuter_id:
            diagnostics.append(
                _diag(
                    model_label=model_label,
                    seed=row_seed or seed,
                    request_id=request_id,
                    issue_code="missing_commuter_id",
                    severity="error",
                    detail="commuter_id is empty",
                    row_index=index,
                )
            )

        if outcome not in VALID_OUTCOMES:
            diagnostics.append(
                _diag(
                    model_label=model_label,
                    seed=row_seed or seed,
                    request_id=request_id,
                    issue_code="invalid_outcome",
                    severity="error",
                    detail=f"outcome='{row.get('outcome')}' is not one of {sorted(VALID_OUTCOMES)}",
                    row_index=index,
                )
            )

        if income_group not in {"low", "middle", "high"}:
            diagnostics.append(
                _diag(
                    model_label=model_label,
                    seed=row_seed or seed,
                    request_id=request_id,
                    issue_code="missing_or_invalid_income_group",
                    severity="error",
                    detail=f"income_group='{row.get('income_group')}' is invalid",
                    row_index=index,
                )
            )

        dedupe_key = (row_seed or str(seed or ""), request_id)
        seen_keys[dedupe_key] += 1

        if outcome == "success":
            if not chosen_mode:
                diagnostics.append(
                    _diag(
                        model_label=model_label,
                        seed=row_seed or seed,
                        request_id=request_id,
                        issue_code="missing_success_chosen_mode",
                        severity="error",
                        detail="served row has empty chosen_mode",
                        row_index=index,
                    )
                )
            travel_time_value = _safe_float(travel_time)
            free_flow_value = _safe_float(free_flow_travel_time)
            congestion_value = _safe_float(congestion_adjusted_travel_time)
            price_value = _safe_float(price)
            if travel_time_value is None or travel_time_value < 0:
                diagnostics.append(
                    _diag(
                        model_label=model_label,
                        seed=row_seed or seed,
                        request_id=request_id,
                        issue_code="invalid_success_travel_time",
                        severity="error",
                        detail=f"served row has invalid travel_time='{travel_time}'",
                        row_index=index,
                    )
                )
            if price_value is None or price_value < 0:
                diagnostics.append(
                    _diag(
                        model_label=model_label,
                        seed=row_seed or seed,
                        request_id=request_id,
                        issue_code="invalid_success_price",
                        severity="error",
                        detail=f"served row has invalid price='{price}'",
                        row_index=index,
                    )
                )
            if free_flow_value is None or free_flow_value < 0:
                diagnostics.append(
                    _diag(
                        model_label=model_label,
                        seed=row_seed or seed,
                        request_id=request_id,
                        issue_code="invalid_success_free_flow_travel_time",
                        severity="error",
                        detail=f"served row has invalid free_flow_travel_time='{free_flow_travel_time}'",
                        row_index=index,
                    )
                )
            if congestion_value is None or congestion_value < 0:
                diagnostics.append(
                    _diag(
                        model_label=model_label,
                        seed=row_seed or seed,
                        request_id=request_id,
                        issue_code="invalid_success_congestion_adjusted_travel_time",
                        severity="error",
                        detail=f"served row has invalid congestion_adjusted_travel_time='{congestion_adjusted_travel_time}'",
                        row_index=index,
                    )
                )
            if scored_travel_time_basis not in {
                "congestion_adjusted_travel_time",
                "free_flow_travel_time",
                "travel_time",
            }:
                diagnostics.append(
                    _diag(
                        model_label=model_label,
                        seed=row_seed or seed,
                        request_id=request_id,
                        issue_code="invalid_scored_travel_time_basis",
                        severity="error",
                        detail=f"served row has invalid scored_travel_time_basis='{row.get('scored_travel_time_basis')}'",
                        row_index=index,
                    )
                )
            basis_value = None
            if scored_travel_time_basis == "congestion_adjusted_travel_time":
                basis_value = congestion_value
            elif scored_travel_time_basis == "free_flow_travel_time":
                basis_value = free_flow_value
            elif scored_travel_time_basis == "travel_time":
                basis_value = travel_time_value
            if basis_value is not None and travel_time_value is not None and abs(basis_value - travel_time_value) > 1e-9:
                diagnostics.append(
                    _diag(
                        model_label=model_label,
                        seed=row_seed or seed,
                        request_id=request_id,
                        issue_code="travel_time_basis_mismatch",
                        severity="error",
                        detail=(
                            f"travel_time='{travel_time}' does not match "
                            f"{scored_travel_time_basis}='{row.get(scored_travel_time_basis)}'"
                        ),
                        row_index=index,
                    )
                )
        elif outcome == "fail":
            if _safe_float(free_flow_travel_time) not in (None,):
                diagnostics.append(
                    _diag(
                        model_label=model_label,
                        seed=row_seed or seed,
                        request_id=request_id,
                        issue_code="failed_row_has_free_flow_travel_time",
                        severity="warning",
                        detail=f"failed row carries free_flow_travel_time='{free_flow_travel_time}'",
                        row_index=index,
                    )
                )
            if _safe_float(congestion_adjusted_travel_time) not in (None,):
                diagnostics.append(
                    _diag(
                        model_label=model_label,
                        seed=row_seed or seed,
                        request_id=request_id,
                        issue_code="failed_row_has_congestion_adjusted_travel_time",
                        severity="warning",
                        detail=f"failed row carries congestion_adjusted_travel_time='{congestion_adjusted_travel_time}'",
                        row_index=index,
                    )
                )
            if _safe_float(travel_time) not in (None,):
                diagnostics.append(
                    _diag(
                        model_label=model_label,
                        seed=row_seed or seed,
                        request_id=request_id,
                        issue_code="failed_row_has_travel_time",
                        severity="warning",
                        detail=f"failed row carries travel_time='{travel_time}'",
                        row_index=index,
                    )
                )
            if scored_travel_time_basis:
                diagnostics.append(
                    _diag(
                        model_label=model_label,
                        seed=row_seed or seed,
                        request_id=request_id,
                        issue_code="failed_row_has_scored_travel_time_basis",
                        severity="warning",
                        detail=f"failed row carries scored_travel_time_basis='{row.get('scored_travel_time_basis')}'",
                        row_index=index,
                    )
                )
            if _safe_float(price) not in (None,):
                diagnostics.append(
                    _diag(
                        model_label=model_label,
                        seed=row_seed or seed,
                        request_id=request_id,
                        issue_code="failed_row_has_price",
                        severity="warning",
                        detail=f"failed row carries price='{price}'",
                        row_index=index,
                    )
                )

    for (row_seed, request_id), count in seen_keys.items():
        if count > 1:
            diagnostics.append(
                _diag(
                    model_label=model_label,
                    seed=row_seed or seed,
                    request_id=request_id,
                    issue_code="duplicate_request_row",
                    severity="error",
                    detail=f"found {count} rows for the same seed/request pair",
                    row_index=None,
                )
            )

    return diagnostics


def has_blocking_request_validation_errors(diagnostics: Iterable[Mapping[str, Any]]) -> bool:
    return any(str(diag.get("severity")) == "error" for diag in diagnostics)


def _diag(
    *,
    model_label: str,
    seed: Any,
    request_id: Any,
    issue_code: str,
    severity: str,
    detail: str,
    row_index: int | None,
) -> dict[str, Any]:
    return {
        "model": model_label,
        "seed": "" if seed is None else seed,
        "request_id": "" if request_id is None else request_id,
        "issue_code": issue_code,
        "severity": severity,
        "detail": detail,
        "row_index": "" if row_index is None else row_index,
    }


def _as_text(value: Any) -> str:
    return "" if value is None else str(value).strip()


def _safe_float(value: Any) -> float | None:
    text = _as_text(value)
    if text == "":
        return None
    try:
        return float(text)
    except (TypeError, ValueError):
        return None
