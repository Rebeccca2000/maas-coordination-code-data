"""Compatibility shim.

Downstream modules copied from Rep still `from shared_topology_v2 import ...`.
This module re-exports the entire public API of the new Sydney-network
`topology` module so those imports keep working without touching the copied
files.
"""
from topology import *  # noqa: F401,F403
from topology import (  # noqa: F401 — explicit re-exports for symbol tools
    GRID_WIDTH, GRID_HEIGHT, TRANSFER_TIME, DEFAULT_PT_TRAVEL_TIME,
    ZONE_BOUNDS, SUBCENTRE_DEFINITIONS,
    RAIL_ROUTE_DEFINITIONS, BUS_ROUTE_DEFINITIONS,
    ALL_ROUTE_DEFINITIONS, ROUTE_DEFINITION_BY_ID,
    NODE_WEIGHTS,
    SharedTopologyV2,
    StationsDict, RoutesDict, TransfersDict,
    get_shared_topology_v2, get_route_definition, get_small_world_map,
    get_subcentre_definitions, build_subcentre_hubs,
    get_node_subcentre_mapping, get_node_weights,
)
