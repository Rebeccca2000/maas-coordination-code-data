"""Deterministic V2 supply definitions aligned to the shared metropolitan topology.

This file defines ownership and operator profiles only. The underlying node and edge
set comes from shared_topology_v2 and must remain identical across architectures.
"""

from __future__ import annotations

from copy import deepcopy

from shared_operator_heterogeneity import resolve_s1_variant, transform_decentralized_ondemand_profiles
from shared_cross_world_runtime import (
    apply_world_scales_to_decentralized_ondemand_profiles,
    resolve_operator_niche_profile,
    resolve_pt_in_vehicle_time_factor,
    resolve_pt_wait_time_factor,
    scale_direct_capacity,
)
from shared_pt_operating_assumptions import (
    get_pt_in_vehicle_time_per_hop,
    get_pt_mode_base_fare,
    get_pt_mode_distance_rate,
)
from shared_topology_v2 import ZONE_BOUNDS, get_route_definition

GRID_WIDTH = 100
GRID_HEIGHT = 80

ZONE_CENTERS = {
    "nw": (25, 60),
    "ne": (75, 60),
    "sw": (25, 20),
    "se": (75, 20),
}

RAIL_CORRIDOR_ROUTE_IDS = [
    "T1_WESTERN",       # Penrith -> Central (was RAIL_WEST_CBD)
    "T1_NORTH_SHORE",   # Hornsby -> Central (was RAIL_NORTH_CBD)
    "T3_BANKSTOWN",     # Central -> Liverpool via Bankstown (was RAIL_SOUTH_CBD)
    "T4_EASTERN",       # Central -> Bondi Junction (was RAIL_EAST_CBD)
    "T2_INNER_WEST",    # Central -> Strathfield (was RAIL_WEST_NORTH_ORBITAL)
]

RAIL_OPERATOR = {
    "operator_id": "rail_main",
    "operator_type": "rail",
    "mode": "train",
    "corridors": [
        {
            "corridor_id": get_route_definition(route_id)["corridor_id"],
            "route_id": route_id,
            "station_ids": list(get_route_definition(route_id)["station_ids"]),
            "schedule_interval": get_route_definition(route_id)["frequency"],
            "capacity_per_departure": get_route_definition(route_id)["capacity"],
            "in_vehicle_per_hop": get_pt_in_vehicle_time_per_hop(route_id),
            "base_fare": get_pt_mode_base_fare("train", 10),
            "distance_rate": get_pt_mode_distance_rate("train"),
            "reliability": 0.97,
        }
        for route_id in RAIL_CORRIDOR_ROUTE_IDS
    ],
}

BUS_OPERATORS = [
    {
        "operator_id": "bus_zone_nw",
        "operator_type": "bus",
        "mode": "bus",
        "zone_id": "nw",
        "zone_bounds": ZONE_BOUNDS["nw"],
        "schedule_interval": get_route_definition("BUS_600")["frequency"],
        "capacity_per_departure": 16,
        "in_vehicle_per_hop": get_pt_in_vehicle_time_per_hop("BUS_600"),
        "base_fare": get_pt_mode_base_fare("bus", 10),
        "distance_rate": get_pt_mode_distance_rate("bus"),
        "reliability": 0.90,
        # NW quadrant: Parramatta / Blacktown / Penrith / Strathfield corridor.
        "owned_stop_ids": ["B_PENRITH", "B_BLACKTOWN", "B_PARRAMATTA", "B_STRATHFIELD"],
        "local_route_ids": ["BUS_600"],
        "feeder_route_ids": ["BUS_461"],
        "route_definitions": [
            {
                "route_id": "BUS_600",  # Parramatta <-> Blacktown local
                "service_scope": "local",
                "station_ids": list(get_route_definition("BUS_600")["station_ids"]),
            },
            {
                "route_id": "BUS_461",  # Burwood <-> Strathfield feeder into T1_WESTERN/T2
                "service_scope": "feeder",
                "station_ids": list(get_route_definition("BUS_461")["station_ids"]),
                "pt_interchange_stop_id": "B_STRATHFIELD",
            },
        ],
    },
    {
        "operator_id": "bus_zone_ne",
        "operator_type": "bus",
        "mode": "bus",
        "zone_id": "ne",
        "zone_bounds": ZONE_BOUNDS["ne"],
        "schedule_interval": get_route_definition("BUS_143")["frequency"],
        "capacity_per_departure": 16,
        "in_vehicle_per_hop": get_pt_in_vehicle_time_per_hop("BUS_143"),
        "base_fare": get_pt_mode_base_fare("bus", 10),
        "distance_rate": get_pt_mode_distance_rate("bus"),
        "reliability": 0.92,
        # NE quadrant: Chatswood / Manly / Hornsby / Northern Beaches.
        "owned_stop_ids": ["B_HORNSBY", "B_CHATSWOOD", "B_MANLY", "B_DEE_WHY", "B_MONA_VALE"],
        "local_route_ids": ["BUS_143"],
        "feeder_route_ids": ["BUS_575"],
        "route_definitions": [
            {
                "route_id": "BUS_143",  # Chatswood <-> Manly local
                "service_scope": "local",
                "station_ids": list(get_route_definition("BUS_143")["station_ids"]),
            },
            {
                "route_id": "BUS_575",  # Hornsby <-> Chatswood feeder into T1_NORTH_SHORE
                "service_scope": "feeder",
                "station_ids": list(get_route_definition("BUS_575")["station_ids"]),
                "pt_interchange_stop_id": "B_CHATSWOOD",
            },
        ],
    },
    {
        "operator_id": "bus_zone_sw",
        "operator_type": "bus",
        "mode": "bus",
        "zone_id": "sw",
        "zone_bounds": ZONE_BOUNDS["sw"],
        "schedule_interval": get_route_definition("BUS_901")["frequency"],
        "capacity_per_departure": 16,
        "in_vehicle_per_hop": get_pt_in_vehicle_time_per_hop("BUS_901"),
        "base_fare": get_pt_mode_base_fare("bus", 10),
        "distance_rate": get_pt_mode_distance_rate("bus"),
        "reliability": 0.91,
        # SW quadrant: Liverpool / Bankstown / Hurstville / Ashfield / Burwood corridor.
        "owned_stop_ids": ["B_LIVERPOOL", "B_BANKSTOWN", "B_HURSTVILLE", "B_ASHFIELD", "B_BURWOOD"],
        "local_route_ids": ["BUS_901"],
        "feeder_route_ids": ["BUS_901"],
        "route_definitions": [
            {
                "route_id": "BUS_901",  # Liverpool <-> Bankstown local (also feeds T3_BANKSTOWN)
                "service_scope": "local",
                "station_ids": list(get_route_definition("BUS_901")["station_ids"]),
            },
            {
                "route_id": "BUS_901",  # reused as feeder; interchange at Bankstown
                "service_scope": "feeder",
                "station_ids": list(get_route_definition("BUS_901")["station_ids"]),
                "pt_interchange_stop_id": "B_BANKSTOWN",
            },
        ],
    },
    {
        "operator_id": "bus_zone_se",
        "operator_type": "bus",
        "mode": "bus",
        "zone_id": "se",
        "zone_bounds": ZONE_BOUNDS["se"],
        "schedule_interval": get_route_definition("BUS_394")["frequency"],
        "capacity_per_departure": 16,
        "in_vehicle_per_hop": get_pt_in_vehicle_time_per_hop("BUS_394"),
        "base_fare": get_pt_mode_base_fare("bus", 10),
        "distance_rate": get_pt_mode_distance_rate("bus"),
        "reliability": 0.93,
        # SE quadrant: Randwick / Maroubra / Eastgardens / Sutherland corridor.
        "owned_stop_ids": ["B_RANDWICK", "B_MAROUBRA", "B_EASTGARDENS", "B_SUTHERLAND"],
        "local_route_ids": ["BUS_394"],
        "feeder_route_ids": ["BUS_381"],
        "route_definitions": [
            {
                "route_id": "BUS_394",  # Randwick <-> Eastgardens <-> Maroubra local
                "service_scope": "local",
                "station_ids": list(get_route_definition("BUS_394")["station_ids"]),
            },
            {
                "route_id": "BUS_381",  # Bondi Junction <-> Randwick feeder into T4_EASTERN
                "service_scope": "feeder",
                "station_ids": list(get_route_definition("BUS_381")["station_ids"]),
                "pt_interchange_stop_id": "B_BONDI_JUNCTION",
            },
        ],
    },
]

BASE_BIKE_OPERATORS = [
    {
        "operator_id": "bikeshare_A",
        "operator_type": "ondemand",
        "mode_set": ["bike"],
        "coverage_type": "city_wide",
        "preferred_zones": ["nw", "sw", "ne", "se"],
        "out_of_preference_penalty_multiplier": 1.00,
        "fleet_capacity": 10,
        "base_price": 0.0,
        "distance_rate": 0.37,
        "speed": 6.5,
        "bike_speed": 1.4,
        "reliability": 0.92,
        "quality_score": 78,
        "service_center": (30, 40),
        "service_area": 120,
    },
    {
        "operator_id": "bikeshare_B",
        "operator_type": "ondemand",
        "mode_set": ["bike"],
        "coverage_type": "city_wide",
        "preferred_zones": ["nw", "sw", "ne", "se"],
        "out_of_preference_penalty_multiplier": 1.00,
        "fleet_capacity": 12,
        "base_price": 0.0,
        "distance_rate": 0.37,
        "speed": 6.5,
        "bike_speed": 1.4,
        "reliability": 0.90,
        "quality_score": 75,
        "service_center": (70, 40),
        "service_area": 120,
    },
]

BASE_ONDEMAND_OPERATORS = [
    # Sydney-district specialisation (2026-07-09):
    #   coverage_type = "district" enables the ABM's origin/destination distance
    #   filter (see decentralized_provider.py:265) — provider accepts a request
    #   only if min(orig_dist, dest_dist) to service_center <= service_area.
    #   service_center coords now anchored on real Sydney hubs.
    {
        "operator_id": "ondemand_A_low_price",
        "operator_type": "ondemand",
        "mode_set": ["car"],
        "coverage_type": "district",
        "preferred_zones": ["nw", "sw", "ne", "se"],  # low-price broad-availability
        "out_of_preference_penalty_multiplier": 1.00,
        "fleet_capacity": 24,
        "base_price": 1.5,
        "distance_rate": 0.9,
        "speed": 6.5,
        "bike_speed": None,
        "reliability": 0.88,
        "quality_score": 80,
        "service_center": (50, 40),   # CBD (Central)
        "service_area": 35,           # CBD + inner ring; catches long trips ending in CBD
    },
    {
        "operator_id": "ondemand_B_fast_premium",
        "operator_type": "ondemand",
        "mode_set": ["car"],
        "coverage_type": "district",
        "preferred_zones": ["ne", "se"],  # affluent east
        "out_of_preference_penalty_multiplier": 1.10,
        "fleet_capacity": 16,
        "base_price": 4.0,
        "distance_rate": 1.5,
        "speed": 6.5,
        "bike_speed": None,
        "reliability": 0.95,
        "quality_score": 90,
        "service_center": (65, 45),   # Bondi Junction area
        "service_area": 25,           # eastern suburbs / lower north shore
    },
    {
        "operator_id": "ondemand_C_balanced",
        "operator_type": "ondemand",
        "mode_set": ["car", "bike"],
        "coverage_type": "district",
        "preferred_zones": ["nw", "sw"],  # western corridor
        "out_of_preference_penalty_multiplier": 1.05,
        "fleet_capacity": 20,
        "base_price": 2.7,
        "distance_rate": 1.2,
        "speed": 6.5,
        "bike_speed": 1.4,
        "reliability": 0.91,
        "quality_score": 86,
        "service_center": (25, 45),   # Parramatta (real Sydney secondary hub)
        "service_area": 25,           # western corridor Penrith -> Strathfield
    },
]

ONDEMAND_OPERATORS = BASE_ONDEMAND_OPERATORS

EXPECTED_OPERATOR_IDS = [
    "rail_main",
    "bus_zone_nw",
    "bus_zone_ne",
    "bus_zone_sw",
    "bus_zone_se",
    "ondemand_A_low_price",
    "ondemand_B_fast_premium",
    "ondemand_C_balanced",
    "bikeshare_A",
    "bikeshare_B",
]


def _scale_pt_supply_profiles(
    rail_operator: dict,
    bus_operators: list[dict],
    *,
    world_settings: dict | None = None,
) -> tuple[dict, list[dict]]:
    wait_factor = resolve_pt_wait_time_factor(world_settings=world_settings)
    in_vehicle_factor = resolve_pt_in_vehicle_time_factor(world_settings=world_settings)
    scaled_rail = deepcopy(rail_operator)
    for corridor in scaled_rail.get("corridors", []):
        corridor["schedule_interval"] = max(1, int(round(float(corridor["schedule_interval"]) * wait_factor)))
        corridor["in_vehicle_per_hop"] = round(float(corridor.get("in_vehicle_per_hop", 1.0)) * in_vehicle_factor, 6)
    scaled_bus = deepcopy(bus_operators)
    for operator in scaled_bus:
        operator["schedule_interval"] = max(1, int(round(float(operator["schedule_interval"]) * wait_factor)))
        operator["in_vehicle_per_hop"] = round(float(operator.get("in_vehicle_per_hop", 1.0)) * in_vehicle_factor, 6)
    return scaled_rail, scaled_bus


def _apply_operator_niche_profile(
    profiles: list[dict],
    *,
    world_settings: dict | None = None,
) -> list[dict]:
    niche_profile = resolve_operator_niche_profile(world_settings=world_settings)
    rows = deepcopy(profiles)
    if niche_profile == "baseline":
        return rows

    def _set_profile(operator_id: str, **updates):
        for row in rows:
            if row.get("operator_id") == operator_id:
                row.update(updates)
                return
        raise KeyError(f"Unknown on-demand operator for niche profile: {operator_id}")

    if niche_profile == "polycentric_local_specialists":
        _set_profile(
            "ondemand_A_low_price",
            coverage_type="district",
            preferred_zones=["nw"],
            service_center=ZONE_CENTERS["nw"],
            service_area=34,
        )
        _set_profile(
            "ondemand_B_fast_premium",
            coverage_type="district",
            preferred_zones=["se"],
            service_center=ZONE_CENTERS["se"],
            service_area=34,
        )
        _set_profile(
            "ondemand_C_balanced",
            coverage_type="regional",
            preferred_zones=["ne", "sw"],
            service_center=(50, 40),
            service_area=44,
        )
        return rows

    if niche_profile == "outer_ring_specialists":
        _set_profile(
            "ondemand_A_low_price",
            coverage_type="district",
            preferred_zones=["sw"],
            service_center=ZONE_CENTERS["sw"],
            service_area=36,
        )
        _set_profile(
            "ondemand_B_fast_premium",
            coverage_type="district",
            preferred_zones=["ne"],
            service_center=ZONE_CENTERS["ne"],
            service_area=36,
        )
        _set_profile(
            "ondemand_C_balanced",
            coverage_type="district",
            preferred_zones=["se"],
            service_center=ZONE_CENTERS["se"],
            service_area=38,
        )
        return rows

    if niche_profile == "reverse_commute_specialists":
        _set_profile(
            "ondemand_A_low_price",
            coverage_type="regional",
            preferred_zones=["nw", "ne"],
            service_center=(50, 60),
            service_area=42,
        )
        _set_profile(
            "ondemand_B_fast_premium",
            coverage_type="district",
            preferred_zones=["sw"],
            service_center=ZONE_CENTERS["sw"],
            service_area=34,
        )
        _set_profile(
            "ondemand_C_balanced",
            coverage_type="district",
            preferred_zones=["se"],
            service_center=ZONE_CENTERS["se"],
            service_area=34,
        )
        return rows

    raise ValueError(f"Unknown operator niche profile: {niche_profile}")


def _neutral_spec_active() -> bool:
    """V9 §1.2b. Mirrors Rep tree."""
    import os
    return os.environ.get("V9_NEUTRAL_SPEC", "").strip().lower() in ("1", "true", "yes", "on")


def _apply_neutral_supply_override(ondemand_ops: list[dict], bike_ops: list[dict]) -> tuple[list[dict], list[dict]]:
    """V9 §1.2b Phase 1.3 wiring. Mirrors Rep — drops ondemand_C, resizes car
    A/B to neutral capacities, applies shared fare card. Sydney twin."""
    from shared_neutral_supply import NEUTRAL_SUPPLY_SPEC
    try:
        from shared_fare_card import FARE_CARD
    except Exception:
        FARE_CARD = None

    car_neutral = NEUTRAL_SUPPLY_SPEC["car"]
    bike_neutral = NEUTRAL_SUPPLY_SPEC["bike"]

    neutral_car_caps = [p["capacity"] for p in car_neutral["providers"]]
    neutral_car_ids = [p["provider_id"] for p in car_neutral["providers"]]
    ride_hail = (FARE_CARD or {}).get("ride_hail") or {}
    new_ondemand = []
    car_only_ops = [op for op in ondemand_ops if op.get("mode_set") == ["car"]]
    for i, op in enumerate(car_only_ops[:len(neutral_car_caps)]):
        neutral_op = deepcopy(op)
        neutral_op["fleet_capacity"] = int(neutral_car_caps[i])
        if ride_hail:
            neutral_op["base_price"] = float(ride_hail.get("base") or 0.0)
            neutral_op["distance_rate"] = float(ride_hail.get("distance_rate") or 0.0)
            neutral_op["time_rate"] = float(ride_hail.get("time_rate") or 0.0)
        neutral_op["neutral_provider_id"] = neutral_car_ids[i]
        new_ondemand.append(neutral_op)

    micromob = (FARE_CARD or {}).get("micromobility") or {}
    neutral_bike_caps = [p["capacity"] for p in bike_neutral["providers"]]
    neutral_bike_ids = [p["provider_id"] for p in bike_neutral["providers"]]
    new_bike = []
    for i, op in enumerate(bike_ops[:len(neutral_bike_caps)]):
        neutral_op = deepcopy(op)
        neutral_op["fleet_capacity"] = int(neutral_bike_caps[i])
        if micromob:
            neutral_op["base_price"] = float(micromob.get("base") or 0.0)
            neutral_op["distance_rate"] = float(micromob.get("distance_rate") or 0.0)
            neutral_op["time_rate"] = float(micromob.get("time_rate") or 0.0)
        neutral_op["neutral_provider_id"] = neutral_bike_ids[i]
        new_bike.append(neutral_op)
    return new_ondemand, new_bike


def get_v2_supply_definition(
    variant: str | None = None,
    *,
    world_settings: dict | None = None,
):
    resolved_variant = resolve_s1_variant(variant)
    scaled_rail_operator, scaled_bus_operators = _scale_pt_supply_profiles(
        RAIL_OPERATOR,
        BUS_OPERATORS,
        world_settings=world_settings,
    )
    ondemand_transformed = _apply_operator_niche_profile(
        apply_world_scales_to_decentralized_ondemand_profiles(
            transform_decentralized_ondemand_profiles(
                deepcopy(BASE_ONDEMAND_OPERATORS),
                variant=resolved_variant,
            ),
            world_settings=world_settings,
        ),
        world_settings=world_settings,
    )
    bike_ops = deepcopy(BASE_BIKE_OPERATORS)

    if _neutral_spec_active():
        ondemand_transformed, bike_ops = _apply_neutral_supply_override(
            ondemand_transformed, bike_ops,
        )
        # CAUGHT ERROR #10 fix (STOP #16, Option A / v9-neutral-spec.3): the neutral
        # override above resets fleet_capacity to the fixed neutral cap, discarding the
        # direct_capacity_factor scaling applied earlier by
        # apply_world_scales_to_decentralized_ondemand_profiles. Re-apply the factor here
        # so the D arm mirrors C's ordering (neutral base cap THEN scale — see
        # run_visualisation_03.py:2061-2065). No-op at direct_capacity_factor == 1.0.
        for _op in ondemand_transformed + bike_ops:
            _op["fleet_capacity"] = scale_direct_capacity(
                _op["fleet_capacity"], world_settings=world_settings
            )
        expected_ids = [i for i in EXPECTED_OPERATOR_IDS if i != "ondemand_C_balanced"]
    else:
        expected_ids = EXPECTED_OPERATOR_IDS

    return {
        "grid_width": GRID_WIDTH,
        "grid_height": GRID_HEIGHT,
        "zone_bounds": ZONE_BOUNDS,
        "zone_centers": ZONE_CENTERS,
        "rail_operator": scaled_rail_operator,
        "bus_operators": scaled_bus_operators,
        "ondemand_operators": ondemand_transformed + bike_ops,
        "expected_operator_ids": expected_ids,
    }
