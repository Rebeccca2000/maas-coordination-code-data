from __future__ import annotations

from pathlib import Path
import json
import random

from shared_experiment_config import (
    GRID_HEIGHT,
    GRID_WIDTH,
    NUM_COMMUTERS,
    RANDOM_SEED,
    SIMULATION_STEPS,
    SMALL_WORLD_P,
)
from shared_frozen_inputs import (
    FrozenCommuterSpec,
    compute_commuter_fingerprint,
    compute_trip_request_fingerprint,
)
from shared_topology_v2 import build_subcentre_hubs, get_small_world_map
from shared_trip_generator import TripSpec, generate_two_trip_day


OUTPUT_DIR = Path(__file__).resolve().parent / "frozen_inputs" / "conference_baseline"
SCENARIO_ID = "conference_baseline_v1"

INCOME_WEIGHTS = [0.5, 0.3, 0.2]
HEALTH_WEIGHTS = [0.9, 0.1]
PAYMENT_WEIGHTS = [0.8, 0.2]
AGE_DISTRIBUTION = {
    (18, 25): 0.2,
    (26, 35): 0.3,
    (36, 45): 0.2,
    (46, 55): 0.15,
    (56, 65): 0.1,
    (66, 75): 0.05,
}
DISABILITY_WEIGHTS = [0.2, 0.8]
TECH_ACCESS_WEIGHTS = [0.95, 0.05]


def build_hubs(stations: dict[str, dict[str, tuple[int, int]]]) -> dict[str, tuple[int, int]]:
    return build_subcentre_hubs(
        stations,
        grid_width=GRID_WIDTH,
        grid_height=GRID_HEIGHT,
    )


def generate_trips() -> list[TripSpec]:
    sw = get_small_world_map(
        p_shortcut=SMALL_WORLD_P,
        seed=RANDOM_SEED,
        grid_width=GRID_WIDTH,
        grid_height=GRID_HEIGHT,
    )
    hubs = build_hubs(sw.stations)
    days = max(1, (SIMULATION_STEPS + 143) // 144)
    trips: list[TripSpec] = []
    for canonical_commuter_id in range(NUM_COMMUTERS):
        for day_idx in range(days):
            outbound, inbound = generate_two_trip_day(
                base_seed=RANDOM_SEED,
                commuter_id=canonical_commuter_id,
                grid_w=GRID_WIDTH,
                grid_h=GRID_HEIGHT,
                hubs=hubs,
                day_index=day_idx,
            )
            trips.extend([outbound, inbound])
    return trips


def generate_commuters(trips: list[TripSpec]) -> list[dict[str, object]]:
    trips_by_commuter: dict[int, list[TripSpec]] = {}
    for trip in trips:
        trips_by_commuter.setdefault(trip.commuter_id, []).append(trip)
    for commuter_id in list(trips_by_commuter):
        trips_by_commuter[commuter_id].sort(key=lambda trip: (trip.day_index, trip.trip_index))

    age_buckets = list(AGE_DISTRIBUTION.items())
    commuters = []
    for canonical_commuter_id in range(NUM_COMMUTERS):
        rnd = random.Random(RANDOM_SEED + canonical_commuter_id * 9973)
        initial_location = list(trips_by_commuter[canonical_commuter_id][0].origin_xy)
        age_range = rnd.choices(
            [item[0] for item in age_buckets],
            weights=[item[1] for item in age_buckets],
        )[0]
        commuters.append(
            {
                "canonical_commuter_id": canonical_commuter_id,
                "initial_location": initial_location,
                "age": rnd.randint(age_range[0], age_range[1]),
                "income_level": rnd.choices(["low", "middle", "high"], weights=INCOME_WEIGHTS)[0],
                "has_disability": rnd.choices([True, False], weights=DISABILITY_WEIGHTS)[0],
                "tech_access": rnd.choices([True, False], weights=TECH_ACCESS_WEIGHTS)[0],
                "health_status": rnd.choices(["good", "poor"], weights=HEALTH_WEIGHTS)[0],
                "payment_scheme": rnd.choices(["PAYG", "subscription"], weights=PAYMENT_WEIGHTS)[0],
            }
        )
    return commuters


def main() -> int:
    trips = generate_trips()
    commuters = generate_commuters(trips)

    commuter_payload = {
        "schema_version": 1,
        "scenario_id": SCENARIO_ID,
        "seed": RANDOM_SEED,
        "grid_width": GRID_WIDTH,
        "grid_height": GRID_HEIGHT,
        "commuter_count": len(commuters),
        "commuters": commuters,
    }
    trip_payload = {
        "schema_version": 1,
        "scenario_id": SCENARIO_ID,
        "seed": RANDOM_SEED,
        "simulation_steps": SIMULATION_STEPS,
        "planned_trip_count": len(trips),
        "trip_requests": [
            {
                "canonical_trip_id": trip.trip_id,
                "canonical_commuter_id": trip.commuter_id,
                "trip_index": trip.trip_index,
                "day_index": trip.day_index,
                "depart_step": trip.depart_step,
                "origin_xy": list(trip.origin_xy),
                "dest_xy": list(trip.dest_xy),
                "purpose": trip.purpose,
            }
            for trip in trips
        ],
    }

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    commuter_path = OUTPUT_DIR / "fixed_commuters.json"
    trip_path = OUTPUT_DIR / "fixed_trip_requests.json"
    commuter_path.write_text(json.dumps(commuter_payload, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    trip_path.write_text(json.dumps(trip_payload, sort_keys=True, indent=2) + "\n", encoding="utf-8")

    print(f"Wrote {commuter_path}")
    print(f"Commuter fingerprint: {compute_commuter_fingerprint_from_payload(commuters)}")
    print(f"Wrote {trip_path}")
    print(f"Trip fingerprint: {compute_trip_request_fingerprint(trips)}")
    return 0


def compute_commuter_fingerprint_from_payload(commuters: list[dict[str, object]]) -> str:
    return compute_commuter_fingerprint(
        [
            FrozenCommuterSpec(
                canonical_commuter_id=int(commuter["canonical_commuter_id"]),
                initial_location=tuple(commuter["initial_location"]),
                age=int(commuter["age"]),
                income_level=str(commuter["income_level"]),
                has_disability=bool(commuter["has_disability"]),
                tech_access=bool(commuter["tech_access"]),
                health_status=str(commuter["health_status"]),
                payment_scheme=str(commuter["payment_scheme"]),
            )
            for commuter in commuters
        ]
    )


if __name__ == "__main__":
    raise SystemExit(main())
