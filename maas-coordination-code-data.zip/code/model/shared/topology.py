"""Sydney-network topology bridge.

Replaces the synthetic 5-hub topology_ORIGINAL.py with NTEO's 46-node real
Sydney network while preserving the SharedTopologyV2 public API that
pt_operating_assumptions, cross_world_panel, supply_config, and the ABMs
consume.

Design:
- 46 NTEO nodes are split into T_<NAME> (train-capable) and B_<NAME>
  (bus-capable) station entries, matching the original T_/B_ mode-split
  convention. Nodes supporting both modes yield two entries at identical
  coords plus a TRANSFER edge (T_X <-> B_X, 1.0 min).
- Routes are inferred from NTEO's route_id prefix: T*_* -> train, BUS_* -> bus.
  WALK-only NTEO edges are dropped (transfers handle intra-CBD walking).
- Frequency/capacity/travel_time per route are taken from the first edge in
  the route sequence (NTEO edges within a route share these).
- Subcentres redefined for real Sydney: CBD, WestHub (Parramatta),
  NorthHub (Chatswood), EastHub (Bondi Jct), SouthHub (Hurstville/Bankstown).
- Zone bounds preserved (NW/NE/SW/SE quadrants of the 100x80 grid).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Tuple
import copy
import hashlib
import json
import os
import sys
from collections import defaultdict

# Path bootstrap so we can import the sibling code/network/ package.
_HERE = os.path.dirname(os.path.abspath(__file__))
_NETWORK_DIR = os.path.abspath(os.path.join(_HERE, "..", "network"))
if _NETWORK_DIR not in sys.path:
    sys.path.insert(0, _NETWORK_DIR)

from network_topology import SydneyNetworkTopology, TransportMode  # noqa: E402


StationsDict = Dict[str, Dict[str, Tuple[int, int]]]
RoutesDict = Dict[str, Dict[str, List[str]]]
TransfersDict = Dict[Tuple[str, str], float]


GRID_WIDTH = 100
GRID_HEIGHT = 80
TRANSFER_TIME = 1.0
DEFAULT_PT_TRAVEL_TIME = 0.8


ZONE_BOUNDS = {
    "nw": {"x_min": 0, "x_max": 49, "y_min": 40, "y_max": 79},
    "ne": {"x_min": 50, "x_max": 99, "y_min": 40, "y_max": 79},
    "sw": {"x_min": 0, "x_max": 49, "y_min": 0, "y_max": 39},
    "se": {"x_min": 50, "x_max": 99, "y_min": 0, "y_max": 39},
}


# Sydney subcentres — real hub anchors on NTEO node names, T_/B_ prefixed for
# consumers that filter by transport mode.
SUBCENTRE_DEFINITIONS: Dict[str, Dict[str, Any]] = {
    "CBD": {
        "subcentre_id": "CBD",
        "anchor_node_ids": ["T_CENTRAL", "T_TOWN_HALL", "T_WYNYARD", "B_CENTRAL"],
        "member_node_ids": [
            "T_CENTRAL", "T_TOWN_HALL", "T_WYNYARD", "T_CIRCULAR_QUAY",
            "T_MARTIN_PLACE", "T_REDFERN",
            "B_CENTRAL", "B_TOWN_HALL", "B_WYNYARD", "B_CIRCULAR_QUAY",
        ],
    },
    "WestHub": {
        "subcentre_id": "WestHub",
        "anchor_node_ids": ["T_PARRAMATTA", "T_BLACKTOWN", "T_PENRITH", "B_PARRAMATTA"],
        "member_node_ids": [
            "T_PARRAMATTA", "T_BLACKTOWN", "T_PENRITH", "T_WESTMEAD",
            "T_LIDCOMBE", "T_HOMEBUSH", "T_STRATHFIELD",
            "B_PARRAMATTA", "B_BLACKTOWN", "B_PENRITH", "B_STRATHFIELD",
        ],
    },
    "NorthHub": {
        "subcentre_id": "NorthHub",
        "anchor_node_ids": ["T_CHATSWOOD", "T_NORTH_SYDNEY", "T_HORNSBY", "B_CHATSWOOD"],
        "member_node_ids": [
            "T_CHATSWOOD", "T_NORTH_SYDNEY", "T_HORNSBY", "T_MILSONS_POINT",
            "T_CROWS_NEST", "T_ST_LEONARDS", "T_ROSEVILLE", "T_GORDON",
            "B_CHATSWOOD", "B_NORTH_SYDNEY", "B_HORNSBY", "B_MANLY",
            "B_DEE_WHY", "B_MONA_VALE",
        ],
    },
    "EastHub": {
        "subcentre_id": "EastHub",
        "anchor_node_ids": ["T_BONDI_JUNCTION", "B_BONDI_JUNCTION"],
        "member_node_ids": [
            "T_BONDI_JUNCTION", "T_EDGECLIFF", "T_KINGS_CROSS",
            "B_BONDI_JUNCTION", "B_RANDWICK", "B_MAROUBRA", "B_EASTGARDENS",
        ],
    },
    "SouthHub": {
        "subcentre_id": "SouthHub",
        "anchor_node_ids": ["T_LIVERPOOL", "T_BANKSTOWN", "T_HURSTVILLE", "T_MASCOT"],
        "member_node_ids": [
            "T_LIVERPOOL", "T_BANKSTOWN", "T_HURSTVILLE", "T_MASCOT",
            "T_SYDENHAM", "T_WILEY_PARK", "T_LAKEMBA", "T_KOGARAH",
            "T_ROCKDALE", "T_SUTHERLAND", "T_DOMESTIC_AIRPORT",
            "T_INTERNATIONAL_AIRPORT", "T_NEWTOWN",
            "B_LIVERPOOL", "B_BANKSTOWN", "B_HURSTVILLE", "B_MASCOT",
        ],
    },
}


# --- Build stations + routes from the NTEO Sydney topology -------------------

def _build_nteo_topology() -> SydneyNetworkTopology:
    t = SydneyNetworkTopology()
    t.initialize_base_sydney_network()
    return t


def _classify_route_mode(route_id: str) -> str:
    """T* -> train, BUS_* -> bus, everything else (WALK etc.) -> transfer."""
    if route_id.startswith("BUS_"):
        return "bus"
    if route_id and route_id[0] == "T" and (len(route_id) > 1 and route_id[1].isdigit()):
        return "train"
    return "transfer"


def _prefix_for_mode(mode: str) -> str:
    if mode == "train":
        return "T_"
    if mode == "bus":
        return "B_"
    return ""


def _build_stations_from_nteo(nteo: SydneyNetworkTopology) -> StationsDict:
    train: Dict[str, Tuple[int, int]] = {}
    bus: Dict[str, Tuple[int, int]] = {}
    for nid, node in nteo.nodes.items():
        modes = node.transport_modes or []
        x, y = int(node.coordinates[0]), int(node.coordinates[1])
        if TransportMode.TRAIN in modes:
            train[f"T_{nid}"] = (x, y)
        if TransportMode.BUS in modes:
            bus[f"B_{nid}"] = (x, y)
    return {"train": train, "bus": bus}


def _build_route_definitions_from_nteo(
    nteo: SydneyNetworkTopology,
    stations: StationsDict,
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    """Collapse NTEO edges into per-route station sequences.

    Each NTEO edge belongs to a route_id and has a segment_order. We order
    edges within a route by segment_order, then walk the chain to produce a
    single station_ids list.
    """
    per_route_segments: Dict[str, List[Tuple[int, str, str, Any]]] = defaultdict(list)
    for eid, edge in nteo.edges.items():
        per_route_segments[edge.route_id].append(
            (edge.segment_order, edge.from_node, edge.to_node, edge),
        )

    rail_defs: List[Dict[str, Any]] = []
    bus_defs: List[Dict[str, Any]] = []
    for route_id, segs in per_route_segments.items():
        mode = _classify_route_mode(route_id)
        if mode == "transfer":
            continue
        prefix = _prefix_for_mode(mode)

        # Sort by segment_order and reconstruct the station chain.
        segs_sorted = sorted(segs, key=lambda s: s[0])
        station_ids: List[str] = []
        for _, fr, to, _edge in segs_sorted:
            fr_id = f"{prefix}{fr}"
            to_id = f"{prefix}{to}"
            if fr_id not in station_ids:
                station_ids.append(fr_id)
            if to_id not in station_ids:
                station_ids.append(to_id)

        # Drop stations not present in the station dict (e.g. a node without
        # the required mode). Rare but defensive.
        valid_ids = set(stations[mode].keys())
        station_ids = [sid for sid in station_ids if sid in valid_ids]
        if len(station_ids) < 2:
            continue

        first_edge = segs_sorted[0][3]
        route_def = {
            "route_id": route_id,
            "mode": mode,
            "station_ids": station_ids,
            "travel_time": float(first_edge.travel_time or DEFAULT_PT_TRAVEL_TIME),
            "capacity": int(first_edge.capacity or 120),
            "frequency": int(round(first_edge.frequency or 8)),
            "service_scope": "trunk" if mode == "train" else "local",
            "corridor_id": route_id.lower(),
        }
        if mode == "train":
            rail_defs.append(route_def)
        else:
            bus_defs.append(route_def)

    rail_defs.sort(key=lambda r: r["route_id"])
    bus_defs.sort(key=lambda r: r["route_id"])
    return rail_defs, bus_defs


# Build once at import time — topology is deterministic.
_NTEO = _build_nteo_topology()
_STATIONS = _build_stations_from_nteo(_NTEO)
RAIL_ROUTE_DEFINITIONS, BUS_ROUTE_DEFINITIONS = _build_route_definitions_from_nteo(_NTEO, _STATIONS)
ALL_ROUTE_DEFINITIONS = RAIL_ROUTE_DEFINITIONS + BUS_ROUTE_DEFINITIONS
ROUTE_DEFINITION_BY_ID = {r["route_id"]: r for r in ALL_ROUTE_DEFINITIONS}


@dataclass(frozen=True)
class SharedTopologyV2:
    stations: StationsDict
    routes: RoutesDict
    transfers: TransfersDict
    nodes: List[Dict[str, Any]]
    edges: List[Dict[str, Any]]
    route_catalog: Dict[str, Dict[str, Any]]
    zone_bounds: Dict[str, Dict[str, int]]
    meta: Dict[str, Any]


_cached: SharedTopologyV2 | None = None


def _fingerprint(payload: Dict[str, Any]) -> str:
    blob = json.dumps(payload, sort_keys=True, default=str)
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()[:16]


def _build_routes_dict() -> RoutesDict:
    return {
        "train": {r["route_id"]: list(r["station_ids"]) for r in RAIL_ROUTE_DEFINITIONS},
        "bus": {r["route_id"]: list(r["station_ids"]) for r in BUS_ROUTE_DEFINITIONS},
    }


def _build_transfers(stations: StationsDict) -> TransfersDict:
    """Every station that has both a T_ and B_ entry gets a bidirectional transfer."""
    transfers: TransfersDict = {}
    train_bases = {sid[2:] for sid in stations["train"].keys()}
    bus_bases = {sid[2:] for sid in stations["bus"].keys()}
    for base in sorted(train_bases & bus_bases):
        t_id, b_id = f"T_{base}", f"B_{base}"
        transfers[(t_id, b_id)] = TRANSFER_TIME
        transfers[(b_id, t_id)] = TRANSFER_TIME
    return transfers


def _hub_group(node_id: str) -> str | None:
    for sub_id, defn in SUBCENTRE_DEFINITIONS.items():
        if node_id in defn["member_node_ids"]:
            return sub_id
    return None


def _build_nodes(stations: StationsDict) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for mode in ("train", "bus"):
        for nid, (x, y) in stations[mode].items():
            sub = _hub_group(nid)
            out.append({
                "node_id": nid,
                "node_mode": mode,
                "x": x,
                "y": y,
                "hub_group": sub,
                "subcentre_id": sub,
            })
    return sorted(out, key=lambda i: i["node_id"])


def _build_edges(routes: RoutesDict, transfers: TransfersDict) -> List[Dict[str, Any]]:
    edges: List[Dict[str, Any]] = []
    for mode in ("train", "bus"):
        for route_id, station_ids in routes[mode].items():
            route_def = ROUTE_DEFINITION_BY_ID[route_id]
            for u, v in zip(station_ids, station_ids[1:]):
                for fr, to in ((u, v), (v, u)):
                    edges.append({
                        "edge_id": f"{route_id}::{fr}->{to}",
                        "from_node": fr,
                        "to_node": to,
                        "route_id": route_id,
                        "transport_mode": mode,
                        "travel_time": float(route_def["travel_time"]),
                        "capacity": int(route_def["capacity"]),
                        "frequency": int(route_def["frequency"]),
                        "service_scope": route_def.get("service_scope"),
                        "corridor_id": route_def.get("corridor_id"),
                        "zone_id": route_def.get("zone_id"),
                    })
    for (u, v), t in sorted(transfers.items()):
        edges.append({
            "edge_id": f"TRANSFER::{u}->{v}",
            "from_node": u,
            "to_node": v,
            "route_id": "TRANSFER",
            "transport_mode": "transfer",
            "travel_time": float(t),
            "capacity": 9999,
            "frequency": "continuous",
            "service_scope": "transfer",
            "corridor_id": None,
            "zone_id": None,
        })
    return sorted(edges, key=lambda i: i["edge_id"])


def get_shared_topology_v2(grid_width: int = GRID_WIDTH, grid_height: int = GRID_HEIGHT) -> SharedTopologyV2:
    global _cached
    if _cached is None or _cached.meta.get("grid_width") != grid_width or _cached.meta.get("grid_height") != grid_height:
        stations = copy.deepcopy(_STATIONS)
        routes = _build_routes_dict()
        transfers = _build_transfers(stations)
        nodes = _build_nodes(stations)
        edges = _build_edges(routes, transfers)
        route_catalog = copy.deepcopy(ROUTE_DEFINITION_BY_ID)
        fingerprint_payload = {
            "stations": stations,
            "routes": routes,
            "transfers": [(u, v, t) for (u, v), t in sorted(transfers.items())],
        }
        meta = {
            "topology_type": "sydney_nteo_v1",
            "deterministic": True,
            "grid_width": grid_width,
            "grid_height": grid_height,
            "subcentre_ids": list(SUBCENTRE_DEFINITIONS.keys()),
            "node_count": len(nodes),
            "edge_count": len(edges),
            "route_count_train": len(routes["train"]),
            "route_count_bus": len(routes["bus"]),
            "rail_corridor_count": len(RAIL_ROUTE_DEFINITIONS),
            "bus_route_count": len(BUS_ROUTE_DEFINITIONS),
            "fingerprint": _fingerprint(fingerprint_payload),
        }
        _cached = SharedTopologyV2(
            stations=stations, routes=routes, transfers=transfers,
            nodes=nodes, edges=edges, route_catalog=route_catalog,
            zone_bounds=copy.deepcopy(ZONE_BOUNDS), meta=meta,
        )
    return SharedTopologyV2(
        stations=copy.deepcopy(_cached.stations),
        routes=copy.deepcopy(_cached.routes),
        transfers=copy.deepcopy(_cached.transfers),
        nodes=copy.deepcopy(_cached.nodes),
        edges=copy.deepcopy(_cached.edges),
        route_catalog=copy.deepcopy(_cached.route_catalog),
        zone_bounds=copy.deepcopy(_cached.zone_bounds),
        meta=copy.deepcopy(_cached.meta),
    )


def get_route_definition(route_id: str) -> Dict[str, Any]:
    return copy.deepcopy(ROUTE_DEFINITION_BY_ID[route_id])


def get_subcentre_definitions() -> Dict[str, Dict[str, Any]]:
    return copy.deepcopy(SUBCENTRE_DEFINITIONS)


def build_subcentre_hubs(
    stations: StationsDict,
    *,
    grid_width: int = GRID_WIDTH,
    grid_height: int = GRID_HEIGHT,
) -> Dict[str, Tuple[int, int]]:
    fallback = (grid_width // 2, grid_height // 2)

    def _coord(node_id: str) -> Tuple[int, int] | None:
        if node_id.startswith("T_"):
            return stations.get("train", {}).get(node_id)
        if node_id.startswith("B_"):
            return stations.get("bus", {}).get(node_id)
        return None

    hubs: Dict[str, Tuple[int, int]] = {}
    for sub_id, defn in SUBCENTRE_DEFINITIONS.items():
        coord = None
        for nid in defn["anchor_node_ids"]:
            coord = _coord(nid)
            if coord is not None:
                break
        hubs[sub_id] = coord or fallback
    return hubs


def get_node_subcentre_mapping(
    stations: StationsDict | None = None,
) -> List[Dict[str, Any]]:
    if stations is None:
        stations = copy.deepcopy(_STATIONS)
    anchor_lookup = {
        nid: sub_id
        for sub_id, defn in SUBCENTRE_DEFINITIONS.items()
        for nid in defn["anchor_node_ids"]
    }
    out: List[Dict[str, Any]] = []
    for mode in ("train", "bus"):
        for nid, (x, y) in stations[mode].items():
            sub = _hub_group(nid)
            out.append({
                "node_id": nid, "node_mode": mode, "x": x, "y": y,
                "subcentre_id": sub,
                "is_anchor": bool(sub) and anchor_lookup.get(nid) == sub,
            })
    return sorted(out, key=lambda i: i["node_id"])


def get_small_world_map(
    p_shortcut: float = 0.0,
    seed: int = 0,
    grid_width: int = GRID_WIDTH,
    grid_height: int = GRID_HEIGHT,
) -> SharedTopologyV2:
    """Compatibility entrypoint. Sydney topology is deterministic — small-world
    parameters are recorded in meta but do not alter the graph."""
    topo = get_shared_topology_v2(grid_width=grid_width, grid_height=grid_height)
    meta = copy.deepcopy(topo.meta)
    meta.update({
        "compatibility_entrypoint": "get_small_world_map",
        "p_shortcut": p_shortcut,
        "seed": seed,
        "legacy_small_world_compat": True,
    })
    return SharedTopologyV2(
        stations=topo.stations, routes=topo.routes, transfers=topo.transfers,
        nodes=topo.nodes, edges=topo.edges, route_catalog=topo.route_catalog,
        zone_bounds=topo.zone_bounds, meta=meta,
    )


# Node-level population/employment weights sourced from NTEO for downstream
# purpose-based OD generation (used by trip_generator.py in Stage 4).
NODE_WEIGHTS: Dict[str, Dict[str, float]] = {
    nid: {
        "population_weight": float(node.population_weight),
        "employment_weight": float(node.employment_weight),
        "node_type": str(node.node_type.name if hasattr(node.node_type, "name") else node.node_type),
        "coord": (int(node.coordinates[0]), int(node.coordinates[1])),
    }
    for nid, node in _NTEO.nodes.items()
}


def get_node_weights() -> Dict[str, Dict[str, float]]:
    return copy.deepcopy(NODE_WEIGHTS)
