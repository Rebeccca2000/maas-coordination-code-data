from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple
import heapq
import math
import copy

from shared_experiment_config import PT_IN_VEHICLE_PER_HOP, WALK_SPEED_UNITS_PER_TICK

StationsDict = Dict[str, Dict[str, Tuple[int, int]]]
RoutesDict = Dict[str, Dict[str, List[str]]]
TransfersDict = Dict[Tuple[str, str], float]


@dataclass
class PTRouteResult:
    total_time: float
    station_path: List[str]
    legs: List[Dict[str, Any]]


_PT_ROUTER_STATS: Dict[str, Any] = {
    "call_count": 0,
    "samples": [],
}


def reset_pt_router_stats() -> None:
    _PT_ROUTER_STATS["call_count"] = 0
    _PT_ROUTER_STATS["samples"] = []


def get_pt_router_stats() -> Dict[str, Any]:
    return {
        "call_count": int(_PT_ROUTER_STATS.get("call_count", 0)),
        "samples": copy.deepcopy(_PT_ROUTER_STATS.get("samples", [])),
    }


def _euclid(a: Tuple[int, int], b: Tuple[int, int]) -> float:
    return math.sqrt((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2)


class NoFeasibleStation(Exception):
    """Raised when no station is within the requested walk_radius (V9 Phase 1.2). Mirrors Rep."""


def nearest_station(point: Tuple[int, int], stations: StationsDict, mode: Optional[str] = None) -> str:
    """
    Returns nearest station id to a grid point.
    mode: None / "train" / "bus"
    """
    candidates: List[Tuple[str, Tuple[int, int]]] = []
    if mode is None:
        for m in ("train", "bus"):
            candidates.extend([(sid, xy) for sid, xy in stations.get(m, {}).items()])
    else:
        candidates = [(sid, xy) for sid, xy in stations.get(mode, {}).items()]

    best_sid = None
    best_d = float("inf")
    for sid, xy in candidates:
        d = _euclid(point, xy)
        if d < best_d:
            best_d = d
            best_sid = sid

    if best_sid is None:
        raise ValueError("No stations available to map point -> station.")
    return best_sid


def nearest_station_within_radius(
    point: Tuple[int, int],
    stations: StationsDict,
    walk_radius: float,
    mode: Optional[str] = None,
) -> str:
    """V9 §26.7 walk-radius-bounded variant. Mirrors Rep — see there."""
    candidates: List[Tuple[str, Tuple[int, int]]] = []
    if mode is None:
        for m in ("train", "bus"):
            candidates.extend([(sid, xy) for sid, xy in stations.get(m, {}).items()])
    else:
        candidates = [(sid, xy) for sid, xy in stations.get(mode, {}).items()]

    best_sid = None
    best_d = float("inf")
    for sid, xy in candidates:
        d = _euclid(point, xy)
        if d < best_d:
            best_d = d
            best_sid = sid

    if best_sid is None:
        raise ValueError("No stations available to map point -> station.")
    if best_d > float(walk_radius):
        raise NoFeasibleStation(
            f"Nearest station {best_sid} at d={best_d:.2f} exceeds walk_radius={walk_radius:.2f}"
        )
    return best_sid


def build_station_graph(
    routes: RoutesDict,
    transfers: TransfersDict,
    in_vehicle_per_hop: float = PT_IN_VEHICLE_PER_HOP,
) -> Dict[str, List[Tuple[str, float, Dict[str, Any]]]]:
    """
    Graph: station_id -> list of (next_station, time_cost, meta)
    meta includes edge_type and route_id.
    """
    g: Dict[str, List[Tuple[str, float, Dict[str, Any]]]] = {}

    def add_edge(u: str, v: str, w: float, meta: Dict[str, Any]):
        g.setdefault(u, []).append((v, w, meta))

    for mode in ("train", "bus"):
        for route_id, seq in routes.get(mode, {}).items():
            for i in range(len(seq) - 1):
                u = seq[i]
                v = seq[i + 1]
                add_edge(u, v, in_vehicle_per_hop, {
                    "edge_type": "in_vehicle",
                    "mode": mode,
                    "route_id": route_id,
                })
                add_edge(v, u, in_vehicle_per_hop, {
                    "edge_type": "in_vehicle",
                    "mode": mode,
                    "route_id": route_id,
                })

    for (u, v), t in transfers.items():
        add_edge(u, v, float(t), {
            "edge_type": "transfer",
            "mode": "transfer",
            "route_id": None,
        })

    return g


def dijkstra(
    graph: Dict[str, List[Tuple[str, float, Dict[str, Any]]]],
    start: str,
    goal: str,
) -> Tuple[float, List[str], List[Dict[str, Any]]]:
    """
    Returns (total_cost, path, legs_meta).
    """
    dist = {start: 0.0}
    prev: Dict[str, str] = {}
    prev_edge: Dict[str, Tuple[str, str, float, Dict[str, Any]]] = {}
    pq = [(0.0, start)]

    while pq:
        d, u = heapq.heappop(pq)
        if u == goal:
            break
        if d != dist.get(u, float("inf")):
            continue
        for v, w, meta in graph.get(u, []):
            nd = d + w
            if nd < dist.get(v, float("inf")):
                dist[v] = nd
                prev[v] = u
                prev_edge[v] = (u, v, w, meta)
                heapq.heappush(pq, (nd, v))

    if goal not in dist:
        return float("inf"), [], []

    path = [goal]
    legs: List[Dict[str, Any]] = []
    cur = goal
    while cur != start:
        u = prev[cur]
        uu, vv, w, meta = prev_edge[cur]
        legs.append({
            "from": uu,
            "to": vv,
            "type": meta["edge_type"],
            "mode": meta["mode"],
            "route_id": meta.get("route_id"),
            "time": w,
        })
        path.append(u)
        cur = u

    path.reverse()
    legs.reverse()
    return dist[goal], path, legs


def pt_route_time_between_points(
    origin_xy: Tuple[int, int],
    dest_xy: Tuple[int, int],
    stations: StationsDict,
    routes: RoutesDict,
    transfers: TransfersDict,
    in_vehicle_per_hop: float = PT_IN_VEHICLE_PER_HOP,
    *,
    walk_radius: Optional[float] = None,
) -> PTRouteResult:
    """
    Canonical PT travel-time computation used for parity. See Rep tree for
    V9 §26.7 walk_radius kwarg semantics.
    """
    if walk_radius is None:
        s0 = nearest_station(origin_xy, stations)
        s1 = nearest_station(dest_xy, stations)
    else:
        s0 = nearest_station_within_radius(origin_xy, stations, walk_radius)
        s1 = nearest_station_within_radius(dest_xy, stations, walk_radius)

    graph = build_station_graph(routes, transfers, in_vehicle_per_hop=in_vehicle_per_hop)
    total, path, legs = dijkstra(graph, s0, s1)

    _PT_ROUTER_STATS["call_count"] = int(_PT_ROUTER_STATS.get("call_count", 0)) + 1
    if len(_PT_ROUTER_STATS["samples"]) < 25:
        _PT_ROUTER_STATS["samples"].append({
            "origin_xy": [origin_xy[0], origin_xy[1]],
            "dest_xy": [dest_xy[0], dest_xy[1]],
            "origin_station": s0,
            "dest_station": s1,
            "total_time": total,
            "path_len": len(path),
        })

    return PTRouteResult(total_time=total, station_path=path, legs=legs)


def _station_xy_any_mode(station_id: str, stations: StationsDict) -> Optional[Tuple[int, int]]:
    for mode in ("train", "bus"):
        xy = stations.get(mode, {}).get(station_id)
        if xy is not None:
            return xy
    return None


def door_to_door_walk_time(
    origin_xy: Tuple[int, int],
    dest_xy: Tuple[int, int],
    station_path: List[str],
    stations: StationsDict,
    walk_speed: float = WALK_SPEED_UNITS_PER_TICK,
) -> float:
    """Endpoint walk time in ticks: origin → first station + last station → dest.

    Uses shared `WALK_SPEED_UNITS_PER_TICK` (0.76) by default. Returns 0.0 if
    ``station_path`` is empty or an endpoint station is not in ``stations``.
    Used by V9 §27 to convert station-to-station PT times into door-to-door
    ``travel_time`` on both C and D public paths. Mirrors Rep tree.
    """
    if not station_path:
        return 0.0
    s0_xy = _station_xy_any_mode(station_path[0], stations)
    s1_xy = _station_xy_any_mode(station_path[-1], stations)
    if s0_xy is None or s1_xy is None:
        return 0.0
    d_first = _euclid(tuple(origin_xy), s0_xy)
    d_last = _euclid(s1_xy, tuple(dest_xy))
    return (d_first + d_last) / float(walk_speed)
