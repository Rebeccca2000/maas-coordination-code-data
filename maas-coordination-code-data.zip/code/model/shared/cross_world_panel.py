from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable
import csv
import hashlib
import json
import math
import random
import sys

from build_conference_frozen_inputs import (
    AGE_DISTRIBUTION,
    DISABILITY_WEIGHTS,
    HEALTH_WEIGHTS,
    INCOME_WEIGHTS,
    PAYMENT_WEIGHTS,
    TECH_ACCESS_WEIGHTS,
    build_hubs,
)
from shared_experiment_config import (
    GRID_HEIGHT,
    GRID_WIDTH,
    NUM_COMMUTERS,
    RANDOM_SEED,
    SIMULATION_STEPS,
    SMALL_WORLD_P,
)
from shared_frozen_inputs import (
    FrozenCommuterSpec,
    compute_commuter_fingerprint,
    compute_trip_request_fingerprint,
)
from shared_operator_heterogeneity import transform_centralized_price_overrides
from shared_pt_operating_assumptions import get_pt_mode_base_fare
from shared_supply_v2_config import get_v2_supply_definition
from shared_topology_v2 import get_small_world_map
from shared_trip_generator import TripSpec, generate_two_trip_day


REPO_ROOT = Path(__file__).resolve().parent
PANEL_ID = "cross_world_panel_v7"
PANEL_SCHEMA_VERSION = 2
CANONICAL_S1_VARIANT = "S1_base"
DESIGN_DIR = REPO_ROOT / "analysis_outputs" / "cross_world_panel_design_v7"
DESIGN_MANIFEST_PATH = DESIGN_DIR / "scenario_panel_manifest.md"
DESIGN_WORLD_TABLE_PATH = DESIGN_DIR / "scenario_world_table.csv"
FROZEN_PANEL_DIR = REPO_ROOT / "frozen_inputs" / PANEL_ID

CENTRALISED_CONFIG_DIR = (
    REPO_ROOT
    / "ABM_ETOP_framework"
    / "MaaS-Centralised"
    / "spf_abm_analysis_separate"
)
if str(CENTRALISED_CONFIG_DIR) not in sys.path:
    sys.path.insert(0, str(CENTRALISED_CONFIG_DIR))

from database_01 import (  # noqa: E402
    BACKGROUND_TRAFFIC_AMOUNT,
    BikeShare1_capacity,
    BikeShare1_price,
    BikeShare2_capacity,
    BikeShare2_price,
    UberLike1_cpacity,
    UberLike1_price,
    UberLike2_cpacity,
    UberLike2_price,
)


FIXED_DIMENSIONS = (
    "topology",
    "utility_logic",
    "architecture_pair",
    "metrics_and_validation",
    "generation_seed",
)


def _stable_hash(value: Any) -> str:
    return hashlib.sha256(
        json.dumps(value, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()[:16]


def _round_half_up(value: float, *, minimum: int = 1) -> int:
    return max(minimum, int(math.floor(float(value) + 0.5)))


@dataclass(frozen=True)
class CrossWorldScenarioV7:
    world_id: str
    scenario_name: str
    intended_stress_or_interpretation: str
    expected_relevance: str
    demand_scale_factor: float = 1.0
    direct_price_factor: float = 1.0
    pt_price_factor: float = 1.0
    direct_capacity_factor: float = 1.0
    background_traffic_factor: float = 1.0
    pt_wait_time_factor: float = 1.0
    pt_in_vehicle_time_factor: float = 1.0
    operator_niche_profile: str = "baseline"
    trip_pattern_profile: str = "baseline"
    morning_window: tuple[int, int] = (40, 56)
    evening_window: tuple[int, int] = (96, 112)

    @property
    def scenario_id(self) -> str:
        return f"{PANEL_ID}__{self.world_id}"

    @property
    def generation_seed(self) -> int:
        return int(RANDOM_SEED)

    def materialized_commuter_count(self) -> int:
        return _round_half_up(NUM_COMMUTERS * self.demand_scale_factor)

    def materialized_background_traffic(self) -> int:
        return _round_half_up(BACKGROUND_TRAFFIC_AMOUNT * self.background_traffic_factor, minimum=0)

    def changed_dimensions(self) -> tuple[str, ...]:
        fields: list[str] = []
        if not math.isclose(self.demand_scale_factor, 1.0):
            fields.append("demand_scale")
        if not math.isclose(self.direct_price_factor, 1.0):
            fields.append("direct_price_factor")
        if not math.isclose(self.pt_price_factor, 1.0):
            fields.append("pt_price_factor")
        if not math.isclose(self.direct_capacity_factor, 1.0):
            fields.append("direct_capacity_factor")
        if not math.isclose(self.background_traffic_factor, 1.0):
            fields.append("background_traffic_factor")
        if not math.isclose(self.pt_wait_time_factor, 1.0):
            fields.append("pt_wait_time_factor")
        if not math.isclose(self.pt_in_vehicle_time_factor, 1.0):
            fields.append("pt_in_vehicle_time_factor")
        if self.operator_niche_profile != "baseline":
            fields.append("operator_niche_profile")
        if self.trip_pattern_profile != "baseline":
            fields.append("trip_pattern_profile")
        if self.morning_window != (40, 56):
            fields.append("morning_window")
        if self.evening_window != (96, 112):
            fields.append("evening_window")
        return tuple(fields)

    def changed_dimensions_text(self) -> str:
        parts: list[str] = []
        if not math.isclose(self.demand_scale_factor, 1.0):
            parts.append(f"demand_scale={self.demand_scale_factor:.2f}x")
        if not math.isclose(self.direct_price_factor, 1.0):
            parts.append(f"direct_price_factor={self.direct_price_factor:.2f}x")
        if not math.isclose(self.pt_price_factor, 1.0):
            parts.append(f"pt_price_factor={self.pt_price_factor:.2f}x")
        if not math.isclose(self.direct_capacity_factor, 1.0):
            parts.append(f"direct_capacity_factor={self.direct_capacity_factor:.2f}x")
        if not math.isclose(self.background_traffic_factor, 1.0):
            parts.append(f"background_traffic_factor={self.background_traffic_factor:.2f}x")
        if not math.isclose(self.pt_wait_time_factor, 1.0):
            parts.append(f"pt_wait_time_factor={self.pt_wait_time_factor:.2f}x")
        if not math.isclose(self.pt_in_vehicle_time_factor, 1.0):
            parts.append(f"pt_in_vehicle_time_factor={self.pt_in_vehicle_time_factor:.2f}x")
        if self.operator_niche_profile != "baseline":
            parts.append(f"operator_niche_profile={self.operator_niche_profile}")
        if self.trip_pattern_profile != "baseline":
            parts.append(f"trip_pattern_profile={self.trip_pattern_profile}")
        if self.morning_window != (40, 56):
            parts.append(f"morning_window={self.morning_window[0]}-{self.morning_window[1]}")
        if self.evening_window != (96, 112):
            parts.append(f"evening_window={self.evening_window[0]}-{self.evening_window[1]}")
        return "; ".join(parts) if parts else "none"

    def fixed_dimensions_text(self) -> str:
        return "; ".join(FIXED_DIMENSIONS)

    def exogenous_settings(self) -> dict[str, Any]:
        return {
            "demand_scale_factor": round(self.demand_scale_factor, 6),
            "direct_price_factor": round(self.direct_price_factor, 6),
            "pt_price_factor": round(self.pt_price_factor, 6),
            "direct_capacity_factor": round(self.direct_capacity_factor, 6),
            "background_traffic_factor": round(self.background_traffic_factor, 6),
            "pt_wait_time_factor": round(self.pt_wait_time_factor, 6),
            "pt_in_vehicle_time_factor": round(self.pt_in_vehicle_time_factor, 6),
            "operator_niche_profile": self.operator_niche_profile,
            "trip_pattern_profile": self.trip_pattern_profile,
            "morning_window": list(self.morning_window),
            "evening_window": list(self.evening_window),
            "baseline_num_commuters": int(NUM_COMMUTERS),
            "materialized_commuter_count": self.materialized_commuter_count(),
            "baseline_background_traffic_amount": int(BACKGROUND_TRAFFIC_AMOUNT),
            "materialized_background_traffic_amount": self.materialized_background_traffic(),
            "capacity_rounding_rule": "floor(scaled_value + 0.5), minimum 1",
            "direct_price_rule": (
                "Direct-provider prices scale by direct_price_factor. "
                "The v7 price worlds use stronger shocks than the original panel."
            ),
            "pt_price_rule": (
                "PT fares scale by pt_price_factor in both architectures using the shared PT fare assumptions."
            ),
            "direct_capacity_rule": (
                "Direct-provider capacities scale by direct_capacity_factor using floor(scaled_value + 0.5), minimum 1."
            ),
            "background_traffic_rule": (
                "Road background traffic scales by background_traffic_factor. "
                "Pattern-profile worlds approximate corridor stress by concentrating OD demand into the same travel structure."
            ),
            "peak_pressure_rule": (
                "Morning/evening trip departures use world-specific windows so v7 can create exact peak compression."
            ),
            "pt_stress_rule": (
                "PT generalized time changes through pt_wait_time_factor and "
                "pt_in_vehicle_time_factor, applied consistently in both architectures."
            ),
            "operator_niche_rule": (
                "Decentralised on-demand providers can adopt world-specific niche coverage "
                "profiles to test specialization in dispersed or reverse-commute demand fields."
            ),
        }


WORLD_SCENARIOS_V7: tuple[CrossWorldScenarioV7, ...] = (
    CrossWorldScenarioV7(
        world_id="W00_baseline_reference",
        scenario_name="Baseline Reference",
        intended_stress_or_interpretation="Reference V7 world with unchanged timing, PT service, niche coverage, pricing, capacity, and geography assumptions",
        expected_relevance="Anchors every V7 delta and remains the neutral benchmark for the strengthened world family",
    ),
    CrossWorldScenarioV7(
        world_id="W01_polycentric_direct_abundance",
        scenario_name="Polycentric Direct Abundance",
        intended_stress_or_interpretation="Low-pressure polycentric world with much cheaper direct service, much worse PT generalized cost, more direct capacity, lower congestion, and localized operator niches",
        expected_relevance="Acts as the main decentralised-friendly abundance world and should be strong enough to challenge centralised mode-share and burden advantages",
        demand_scale_factor=0.85,
        direct_price_factor=0.50,
        pt_price_factor=1.25,
        direct_capacity_factor=1.50,
        background_traffic_factor=0.70,
        pt_wait_time_factor=1.35,
        pt_in_vehicle_time_factor=1.20,
        operator_niche_profile="polycentric_local_specialists",
        trip_pattern_profile="polycentric_spread",
        morning_window=(34, 62),
        evening_window=(90, 118),
    ),
    CrossWorldScenarioV7(
        world_id="W02_peak_compressed_high_demand",
        scenario_name="Peak-Compressed High Demand",
        intended_stress_or_interpretation="Higher demand concentrated into narrower commuter peaks with CBD-heavy OD structure, worse background traffic, and mild PT slowdown",
        expected_relevance="Keeps a clear centralised-favoring scarcity anchor where coordination and guaranteed access should still matter",
        demand_scale_factor=1.25,
        background_traffic_factor=1.30,
        pt_wait_time_factor=1.10,
        pt_in_vehicle_time_factor=1.05,
        trip_pattern_profile="cbd_peak_concentration",
        morning_window=(44, 50),
        evening_window=(100, 106),
    ),
    CrossWorldScenarioV7(
        world_id="W03_pt_service_drag",
        scenario_name="PT Service Drag",
        intended_stress_or_interpretation="PT service is much slower and more expensive while outer-ring demand patterns and specialist direct operators make direct substitution structurally attractive",
        expected_relevance="Provides an extreme PT-drag world so decentralised should win burden unless PT remains too dominant in the framework",
        direct_price_factor=0.80,
        pt_price_factor=1.25,
        direct_capacity_factor=1.20,
        background_traffic_factor=0.90,
        pt_wait_time_factor=1.70,
        pt_in_vehicle_time_factor=1.45,
        operator_niche_profile="outer_ring_specialists",
        trip_pattern_profile="outer_ring_connectors",
        morning_window=(36, 60),
        evening_window=(92, 116),
    ),
    CrossWorldScenarioV7(
        world_id="W04_deep_direct_discount",
        scenario_name="Deep Direct Discount",
        intended_stress_or_interpretation="Direct on-demand supply is deeply discounted while PT prices and PT time both worsen in a dispersed specialist-operator geography",
        expected_relevance="This is the strongest direct-friendly world and should be the best candidate for flipping both burden and travel-time equity toward decentralised",
        direct_price_factor=0.45,
        pt_price_factor=1.35,
        direct_capacity_factor=1.35,
        background_traffic_factor=0.75,
        pt_wait_time_factor=1.55,
        pt_in_vehicle_time_factor=1.30,
        operator_niche_profile="polycentric_local_specialists",
        trip_pattern_profile="polycentric_spread",
        morning_window=(34, 62),
        evening_window=(90, 118),
    ),
    CrossWorldScenarioV7(
        world_id="W05_outer_ring_specialists",
        scenario_name="Outer-Ring Specialists",
        intended_stress_or_interpretation="Outer-ring commute patterns combine with specialist direct providers and heavy PT drag to reward localized operator knowledge",
        expected_relevance="Strengthens the niche-coverage test so decentralised should win burden in a clearly non-CBD world rather than only on price",
        direct_price_factor=0.70,
        pt_price_factor=1.20,
        direct_capacity_factor=1.30,
        background_traffic_factor=0.80,
        pt_wait_time_factor=1.50,
        pt_in_vehicle_time_factor=1.25,
        operator_niche_profile="outer_ring_specialists",
        trip_pattern_profile="outer_ring_connectors",
        morning_window=(36, 60),
        evening_window=(92, 116),
    ),
    CrossWorldScenarioV7(
        world_id="W06_severe_direct_capacity_tightness",
        scenario_name="Severe Direct Capacity Tightness",
        intended_stress_or_interpretation="Direct capacity falls sharply while demand compresses into CBD peaks and congestion rises, creating hard scarcity",
        expected_relevance="Keeps the second centralised-favoring scarcity anchor and should continue to expose decentralised access fragility under hard shortages",
        demand_scale_factor=1.15,
        direct_capacity_factor=0.45,
        background_traffic_factor=1.20,
        pt_wait_time_factor=1.05,
        pt_in_vehicle_time_factor=1.05,
        trip_pattern_profile="cbd_peak_concentration",
        morning_window=(44, 50),
        evening_window=(100, 106),
    ),
    CrossWorldScenarioV7(
        world_id="W07_reverse_commute_niche_advantage",
        scenario_name="Reverse-Commute Niche Advantage",
        intended_stress_or_interpretation="Reverse-commute and suburb-suburb travel patterns combine with specialist direct niches, cheaper direct service, and strong PT drag",
        expected_relevance="Adds a second strong decentralised-friendly non-CBD world where specialization should matter more than global coordination",
        demand_scale_factor=0.90,
        direct_price_factor=0.65,
        pt_price_factor=1.25,
        direct_capacity_factor=1.30,
        background_traffic_factor=0.75,
        pt_wait_time_factor=1.60,
        pt_in_vehicle_time_factor=1.30,
        operator_niche_profile="reverse_commute_specialists",
        trip_pattern_profile="reverse_commute_bias",
        morning_window=(34, 60),
        evening_window=(90, 116),
    ),
)


def build_shared_world_map():
    return get_small_world_map(
        p_shortcut=SMALL_WORLD_P,
        seed=RANDOM_SEED,
        grid_width=GRID_WIDTH,
        grid_height=GRID_HEIGHT,
    )


def generate_world_trips(
    scenario: CrossWorldScenarioV7,
    *,
    shared_map=None,
) -> list[TripSpec]:
    sw = shared_map or build_shared_world_map()
    hubs = build_hubs(sw.stations)
    days = max(1, (SIMULATION_STEPS + 143) // 144)
    trips: list[TripSpec] = []
    for canonical_commuter_id in range(scenario.materialized_commuter_count()):
        for day_idx in range(days):
            outbound, inbound = generate_two_trip_day(
                base_seed=scenario.generation_seed,
                commuter_id=canonical_commuter_id,
                grid_w=GRID_WIDTH,
                grid_h=GRID_HEIGHT,
                hubs=hubs,
                day_index=day_idx,
                morning_window=scenario.morning_window,
                evening_window=scenario.evening_window,
                pattern_profile=scenario.trip_pattern_profile,
            )
            trips.extend((outbound, inbound))
    return trips


def generate_world_commuters(
    scenario: CrossWorldScenarioV7,
    trips: list[TripSpec],
) -> list[dict[str, object]]:
    trips_by_commuter: dict[int, list[TripSpec]] = {}
    for trip in trips:
        trips_by_commuter.setdefault(trip.commuter_id, []).append(trip)
    for commuter_id in list(trips_by_commuter):
        trips_by_commuter[commuter_id].sort(
            key=lambda trip: (trip.day_index, trip.trip_index)
        )

    age_buckets = list(AGE_DISTRIBUTION.items())
    commuters: list[dict[str, object]] = []
    for canonical_commuter_id in range(scenario.materialized_commuter_count()):
        rnd = random.Random(scenario.generation_seed + canonical_commuter_id * 9973)
        initial_location = list(trips_by_commuter[canonical_commuter_id][0].origin_xy)
        age_range = rnd.choices(
            [item[0] for item in age_buckets],
            weights=[item[1] for item in age_buckets],
        )[0]
        commuters.append(
            {
                "canonical_commuter_id": canonical_commuter_id,
                "initial_location": initial_location,
                "age": rnd.randint(age_range[0], age_range[1]),
                "income_level": rnd.choices(
                    ["low", "middle", "high"],
                    weights=INCOME_WEIGHTS,
                )[0],
                "has_disability": rnd.choices(
                    [True, False],
                    weights=DISABILITY_WEIGHTS,
                )[0],
                "tech_access": rnd.choices(
                    [True, False],
                    weights=TECH_ACCESS_WEIGHTS,
                )[0],
                "health_status": rnd.choices(
                    ["good", "poor"],
                    weights=HEALTH_WEIGHTS,
                )[0],
                "payment_scheme": rnd.choices(
                    ["PAYG", "subscription"],
                    weights=PAYMENT_WEIGHTS,
                )[0],
            }
        )
    return commuters


def build_fixed_commuters_payload(
    scenario: CrossWorldScenarioV7,
    commuters: list[dict[str, object]],
) -> dict[str, Any]:
    return {
        "schema_version": PANEL_SCHEMA_VERSION,
        "panel_id": PANEL_ID,
        "world_id": scenario.world_id,
        "scenario_id": scenario.scenario_id,
        "scenario_name": scenario.scenario_name,
        "seed": scenario.generation_seed,
        "grid_width": GRID_WIDTH,
        "grid_height": GRID_HEIGHT,
        "commuter_count": len(commuters),
        "commuters": commuters,
    }


def build_fixed_trip_requests_payload(
    scenario: CrossWorldScenarioV7,
    trips: list[TripSpec],
) -> dict[str, Any]:
    return {
        "schema_version": PANEL_SCHEMA_VERSION,
        "panel_id": PANEL_ID,
        "world_id": scenario.world_id,
        "scenario_id": scenario.scenario_id,
        "scenario_name": scenario.scenario_name,
        "seed": scenario.generation_seed,
        "simulation_steps": SIMULATION_STEPS,
        "planned_trip_count": len(trips),
        "trip_requests": [
            {
                "canonical_trip_id": trip.trip_id,
                "canonical_commuter_id": trip.commuter_id,
                "trip_index": trip.trip_index,
                "day_index": trip.day_index,
                "depart_step": trip.depart_step,
                "origin_xy": list(trip.origin_xy),
                "dest_xy": list(trip.dest_xy),
                "purpose": trip.purpose,
            }
            for trip in trips
        ],
    }


def compute_commuter_payload_fingerprint(
    commuters: Iterable[dict[str, object]],
) -> str:
    return compute_commuter_fingerprint(
        [
            FrozenCommuterSpec(
                canonical_commuter_id=int(commuter["canonical_commuter_id"]),
                initial_location=tuple(commuter["initial_location"]),
                age=int(commuter["age"]),
                income_level=str(commuter["income_level"]),
                has_disability=bool(commuter["has_disability"]),
                tech_access=bool(commuter["tech_access"]),
                health_status=str(commuter["health_status"]),
                payment_scheme=str(commuter["payment_scheme"]),
            )
            for commuter in commuters
        ]
    )


def build_world_config_payload(
    scenario: CrossWorldScenarioV7,
    *,
    map_fingerprint: str,
) -> dict[str, Any]:
    return {
        "schema_version": PANEL_SCHEMA_VERSION,
        "panel_id": PANEL_ID,
        "world_id": scenario.world_id,
        "scenario_id": scenario.scenario_id,
        "scenario_name": scenario.scenario_name,
        "source_design_manifest": str(DESIGN_MANIFEST_PATH),
        "source_design_world_table": str(DESIGN_WORLD_TABLE_PATH),
        "generation_seed": scenario.generation_seed,
        "grid_width": GRID_WIDTH,
        "grid_height": GRID_HEIGHT,
        "simulation_steps": SIMULATION_STEPS,
        "small_world_p": SMALL_WORLD_P,
        "map_fingerprint": map_fingerprint,
        "fixed_dimensions": list(FIXED_DIMENSIONS),
        "changed_dimensions": list(scenario.changed_dimensions()),
        "changed_dimensions_text": scenario.changed_dimensions_text(),
        "intended_stress_or_interpretation": scenario.intended_stress_or_interpretation,
        "expected_relevance_to_which_system_is_better_in_which_way": scenario.expected_relevance,
        "architecture_pair_reference": {
            "centralised": "revised_world_centralised_reference",
            "decentralised": "S2_medium_visibility_reference",
        },
        "world_level_exogenous_settings": scenario.exogenous_settings(),
        "frozen_generation_rules": {
            "trip_builder": "shared_trip_generator.generate_two_trip_day",
            "trip_seed_rule": "base_seed = RANDOM_SEED for every world build in v7",
            "commuter_attribute_rule": "build_conference_frozen_inputs commuter attribute distributions reused unchanged",
            "days_derived_from_simulation_steps": max(1, (SIMULATION_STEPS + 143) // 144),
        },
    }


def get_centralised_direct_price_rows(scenario: CrossWorldScenarioV7) -> list[dict[str, Any]]:
    base_prices = transform_centralized_price_overrides(
        {
            "UberLike1": UberLike1_price,
            "UberLike2": UberLike2_price,
            "BikeShare1": BikeShare1_price,
            "BikeShare2": BikeShare2_price,
        },
        variant=CANONICAL_S1_VARIANT,
    )
    provider_groups = {
        "UberLike1": "car",
        "UberLike2": "car",
        "BikeShare1": "bike",
        "BikeShare2": "bike",
    }
    rows: list[dict[str, Any]] = []
    for provider_name in sorted(base_prices):
        baseline = float(base_prices[provider_name])
        world_value = round(baseline * scenario.direct_price_factor, 6)
        rows.append(
            {
                "architecture": "centralised",
                "provider_name": provider_name,
                "provider_group": provider_groups[provider_name],
                "mode_set": provider_groups[provider_name],
                "price_component": "direct",
                "base_price_baseline": round(baseline, 6),
                "base_price_world": world_value,
                "distance_rate_baseline": "",
                "distance_rate_world": "",
                "direct_price_factor": round(scenario.direct_price_factor, 6),
                "pt_price_factor": round(scenario.pt_price_factor, 6),
                "rule_applied": "direct provider base price scaled",
            }
        )
    return rows


def get_decentralised_direct_price_rows(scenario: CrossWorldScenarioV7) -> list[dict[str, Any]]:
    profiles = get_v2_supply_definition(CANONICAL_S1_VARIANT)["ondemand_operators"]
    rows: list[dict[str, Any]] = []
    for profile in profiles:
        baseline_price = float(profile["base_price"])
        baseline_distance_rate = float(profile["distance_rate"])
        rows.append(
            {
                "architecture": "decentralised",
                "provider_name": str(profile["operator_id"]),
                "provider_group": "ondemand",
                "mode_set": "|".join(profile.get("mode_set", []) or []),
                "price_component": "direct",
                "base_price_baseline": round(baseline_price, 6),
                "base_price_world": round(
                    baseline_price * scenario.direct_price_factor,
                    6,
                ),
                "distance_rate_baseline": round(baseline_distance_rate, 6),
                "distance_rate_world": round(
                    baseline_distance_rate * scenario.direct_price_factor,
                    6,
                ),
                "direct_price_factor": round(scenario.direct_price_factor, 6),
                "pt_price_factor": round(scenario.pt_price_factor, 6),
                "rule_applied": "ondemand base_price and distance_rate scaled",
            }
        )
    return rows


def get_shared_pt_price_rows(scenario: CrossWorldScenarioV7) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for architecture in ("centralised", "decentralised"):
        for mode, peak_step, offpeak_step in (("bus", 40, 10), ("train", 40, 10)):
            rows.append(
                {
                    "architecture": architecture,
                    "provider_name": mode,
                    "provider_group": "pt",
                    "mode_set": mode,
                    "price_component": "pt",
                    "base_price_baseline": get_pt_mode_base_fare(mode, peak_step, price_factor=1.0),
                    "base_price_world": get_pt_mode_base_fare(mode, peak_step, price_factor=scenario.pt_price_factor),
                    "distance_rate_baseline": get_pt_mode_base_fare(mode, offpeak_step, price_factor=1.0),
                    "distance_rate_world": get_pt_mode_base_fare(mode, offpeak_step, price_factor=scenario.pt_price_factor),
                    "direct_price_factor": round(scenario.direct_price_factor, 6),
                    "pt_price_factor": round(scenario.pt_price_factor, 6),
                    "rule_applied": "shared PT fare assumptions scaled by pt_price_factor",
                }
            )
    return rows


def get_world_price_summary_rows(scenario: CrossWorldScenarioV7) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    combined = (
        get_centralised_direct_price_rows(scenario)
        + get_decentralised_direct_price_rows(scenario)
        + get_shared_pt_price_rows(scenario)
    )
    for row in combined:
        rows.append(
            {
                "world_id": scenario.world_id,
                "scenario_name": scenario.scenario_name,
                **row,
            }
        )
    return rows


def get_centralised_capacity_rows(scenario: CrossWorldScenarioV7) -> list[dict[str, Any]]:
    base_capacities = {
        "UberLike1": int(UberLike1_cpacity),
        "UberLike2": int(UberLike2_cpacity),
        "BikeShare1": int(BikeShare1_capacity),
        "BikeShare2": int(BikeShare2_capacity),
    }
    provider_groups = {
        "UberLike1": "car",
        "UberLike2": "car",
        "BikeShare1": "bike",
        "BikeShare2": "bike",
    }
    rows: list[dict[str, Any]] = []
    for provider_name in sorted(base_capacities):
        baseline = int(base_capacities[provider_name])
        rows.append(
            {
                "architecture": "centralised",
                "provider_name": provider_name,
                "provider_group": provider_groups[provider_name],
                "mode_set": provider_groups[provider_name],
                "capacity_baseline": baseline,
                "capacity_world": _round_half_up(
                    baseline * scenario.direct_capacity_factor
                ),
                "direct_capacity_factor": round(scenario.direct_capacity_factor, 6),
                "rounding_rule": "floor(scaled_value + 0.5), minimum 1",
                "rule_applied": "direct provider capacity scaled",
            }
        )
    return rows


def get_decentralised_capacity_rows(scenario: CrossWorldScenarioV7) -> list[dict[str, Any]]:
    profiles = get_v2_supply_definition(CANONICAL_S1_VARIANT)["ondemand_operators"]
    rows: list[dict[str, Any]] = []
    for profile in profiles:
        baseline = int(profile["fleet_capacity"])
        rows.append(
            {
                "architecture": "decentralised",
                "provider_name": str(profile["operator_id"]),
                "provider_group": "ondemand",
                "mode_set": "|".join(profile.get("mode_set", []) or []),
                "capacity_baseline": baseline,
                "capacity_world": _round_half_up(
                    baseline * scenario.direct_capacity_factor
                ),
                "direct_capacity_factor": round(scenario.direct_capacity_factor, 6),
                "rounding_rule": "floor(scaled_value + 0.5), minimum 1",
                "rule_applied": "ondemand fleet_capacity scaled",
            }
        )
    return rows


def get_world_capacity_summary_rows(scenario: CrossWorldScenarioV7) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for row in get_centralised_capacity_rows(scenario) + get_decentralised_capacity_rows(scenario):
        rows.append(
            {
                "world_id": scenario.world_id,
                "scenario_name": scenario.scenario_name,
                **row,
            }
        )
    return rows


def build_panel_manifest_payload() -> dict[str, Any]:
    return {
        "schema_version": PANEL_SCHEMA_VERSION,
        "panel_id": PANEL_ID,
        "world_count": len(WORLD_SCENARIOS_V7),
        "world_ids": [scenario.world_id for scenario in WORLD_SCENARIOS_V7],
        "world_scenario_fingerprint": _stable_hash(
            [
                {
                    "world_id": scenario.world_id,
                    "settings": scenario.exogenous_settings(),
                }
                for scenario in WORLD_SCENARIOS_V7
            ]
        ),
    }


def write_design_package() -> list[dict[str, Any]]:
    DESIGN_DIR.mkdir(parents=True, exist_ok=True)
    rows = [_design_row(scenario) for scenario in WORLD_SCENARIOS_V7]
    with DESIGN_WORLD_TABLE_PATH.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        for row in rows:
            writer.writerow(row)
    DESIGN_MANIFEST_PATH.write_text(_build_design_manifest_markdown(rows), encoding="utf-8")
    return rows


def load_design_rows() -> list[dict[str, str]]:
    if not DESIGN_WORLD_TABLE_PATH.exists() or not DESIGN_MANIFEST_PATH.exists():
        write_design_package()
    with DESIGN_WORLD_TABLE_PATH.open(newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def _design_row(scenario: CrossWorldScenarioV7) -> dict[str, Any]:
    return {
        "world_id": scenario.world_id,
        "scenario_name": scenario.scenario_name,
        "intended_stress_or_interpretation": scenario.intended_stress_or_interpretation,
        "expected_relevance": scenario.expected_relevance,
        "demand_scale_factor": round(scenario.demand_scale_factor, 6),
        "direct_price_factor": round(scenario.direct_price_factor, 6),
        "pt_price_factor": round(scenario.pt_price_factor, 6),
        "direct_capacity_factor": round(scenario.direct_capacity_factor, 6),
        "background_traffic_factor": round(scenario.background_traffic_factor, 6),
        "pt_wait_time_factor": round(scenario.pt_wait_time_factor, 6),
        "pt_in_vehicle_time_factor": round(scenario.pt_in_vehicle_time_factor, 6),
        "operator_niche_profile": scenario.operator_niche_profile,
        "trip_pattern_profile": scenario.trip_pattern_profile,
        "morning_window": f"{scenario.morning_window[0]}-{scenario.morning_window[1]}",
        "evening_window": f"{scenario.evening_window[0]}-{scenario.evening_window[1]}",
        "materialized_commuter_count": scenario.materialized_commuter_count(),
        "materialized_background_traffic_amount": scenario.materialized_background_traffic(),
        "changed_dimensions_text": scenario.changed_dimensions_text(),
        "fixed_dimensions_text": scenario.fixed_dimensions_text(),
    }


def _build_design_manifest_markdown(rows: list[dict[str, Any]]) -> str:
    lines = [
        "# Cross-World Panel Design v7",
        "",
        "## Design Goals",
        "",
        "- Strengthen the decentralised-favoring worlds further while preserving W02 and W06 as clear scarcity anchors.",
        "- Push PT wait-time and in-vehicle degradation harder so dispersed direct-friendly worlds become materially different in both models.",
        "- Keep operator-niche profiles active in non-CBD worlds so specialization can compound with price and PT stress.",
        "- Use this prep layer to test whether stronger worlds are enough before introducing income-targeted pricing logic.",
        "",
        "## World Summary",
        "",
        "| world_id | scenario_name | demand | direct_price | pt_price | direct_capacity | bg_traffic | pt_wait | pt_inveh | niche | pattern | morning | evening |",
        "|---|---|---:|---:|---:|---:|---:|---:|---:|---|---|---|---|",
    ]
    for row in rows:
        lines.append(
            f"| {row['world_id']} | {row['scenario_name']} | {row['demand_scale_factor']:.2f} | "
            f"{row['direct_price_factor']:.2f} | {row['pt_price_factor']:.2f} | "
            f"{row['direct_capacity_factor']:.2f} | {row['background_traffic_factor']:.2f} | "
            f"{row['pt_wait_time_factor']:.2f} | {row['pt_in_vehicle_time_factor']:.2f} | "
            f"{row['operator_niche_profile']} | {row['trip_pattern_profile']} | "
            f"{row['morning_window']} | {row['evening_window']} |"
        )
    lines.extend(
        [
            "",
            "## Notes",
            "",
            "- `cbd_peak_concentration` keeps W02 and W06 as the strongest coordinated-scarcity worlds in the panel.",
            "- `polycentric_spread`, `outer_ring_connectors`, and `reverse_commute_bias` make the demand field less monocentric and less peak-synchronous.",
            "- PT stress is materially stronger than V7's predecessor and is modeled through shared wait-time and in-vehicle multipliers rather than architecture-specific hacks.",
            "- Operator niches currently affect decentralised direct providers only; if MSEL still does not flip after V7, the next step should be explicit income-targeted pricing rather than still-harsher world scalars.",
            "",
        ]
    )
    return "\n".join(lines) + "\n"


__all__ = [
    "DESIGN_DIR",
    "DESIGN_MANIFEST_PATH",
    "DESIGN_WORLD_TABLE_PATH",
    "FROZEN_PANEL_DIR",
    "PANEL_ID",
    "PANEL_SCHEMA_VERSION",
    "WORLD_SCENARIOS_V7",
    "CrossWorldScenarioV7",
    "_stable_hash",
    "build_fixed_commuters_payload",
    "build_fixed_trip_requests_payload",
    "build_panel_manifest_payload",
    "build_shared_world_map",
    "build_world_config_payload",
    "compute_commuter_payload_fingerprint",
    "generate_world_commuters",
    "generate_world_trips",
    "get_world_capacity_summary_rows",
    "get_world_price_summary_rows",
    "load_design_rows",
    "write_design_package",
]
