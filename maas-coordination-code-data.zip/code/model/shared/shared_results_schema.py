from __future__ import annotations

import csv
from datetime import datetime, timezone
from typing import Any, Dict
import json
import os


REQUIRED_FIELDS = [
    "run_id",
    "seed",
    "model_type",
    "map_fingerprint",
    "trip_fingerprint",
    "num_requests",
    "num_matched",
    "match_rate",
    "avg_travel_time",
    "p95_travel_time",
    "avg_wait_time",
    "total_system_travel_time",
    "by_income_group",
    "mode_share_by_income",
    "travel_time_by_income",
    "price_by_income_group",
]

REQUEST_COMPARISON_FIELDS = [
    "request_id",
    "commuter_id",
    "income_group",
    "model",
    "outcome",
    "chosen_mode",
    "free_flow_travel_time",
    "congestion_adjusted_travel_time",
    "travel_time",
    "scored_travel_time_basis",
    "price",
    "failure_reason",
]

REQUEST_COMPARISON_OPTIONAL_FIELDS = [
    "seed",
    "bundle_used",
    "operator_usage",
    "operator_type",
    "provider_id",
    "failure_stage",
    "candidate_bundle_count",
    "request_offer_count",
    "operator_count_seen",
    "mode_type_count_seen",
    # V9 §1.2b two-layer price accounting columns. Consumer-facing net price,
    # system-side gross price, and DRC subsidy. Populated by Phase 1.3+ runners
    # under `V9_NEUTRAL_SPEC=1`; may be None on legacy runs.
    "consumer_price",
    "system_net_cost",
    "subsidy",
    # V9 STOP #1(bis) ruling: two-layer accounting instrument, live on every
    # success row (both arms). `card_only_price` is the pure Layer-A fare
    # (shared_fare_card) recomputed on the row's mode / distance / time — a
    # counterfactual price with no Layer-B mechanism. `price_formation_delta`
    # = consumer_price − card_only_price; positive = commuter paid more than
    # the card (Layer B surge/premium), negative = commuter paid less (Layer
    # B subsidy/discount).
    "card_only_price",
    "price_formation_delta",
]


def normalize_run_record(record: Dict[str, Any]) -> Dict[str, Any]:
    normalized = {field: record.get(field) for field in REQUIRED_FIELDS}
    normalized["recorded_at_utc"] = datetime.now(timezone.utc).isoformat()
    return normalized


def append_run_record_jsonl(record: Dict[str, Any], output_path: str) -> Dict[str, Any]:
    normalized = normalize_run_record(record)
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    with open(output_path, "a", encoding="utf-8") as fh:
        fh.write(json.dumps(normalized, sort_keys=True) + "\n")
    return normalized


def write_request_comparison_csv(rows: list[Dict[str, Any]], output_path: str) -> str:
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    fieldnames = REQUEST_COMPARISON_FIELDS + REQUEST_COMPARISON_OPTIONAL_FIELDS
    with open(output_path, "w", encoding="utf-8", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field) for field in fieldnames})
    return output_path
