from __future__ import annotations

from datetime import datetime, timezone
from hashlib import sha256
from typing import Any, Dict, Iterable, Mapping
import json
import os


def compute_full_demand_trip_fingerprint(trip_plans: Mapping[Any, Iterable[Any]]) -> str:
    rows = []
    for trips in trip_plans.values():
        for trip in trips:
            rows.append(
                (
                    int(_trip_attr(trip, "commuter_id", -1)),
                    int(_trip_attr(trip, "day_index", 0)),
                    int(_trip_attr(trip, "trip_index", 0)),
                    str(_trip_attr(trip, "trip_id")),
                    int(_trip_attr(trip, "depart_step", -1)),
                    list(_trip_attr(trip, "origin_xy", [])),
                    list(_trip_attr(trip, "dest_xy", [])),
                    str(_trip_attr(trip, "purpose", "")),
                )
            )
    rows.sort(key=lambda row: (row[0], row[1], row[2], row[3]))
    return sha256(json.dumps(rows, sort_keys=True).encode("utf-8")).hexdigest()[:16]


def count_planned_trips(trip_plans: Mapping[Any, Iterable[Any]]) -> int:
    return sum(len(list(trips)) for trips in trip_plans.values())


def summarize_income_distribution(income_values: Iterable[Any]) -> Dict[str, int]:
    counts: Dict[str, int] = {}
    for raw_value in income_values:
        value = str(raw_value or "unknown").strip().lower()
        counts[value] = counts.get(value, 0) + 1
    return dict(sorted(counts.items()))


def write_matching_validation_artifact(record: Dict[str, Any], output_path: str) -> Dict[str, Any]:
    payload = dict(record)
    payload["recorded_at_utc"] = datetime.now(timezone.utc).isoformat()
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as fh:
        json.dump(payload, fh, sort_keys=True, indent=2)
    return payload


def default_matching_validation_path(results_path: str, model_type: str, seed: int) -> str:
    base_dir = os.path.dirname(results_path) or "."
    safe_model_type = str(model_type).replace("/", "_")
    return os.path.join(
        base_dir,
        f"matching_validation_{safe_model_type}_seed{int(seed)}.json",
    )


def _trip_attr(trip: Any, attr_name: str, default: Any = None) -> Any:
    return getattr(trip, attr_name, default)
