from __future__ import annotations

from collections import Counter
from typing import Any, Dict, Iterable, Mapping


INCOME_LEVELS = ("low", "middle", "high")
MODE_CATEGORIES = ("car", "bike", "public", "walk", "bundle", "other")


def canonical_income_level(value: Any) -> str:
    """Normalize income labels used by both repos."""
    text = str(value or "").strip().lower()
    if text in INCOME_LEVELS:
        return text
    return "unknown"


def canonical_mode_category(value: Any) -> str:
    """Map repo-specific mode labels into comparison-safe categories."""
    text = str(value or "").strip().lower()

    if not text:
        return "other"
    if "maas" in text or "bundle" in text:
        return "bundle"
    if "bike" in text:
        return "bike"
    if text in {"bus", "train", "public", "public_route", "public transport"}:
        return "public"
    if "bus" in text or "train" in text:
        return "public"
    if "walk" in text:
        return "walk"
    if text in {"car", "taxi"} or "uber" in text:
        return "car"
    return "other"


def summarize_mode_share_by_income(
    records: Iterable[Mapping[str, Any]],
    income_by_commuter: Mapping[Any, Any],
    *,
    commuter_id_key: str = "commuter_id",
    mode_key: str = "mode",
) -> Dict[str, Dict[str, Any]]:
    """Aggregate canonical mode shares by income group."""
    counts_by_income = _init_income_buckets()

    for record in records:
        commuter_id = record.get(commuter_id_key)
        income = canonical_income_level(income_by_commuter.get(commuter_id))
        if income == "unknown":
            continue

        mode = canonical_mode_category(record.get(mode_key))
        counts_by_income[income][mode] += 1

    output: Dict[str, Dict[str, Any]] = {}
    for income in INCOME_LEVELS:
        mode_counts = counts_by_income[income]
        trip_count = sum(mode_counts.values())
        mode_shares = {
            mode: (mode_counts.get(mode, 0) / trip_count) if trip_count > 0 else 0.0
            for mode in MODE_CATEGORIES
        }
        output[income] = {
            "trip_count": trip_count,
            "mode_counts": {mode: mode_counts.get(mode, 0) for mode in MODE_CATEGORIES},
            "mode_shares": mode_shares,
        }
    return output


def summarize_travel_time_by_income(
    records: Iterable[Mapping[str, Any]],
    income_by_commuter: Mapping[Any, Any],
    *,
    commuter_id_key: str = "commuter_id",
    duration_key: str = "duration",
) -> Dict[str, Dict[str, Any]]:
    """Aggregate total and average travel times by income group."""
    totals = {
        income: {"trip_count": 0, "total_travel_time": 0.0}
        for income in INCOME_LEVELS
    }

    for record in records:
        commuter_id = record.get(commuter_id_key)
        income = canonical_income_level(income_by_commuter.get(commuter_id))
        if income == "unknown":
            continue

        duration = _safe_float(record.get(duration_key))
        if duration is None:
            continue

        totals[income]["trip_count"] += 1
        totals[income]["total_travel_time"] += duration

    for income in INCOME_LEVELS:
        trip_count = totals[income]["trip_count"]
        total_travel_time = totals[income]["total_travel_time"]
        totals[income]["avg_travel_time"] = (
            total_travel_time / trip_count if trip_count > 0 else 0.0
        )
    return totals


def summarize_price_by_income_group(
    records: Iterable[Mapping[str, Any]],
    income_by_commuter: Mapping[Any, Any],
    *,
    commuter_id_key: str = "commuter_id",
    price_key: str = "price",
) -> Dict[str, Dict[str, Any]]:
    """Aggregate total and average prices by income group."""
    totals = {
        income: {"trip_count": 0, "total_price": 0.0}
        for income in INCOME_LEVELS
    }

    for record in records:
        commuter_id = record.get(commuter_id_key)
        income = canonical_income_level(income_by_commuter.get(commuter_id))
        if income == "unknown":
            continue

        price = _safe_float(record.get(price_key))
        if price is None:
            continue

        totals[income]["trip_count"] += 1
        totals[income]["total_price"] += price

    for income in INCOME_LEVELS:
        trip_count = totals[income]["trip_count"]
        total_price = totals[income]["total_price"]
        totals[income]["avg_price"] = total_price / trip_count if trip_count > 0 else 0.0
    return totals


def _init_income_buckets() -> Dict[str, Counter]:
    return {income: Counter() for income in INCOME_LEVELS}


def _safe_float(value: Any) -> float | None:
    try:
        if value is None:
            return None
        return float(value)
    except (TypeError, ValueError):
        return None
