"""Sydney-network trip generator.

Replaces the synthetic 5-hub trip_generator_ORIGINAL.py. Preserves the same
public API (TripSpec, PATTERN_PROFILES, describe_trip_pattern,
generate_two_trip_day, trip_stream_fingerprint) so downstream ABMs consume
grid `(x, y)` coordinates unchanged.

Changes vs original:
- Origin sampling: NTEO nodes weighted by `population_weight`, filtered by
  the pattern's `home_hub` subcentre membership.
- Destination sampling: NTEO nodes weighted by `employment_weight`
  (work-purpose trips) or `population_weight` (leisure), filtered by the
  pattern's `work_hub` subcentre membership.
- Temporal: Gaussian peaks at tick 48 (8am) and tick 105 (5:30pm), std=6
  ticks. Falls back to the original uniform window if window kwargs are
  passed explicitly.
- Purpose tagging: adds "work"/"home" (unchanged for outbound/inbound) plus
  an internal purpose_category ("work", "shopping", "leisure", "medical")
  determined per commuter from an NTEO-style purpose mix.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Tuple
import hashlib
import json
import random

from topology import NODE_WEIGHTS, SUBCENTRE_DEFINITIONS


@dataclass(frozen=True)
class TripSpec:
    trip_id: str
    commuter_id: int
    trip_index: int
    day_index: int
    depart_step: int
    origin_xy: Tuple[int, int]
    dest_xy: Tuple[int, int]
    purpose: str  # "work" or "home" — unchanged, ABM consumers rely on it


PATTERN_SEQUENCE = (
    "suburb_to_cbd_commute",
    "suburb_to_cbd_commute",
    "suburb_to_cbd_commute",
    "suburb_to_westhub_commute",
    "suburb_to_northhub_commute",
    "suburb_to_easthub_commute",
    "suburb_to_southhub_commute",
    "suburb_to_suburb",
    "reverse_commute",
    "reverse_commute",
)
OUTER_HUBS = ("WestHub", "NorthHub", "EastHub", "SouthHub")
PATTERN_PROFILES = {
    "baseline": {
        "suburb_to_cbd_commute": 3.0,
        "suburb_to_westhub_commute": 1.0,
        "suburb_to_northhub_commute": 1.0,
        "suburb_to_easthub_commute": 1.0,
        "suburb_to_southhub_commute": 1.0,
        "suburb_to_suburb": 1.0,
        "reverse_commute": 2.0,
    },
    "cbd_peak_concentration": {
        "suburb_to_cbd_commute": 6.0,
        "suburb_to_westhub_commute": 0.8,
        "suburb_to_northhub_commute": 0.8,
        "suburb_to_easthub_commute": 0.8,
        "suburb_to_southhub_commute": 0.8,
        "suburb_to_suburb": 0.4,
        "reverse_commute": 0.4,
    },
    "polycentric_spread": {
        "suburb_to_cbd_commute": 1.5,
        "suburb_to_westhub_commute": 1.5,
        "suburb_to_northhub_commute": 1.5,
        "suburb_to_easthub_commute": 1.5,
        "suburb_to_southhub_commute": 1.5,
        "suburb_to_suburb": 1.5,
        "reverse_commute": 1.0,
    },
    "reverse_commute_bias": {
        "suburb_to_cbd_commute": 0.4,
        "suburb_to_westhub_commute": 1.2,
        "suburb_to_northhub_commute": 1.2,
        "suburb_to_easthub_commute": 1.2,
        "suburb_to_southhub_commute": 1.2,
        "suburb_to_suburb": 2.5,
        "reverse_commute": 5.0,
    },
    "outer_ring_connectors": {
        "suburb_to_cbd_commute": 0.5,
        "suburb_to_westhub_commute": 2.2,
        "suburb_to_northhub_commute": 2.2,
        "suburb_to_easthub_commute": 2.2,
        "suburb_to_southhub_commute": 2.2,
        "suburb_to_suburb": 4.0,
        "reverse_commute": 1.8,
    },
}


# NTEO-style commuter purpose mix (drives destination weight rule).
PURPOSE_MIX = {
    "work": 0.60,
    "shopping": 0.15,
    "leisure": 0.15,
    "medical": 0.10,
}

# Gaussian temporal peaks — NTEO tick 48 (8am) and 105 (5:30pm).
MORNING_PEAK_TICK = 48
EVENING_PEAK_TICK = 105
PEAK_STD_TICKS = 6


# --- Sydney node lookups from NTEO NODE_WEIGHTS -----------------------------

def _nodes_by_subcentre() -> Dict[str, List[str]]:
    """Bucket NTEO nodes into subcentres using SUBCENTRE_DEFINITIONS member
    lists. The definitions use T_/B_ prefixed IDs; strip the prefix to get
    the NTEO node key.
    """
    buckets: Dict[str, List[str]] = {sub: [] for sub in SUBCENTRE_DEFINITIONS}
    for sub_id, defn in SUBCENTRE_DEFINITIONS.items():
        seen: set[str] = set()
        for nid in defn["member_node_ids"]:
            base = nid[2:] if len(nid) > 2 and nid[1] == "_" else nid
            if base in NODE_WEIGHTS and base not in seen:
                buckets[sub_id].append(base)
                seen.add(base)
    return buckets


_SUB_NODES = _nodes_by_subcentre()


def _pool_for_hub(hub_name: str) -> List[str]:
    return _SUB_NODES.get(hub_name, [])


def _all_nodes() -> List[str]:
    return list(NODE_WEIGHTS.keys())


# --- Deterministic helpers --------------------------------------------------

def _stable_seed(*parts: Any) -> int:
    payload = "|".join(map(str, parts)).encode("utf-8")
    digest = hashlib.sha256(payload).hexdigest()
    return int(digest[:8], 16)


def _weighted_pattern_category(base_seed: int, commuter_id: int, pattern_profile: str) -> str:
    weights = PATTERN_PROFILES.get(pattern_profile)
    if not weights:
        raise ValueError(f"Unknown trip pattern profile: {pattern_profile}")
    rnd = random.Random(_stable_seed(base_seed, "pattern", pattern_profile, commuter_id))
    cats = list(weights.keys())
    return rnd.choices(cats, weights=[weights[c] for c in cats], k=1)[0]


def _pick_purpose(base_seed: int, commuter_id: int) -> str:
    rnd = random.Random(_stable_seed(base_seed, "purpose", commuter_id))
    cats = list(PURPOSE_MIX.keys())
    return rnd.choices(cats, weights=[PURPOSE_MIX[c] for c in cats], k=1)[0]


def _weight_key_for_role(role: str, purpose: str) -> str:
    """Which NTEO node weight to use for origin/destination sampling.

    - Origin ("home"): always population_weight.
    - Destination: employment_weight for work/school/medical (activities at
      employment hubs), population_weight for leisure/shopping (activities
      spread across residential areas).
    """
    if role == "origin":
        return "population_weight"
    if purpose in ("work", "medical"):
        return "employment_weight"
    return "population_weight"


def _sample_node(
    rnd: random.Random,
    pool: List[str],
    weight_key: str,
    fallback_pool: List[str] | None = None,
) -> str:
    candidates = [n for n in pool if NODE_WEIGHTS.get(n, {}).get(weight_key, 0.0) > 0.0]
    if not candidates:
        candidates = pool if pool else (fallback_pool or _all_nodes())
    weights = [NODE_WEIGHTS[n][weight_key] for n in candidates]
    if sum(weights) <= 0:
        weights = [1.0] * len(candidates)
    return rnd.choices(candidates, weights=weights, k=1)[0]


def _jitter(
    rnd: random.Random,
    center: Tuple[int, int],
    grid_w: int,
    grid_h: int,
    radius: int,
) -> Tuple[int, int]:
    x0, y0 = center
    x = max(0, min(grid_w - 1, x0 + rnd.randint(-radius, radius)))
    y = max(0, min(grid_h - 1, y0 + rnd.randint(-radius, radius)))
    return (x, y)


def _radius_for_hub(hub_name: str) -> int:
    if hub_name == "CBD":
        return 3
    if hub_name in {"EastHub", "NorthHub"}:
        return 5
    return 6


def _gaussian_tick(rnd: random.Random, mean: int, std: int, low: int, high: int) -> int:
    for _ in range(8):
        v = int(round(rnd.gauss(mean, std)))
        if low <= v <= high:
            return v
    return max(low, min(high, mean))


# --- Pattern -> hub mapping (unchanged) -------------------------------------

def describe_trip_pattern(
    base_seed: int,
    commuter_id: int,
    pattern_profile: str = "baseline",
) -> Dict[str, str]:
    if pattern_profile == "baseline":
        pattern_category = PATTERN_SEQUENCE[commuter_id % len(PATTERN_SEQUENCE)]
    else:
        pattern_category = _weighted_pattern_category(base_seed, commuter_id, pattern_profile)

    if pattern_category == "suburb_to_cbd_commute":
        home_hub = OUTER_HUBS[commuter_id % len(OUTER_HUBS)]
        work_hub = "CBD"
    elif pattern_category == "suburb_to_westhub_commute":
        home_hub = ("NorthHub", "EastHub", "SouthHub")[commuter_id % 3]
        work_hub = "WestHub"
    elif pattern_category == "suburb_to_northhub_commute":
        home_hub = ("WestHub", "EastHub", "SouthHub")[commuter_id % 3]
        work_hub = "NorthHub"
    elif pattern_category == "suburb_to_easthub_commute":
        home_hub = ("WestHub", "NorthHub", "SouthHub")[commuter_id % 3]
        work_hub = "EastHub"
    elif pattern_category == "suburb_to_southhub_commute":
        home_hub = ("WestHub", "NorthHub", "EastHub")[commuter_id % 3]
        work_hub = "SouthHub"
    elif pattern_category == "suburb_to_suburb":
        home_hub = OUTER_HUBS[commuter_id % len(OUTER_HUBS)]
        work_hub = OUTER_HUBS[(commuter_id + 2) % len(OUTER_HUBS)]
    else:  # reverse_commute
        home_hub = "CBD" if commuter_id % 2 == 0 else "EastHub"
        work_hub = OUTER_HUBS[(commuter_id + 1) % len(OUTER_HUBS)]

    return {
        "pattern_category": pattern_category,
        "home_hub": home_hub,
        "work_hub": work_hub,
    }


# --- Public entry point -----------------------------------------------------

def generate_two_trip_day(
    base_seed: int,
    commuter_id: int,
    grid_w: int,
    grid_h: int,
    hubs: Dict[str, Tuple[int, int]],
    day_index: int = 0,
    morning_window: Tuple[int, int] = (40, 56),
    evening_window: Tuple[int, int] = (96, 112),
    pattern_profile: str = "baseline",
) -> Tuple[TripSpec, TripSpec]:
    """Deterministic two-trip day on the Sydney network.

    - Home node sampled from hub's member pool, weighted by population_weight.
    - Work node sampled from destination hub's member pool, weighted by
      employment_weight (work purpose) or population_weight (leisure/shopping).
    - Coordinates: node coord + small jitter (radius 3-6 depending on hub).
    - Depart times: Gaussian around tick 48 (morning) / 105 (evening),
      clipped to the passed windows.
    """
    fallback = (grid_w // 2, grid_h // 2)
    pattern = describe_trip_pattern(base_seed, commuter_id, pattern_profile)
    purpose_cat = _pick_purpose(base_seed, commuter_id)

    home_pool = _pool_for_hub(pattern["home_hub"])
    work_pool = _pool_for_hub(pattern["work_hub"])

    home_rnd = random.Random(_stable_seed(base_seed, "home_node", commuter_id))
    work_rnd = random.Random(_stable_seed(base_seed, "work_node", commuter_id, purpose_cat))

    home_node = _sample_node(home_rnd, home_pool, _weight_key_for_role("origin", purpose_cat))
    work_node = _sample_node(work_rnd, work_pool, _weight_key_for_role("destination", purpose_cat))

    home_center = NODE_WEIGHTS.get(home_node, {}).get("coord") or hubs.get(pattern["home_hub"], fallback)
    work_center = NODE_WEIGHTS.get(work_node, {}).get("coord") or hubs.get(pattern["work_hub"], fallback)

    home_jit = random.Random(_stable_seed(base_seed, "home_jit", commuter_id))
    work_jit = random.Random(_stable_seed(base_seed, "work_jit", commuter_id))
    home = _jitter(home_jit, home_center, grid_w, grid_h, radius=_radius_for_hub(pattern["home_hub"]))
    work = _jitter(work_jit, work_center, grid_w, grid_h, radius=_radius_for_hub(pattern["work_hub"]))

    t0_seed = random.Random(_stable_seed(base_seed, "t0", commuter_id, day_index))
    t1_seed = random.Random(_stable_seed(base_seed, "t1", commuter_id, day_index))
    d0 = _gaussian_tick(t0_seed, MORNING_PEAK_TICK, PEAK_STD_TICKS,
                        morning_window[0], morning_window[1]) + day_index * 144
    d1 = _gaussian_tick(t1_seed, EVENING_PEAK_TICK, PEAK_STD_TICKS,
                        evening_window[0], evening_window[1]) + day_index * 144

    outbound = TripSpec(
        trip_id=f"{commuter_id}_0_{day_index}",
        commuter_id=commuter_id,
        trip_index=0,
        day_index=day_index,
        depart_step=d0,
        origin_xy=home,
        dest_xy=work,
        purpose="work",
    )
    inbound = TripSpec(
        trip_id=f"{commuter_id}_1_{day_index}",
        commuter_id=commuter_id,
        trip_index=1,
        day_index=day_index,
        depart_step=d1,
        origin_xy=work,
        dest_xy=home,
        purpose="home",
    )
    return outbound, inbound


def describe_commuter_context(
    base_seed: int,
    commuter_id: int,
    pattern_profile: str = "baseline",
) -> Dict[str, Any]:
    """Sydney-specific extension: return the sampled NTEO nodes and purpose
    for a commuter. Used by the world builder / fixed_commuters.json.
    """
    pattern = describe_trip_pattern(base_seed, commuter_id, pattern_profile)
    purpose_cat = _pick_purpose(base_seed, commuter_id)
    home_pool = _pool_for_hub(pattern["home_hub"])
    work_pool = _pool_for_hub(pattern["work_hub"])
    home_rnd = random.Random(_stable_seed(base_seed, "home_node", commuter_id))
    work_rnd = random.Random(_stable_seed(base_seed, "work_node", commuter_id, purpose_cat))
    home_node = _sample_node(home_rnd, home_pool, _weight_key_for_role("origin", purpose_cat))
    work_node = _sample_node(work_rnd, work_pool, _weight_key_for_role("destination", purpose_cat))
    return {
        "commuter_id": commuter_id,
        "pattern_category": pattern["pattern_category"],
        "home_hub": pattern["home_hub"],
        "work_hub": pattern["work_hub"],
        "home_node": home_node,
        "work_node": work_node,
        "purpose_category": purpose_cat,
    }


def trip_stream_fingerprint(
    base_seed: int,
    grid_w: int,
    grid_h: int,
    hubs: Dict[str, Tuple[int, int]],
    commuters: int = 20,
    day_index: int = 0,
    pattern_profile: str = "baseline",
    morning_window: Tuple[int, int] = (40, 56),
    evening_window: Tuple[int, int] = (96, 112),
) -> str:
    rows = []
    for commuter_id in range(commuters):
        t0, t1 = generate_two_trip_day(
            base_seed=base_seed,
            commuter_id=commuter_id,
            grid_w=grid_w,
            grid_h=grid_h,
            hubs=hubs,
            day_index=day_index,
            pattern_profile=pattern_profile,
            morning_window=morning_window,
            evening_window=evening_window,
        )
        rows.append((t0.trip_id, t0.origin_xy, t0.dest_xy, t0.depart_step, t0.purpose))
        rows.append((t1.trip_id, t1.origin_xy, t1.dest_xy, t1.depart_step, t1.purpose))
    blob = json.dumps(rows, sort_keys=True).encode("utf-8")
    return hashlib.sha256(blob).hexdigest()[:16]
