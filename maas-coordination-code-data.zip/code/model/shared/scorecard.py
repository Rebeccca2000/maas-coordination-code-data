from __future__ import annotations

from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Iterable, Mapping
import csv
import statistics

from shared_comparison_metrics import INCOME_LEVELS, MODE_CATEGORIES, canonical_mode_category
from shared_request_summary import build_authoritative_request_summary, mismatch_diagnostics_from_summary
from shared_request_validation import validate_request_rows


OBJECTIVE_METRIC_ORDER = (
    ("Objective 1", "match_rate"),
    ("Objective 1", "by_income_success_rate"),
    ("Objective 1", "success_rate_dispersion"),
    ("Objective 1", "success_rate_std"),
    ("Objective 1", "near_miss_rate"),
    ("Objective 1", "capacity_rejection_rate"),
    ("Objective 1", "offerless_request_rate"),
    ("Objective 1", "served_offer_richness"),
    ("Objective 2", "mode_share_equity_loss"),
    ("Objective 2", "conditional_travel_time_equity_loss"),
    ("Objective 2", "price_incidence_dispersion"),
    ("Objective 2", "inclusive_travel_time_equity_loss"),
    ("Objective 2", "mode_diversity_index"),
    ("Objective 3", "effective_average_burden"),
    ("Objective 3", "p95_burden"),
    ("Objective 3", "effective_total_burden"),
    ("Objective 3", "inclusive_burden_equity_loss"),
)


def load_request_rows_csv(path: str | Path) -> list[dict[str, str]]:
    with open(path, newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def score_request_rows(
    rows: Iterable[Mapping[str, Any]],
    *,
    model_label: str,
    seed: int | None = None,
    t_penalty: float,
    raw_summary: Mapping[str, Any] | None = None,
    competition_rows: Iterable[Mapping[str, Any]] | None = None,
    unmatched_diagnostics_rows: Iterable[Mapping[str, Any]] | None = None,
) -> dict[str, Any]:
    row_list = [dict(row) for row in rows]
    validation = validate_request_rows(row_list, model_label=model_label, seed=seed)
    authoritative = build_authoritative_request_summary(
        row_list,
        model_label=model_label,
        seed=seed,
        raw_summary=raw_summary,
    )
    mismatch_rows = mismatch_diagnostics_from_summary(authoritative)
    objective = compute_objective_metrics(
        row_list,
        t_penalty=t_penalty,
        unmatched_diagnostics_rows=unmatched_diagnostics_rows,
    )
    competition = compute_competition_support_metrics(
        row_list,
        competition_rows=competition_rows,
    )
    return {
        "model": model_label,
        "seed": "" if seed is None else seed,
        "validation_diagnostics": validation,
        "mismatch_diagnostics": mismatch_rows,
        "authoritative_summary": authoritative,
        "objective_metrics": objective,
        "competition_metrics": competition,
    }


def compute_objective_metrics(
    rows: list[Mapping[str, Any]],
    *,
    t_penalty: float,
    unmatched_diagnostics_rows: Iterable[Mapping[str, Any]] | None = None,
) -> dict[str, Any]:
    total = len(rows)
    success = [row for row in rows if _outcome(row) == "success"]
    failures = [row for row in rows if _outcome(row) != "success"]
    diagnostics_by_request = {
        str(row.get("request_id")): dict(row)
        for row in (unmatched_diagnostics_rows or [])
        if str(row.get("request_id", "")).strip()
    }

    by_income_total = Counter(_income(row) for row in rows)
    by_income_success = Counter(_income(row) for row in success)
    success_rates = {
        income: (by_income_success[income] / by_income_total[income]) if by_income_total[income] else 0.0
        for income in INCOME_LEVELS
    }

    served_times = [_scored_travel_time(row) for row in success]
    served_times = [value for value in served_times if value is not None]
    served_prices = [_float_or_none(row.get("price")) for row in success]
    served_prices = [value for value in served_prices if value is not None]

    served_time_mean = _mean(served_times)
    served_time_sum = sum(served_times)
    served_price_mean = _mean(served_prices)

    travel_time_by_income: dict[str, float] = {}
    price_by_income: dict[str, float] = {}
    mode_share_by_income: dict[str, dict[str, float]] = {}

    for income in INCOME_LEVELS:
        group_success = [row for row in success if _income(row) == income]
        group_times = [_scored_travel_time(row) for row in group_success]
        group_times = [value for value in group_times if value is not None]
        group_prices = [_float_or_none(row.get("price")) for row in group_success]
        group_prices = [value for value in group_prices if value is not None]
        travel_time_by_income[income] = _mean(group_times)
        price_by_income[income] = _mean(group_prices)
        mode_share_by_income[income] = _mode_share(group_success)

    effective_total = served_time_sum + len(failures) * float(t_penalty)
    effective_average = (effective_total / total) if total else 0.0
    burden_values = served_times + ([float(t_penalty)] * len(failures))

    near_miss_failures = 0
    capacity_failures = 0
    offerless_failures = 0
    for row in failures:
        merged = _merge_failure_diagnostics(row, diagnostics_by_request)
        offer_count = _float_or_none(merged.get("request_offer_count"))
        candidate_bundle_count = _float_or_none(merged.get("candidate_bundle_count"))
        failure_reason = str(merged.get("failure_reason", "") or "").strip().lower()
        failure_stage = str(merged.get("failure_stage", "") or "").strip().lower()

        if (offer_count is not None and offer_count > 0) or (candidate_bundle_count is not None and candidate_bundle_count > 0):
            near_miss_failures += 1
        if _is_capacity_rejection(failure_reason=failure_reason, failure_stage=failure_stage):
            capacity_failures += 1
        if offer_count is not None and offer_count <= 0:
            offerless_failures += 1
        elif offer_count is None and failure_reason in {"no_offer", "no_viable_options", "offerless_request"}:
            offerless_failures += 1

    # --- Inclusive equity metrics (failures included at t_penalty) ---
    inclusive_times_by_income: dict[str, list[float]] = {income: [] for income in INCOME_LEVELS}
    for row in rows:
        income = _income(row)
        if income not in INCOME_LEVELS:
            continue
        if _outcome(row) == "success":
            t = _scored_travel_time(row)
            if t is not None:
                inclusive_times_by_income[income].append(t)
        else:
            inclusive_times_by_income[income].append(float(t_penalty))

    inclusive_mean_by_income = {
        income: _mean(vals) for income, vals in inclusive_times_by_income.items() if vals
    }
    overall_inclusive_mean = _mean(list(inclusive_mean_by_income.values()))
    inclusive_travel_time_equity_loss = (
        sum(abs(inclusive_mean_by_income[income] - overall_inclusive_mean) for income in inclusive_mean_by_income)
        / len(inclusive_mean_by_income)
    ) if inclusive_mean_by_income else 0.0

    inclusive_burden_by_income: dict[str, list[float]] = {income: [] for income in INCOME_LEVELS}
    for row in rows:
        income = _income(row)
        if income not in INCOME_LEVELS:
            continue
        if _outcome(row) == "success":
            t = _scored_travel_time(row) or 0.0
            p = _float_or_none(row.get("price")) or 0.0
            inclusive_burden_by_income[income].append(t + p)
        else:
            inclusive_burden_by_income[income].append(float(t_penalty))
    inclusive_burden_mean_by_income = {
        income: _mean(vals) for income, vals in inclusive_burden_by_income.items() if vals
    }
    overall_burden_mean = _mean(list(inclusive_burden_mean_by_income.values()))
    inclusive_burden_equity_loss = (
        sum(abs(inclusive_burden_mean_by_income[inc] - overall_burden_mean)
            for inc in inclusive_burden_mean_by_income)
        / len(inclusive_burden_mean_by_income)
    ) if inclusive_burden_mean_by_income else 0.0

    # --- Served offer richness ---
    offer_counts = [_float_or_none(row.get("request_offer_count")) for row in success]
    offer_counts = [v for v in offer_counts if v is not None]
    served_offer_richness: float | None = _mean(offer_counts) if offer_counts else None

    # --- Mode diversity index (Shannon entropy of mode shares, served only) ---
    mode_counts = Counter(canonical_mode_category(row.get("chosen_mode")) for row in success)
    total_served_modes = sum(mode_counts.values())
    mode_diversity_index = (
        -sum((c / total_served_modes) * _safe_log2(c / total_served_modes) for c in mode_counts.values() if c > 0)
        if total_served_modes > 0 else 0.0
    )

    return {
        "requests": total,
        "successes": len(success),
        "failures": len(failures),
        "match_rate": (len(success) / total) if total else 0.0,
        "by_income_success_rate": success_rates,
        "success_rate_dispersion": (max(success_rates.values()) - min(success_rates.values())) if success_rates else 0.0,
        "success_rate_std": statistics.pstdev(success_rates.values()) if success_rates else 0.0,
        "mode_share_equity_loss": _mode_share_equity_loss(mode_share_by_income),
        "conditional_travel_time_equity_loss": (
            sum(abs(travel_time_by_income[income] - served_time_mean) for income in INCOME_LEVELS) / len(INCOME_LEVELS)
        ),
        "price_incidence_dispersion": (
            sum(abs(price_by_income[income] - served_price_mean) for income in INCOME_LEVELS) / len(INCOME_LEVELS)
        ),
        "near_miss_rate": (near_miss_failures / total) if total else 0.0,
        "capacity_rejection_rate": (capacity_failures / total) if total else 0.0,
        "offerless_request_rate": (offerless_failures / total) if total else 0.0,
        "served_offer_richness": served_offer_richness,
        "inclusive_travel_time_equity_loss": inclusive_travel_time_equity_loss,
        "mode_diversity_index": mode_diversity_index,
        "effective_average_burden": effective_average,
        "p95_burden": _percentile(burden_values, 95.0),
        "effective_total_burden": effective_total,
        "inclusive_burden_equity_loss": inclusive_burden_equity_loss,
        "served_avg_travel_time": served_time_mean,
        "served_total_travel_time": served_time_sum,
        "served_avg_price": served_price_mean,
        "served_total_price": sum(served_prices),
    }


def compute_competition_support_metrics(
    rows: list[Mapping[str, Any]],
    *,
    competition_rows: Iterable[Mapping[str, Any]] | None = None,
) -> dict[str, Any]:
    served = [row for row in rows if _outcome(row) == "success"]
    operator_counter = Counter(
        str(row.get("operator_usage", "")).strip()
        for row in served
        if str(row.get("operator_usage", "")).strip()
    )
    total_served_with_operator = sum(operator_counter.values())
    concentration = (
        max(operator_counter.values()) / total_served_with_operator
        if total_served_with_operator > 0 and operator_counter
        else 0.0
    )
    diversity = len(operator_counter)
    operator_shares = (
        sorted(
            (count / total_served_with_operator for count in operator_counter.values()),
            reverse=True,
        )
        if total_served_with_operator > 0 and operator_counter
        else []
    )
    entropy = (
        -sum(share * _safe_log2(share) for share in operator_shares if share > 0)
        if operator_shares
        else 0.0
    )
    hhi = sum((share * 100.0) ** 2 for share in operator_shares) if operator_shares else 0.0
    top2_share = sum(operator_shares[:2]) if operator_shares else 0.0
    p90_dominance = _percentile(operator_shares, 90.0) if operator_shares else 0.0

    competition_metric_rows = list(competition_rows or [])
    offer_values = [
        _float_or_none(row.get("offer_count"))
        for row in competition_metric_rows
        if row.get("offer_count") not in (None, "")
    ]
    share_ge_2 = None
    mean_offers = None
    bundle_alternative_count = None

    if competition_metric_rows and offer_values:
        has_distribution_counts = any(row.get("request_count") not in (None, "") for row in competition_metric_rows)
        if has_distribution_counts:
            weighted_total = 0.0
            request_total = 0.0
            ge_2_total = 0.0
            for row in competition_metric_rows:
                offer_count = _float_or_none(row.get("offer_count"))
                request_count = _float_or_none(row.get("request_count"))
                if offer_count is None or request_count is None:
                    continue
                weighted_total += offer_count * request_count
                request_total += request_count
                if offer_count >= 2:
                    ge_2_total += request_count
            if request_total > 0:
                mean_offers = weighted_total / request_total
                share_ge_2 = ge_2_total / request_total
        else:
            mean_offers = _mean([float(value) for value in offer_values if value is not None])
            share_ge_2 = (
                sum(1 for value in offer_values if value is not None and float(value) >= 2.0) / len(offer_values)
                if offer_values
                else None
            )
    else:
        mean_offers = None
        share_ge_2 = None

    if competition_metric_rows and any(row.get("bundle_alternative_count") not in (None, "") for row in competition_metric_rows):
        bundle_alternative_count = sum(
            1
            for row in competition_metric_rows
            if (_float_or_none(row.get("bundle_alternative_count")) or 0.0) >= 1.0
        )
    else:
        bundle_alternative_count = sum(
            1 for row in rows
            if _outcome(row) == "success" and canonical_mode_category(row.get("chosen_mode")) == "bundle"
        )

    # --- Provider revenue Gini (supply-side equity; meaningful for decentralised only) ---
    provider_revenue: Counter = Counter()
    for row in served:
        pid = str(row.get("provider_id", "")).strip()
        price = _float_or_none(row.get("price"))
        if pid and price is not None:
            provider_revenue[pid] += price

    revenues = sorted(provider_revenue.values())
    n_providers = len(revenues)
    if n_providers >= 2:
        total_rev = sum(revenues)
        if total_rev > 0:
            cumsum = sum((2 * (i + 1) - n_providers - 1) * r for i, r in enumerate(revenues))
            provider_revenue_gini: float | None = cumsum / (n_providers * total_rev)
        else:
            provider_revenue_gini = None
    else:
        provider_revenue_gini = None

    return {
        "mean_offers_per_request": mean_offers,
        "share_requests_with_ge_2_offers": share_ge_2,
        "operator_usage_concentration": concentration,
        "operator_usage_entropy": entropy,
        "operator_usage_hhi": hhi,
        "operator_usage_top2_share": top2_share,
        "operator_usage_p90_dominance": p90_dominance,
        "operator_usage_diversity": diversity,
        "bundle_alternative_count": bundle_alternative_count,
        "provider_revenue_gini": provider_revenue_gini,
    }


def flatten_objective_metrics(
    scored_rows: Iterable[Mapping[str, Any]],
) -> list[dict[str, Any]]:
    output: list[dict[str, Any]] = []
    for scored in scored_rows:
        model = scored.get("model")
        seed = scored.get("seed")
        objective_metrics = scored.get("objective_metrics", {})
        for objective_name, metric_name in OBJECTIVE_METRIC_ORDER:
            value = objective_metrics.get(metric_name)
            output.append(
                {
                    "model": model,
                    "seed": seed,
                    "objective": objective_name,
                    "metric": metric_name,
                    "value": _format_value(value),
                }
            )
    return output


def flatten_competition_metrics(
    scored_rows: Iterable[Mapping[str, Any]],
) -> list[dict[str, Any]]:
    output: list[dict[str, Any]] = []
    for scored in scored_rows:
        model = scored.get("model")
        seed = scored.get("seed")
        for metric_name, value in (scored.get("competition_metrics", {}) or {}).items():
            output.append(
                {
                    "model": model,
                    "seed": seed,
                    "metric": metric_name,
                    "value": _format_value(value),
                }
            )
    return output


def aggregate_scored_runs(scored_runs: Iterable[Mapping[str, Any]]) -> dict[str, dict[str, Any]]:
    grouped: dict[str, list[Mapping[str, Any]]] = defaultdict(list)
    for row in scored_runs:
        grouped[str(row.get("model"))].append(row)

    aggregated: dict[str, dict[str, Any]] = {}
    for model, runs in grouped.items():
        objective_keys = list((runs[0].get("objective_metrics") or {}).keys()) if runs else []
        competition_keys = list((runs[0].get("competition_metrics") or {}).keys()) if runs else []
        aggregated[model] = {
            "model": model,
            "seeds": len(runs),
            "objective_metrics": {
                key: _mean_or_none(
                    [
                        value
                        for value in (
                            _scalar_metric(run.get("objective_metrics", {}).get(key))
                            for run in runs
                        )
                        if value is not None
                    ]
                )
                for key in objective_keys
                if key != "by_income_success_rate"
            },
            "competition_metrics": {
                key: _mean_or_none(
                    [
                        value
                        for value in (
                            _scalar_metric(run.get("competition_metrics", {}).get(key))
                            for run in runs
                        )
                        if value is not None
                    ]
                )
                for key in competition_keys
            },
        }
        income_rates = {income: [] for income in INCOME_LEVELS}
        for run in runs:
            rate_map = run.get("objective_metrics", {}).get("by_income_success_rate", {}) or {}
            for income in INCOME_LEVELS:
                income_rates[income].append(float(rate_map.get(income, 0.0)))
        aggregated[model]["objective_metrics"]["by_income_success_rate"] = {
            income: _mean(values) for income, values in income_rates.items()
        }
    return aggregated


def _mode_share(group_success: list[Mapping[str, Any]]) -> dict[str, float]:
    counts = Counter(canonical_mode_category(row.get("chosen_mode")) for row in group_success)
    total = sum(counts.values())
    if total == 0:
        return {mode: 0.0 for mode in MODE_CATEGORIES}
    return {mode: counts.get(mode, 0) / total for mode in MODE_CATEGORIES}


def _mode_share_equity_loss(mode_share_by_income: Mapping[str, Mapping[str, float]]) -> float:
    if not mode_share_by_income:
        return 0.0
    average_shares = {
        mode: _mean([float(mode_share_by_income[income].get(mode, 0.0)) for income in INCOME_LEVELS])
        for mode in MODE_CATEGORIES
    }
    losses: list[float] = []
    for income in INCOME_LEVELS:
        losses.extend(
            abs(float(mode_share_by_income[income].get(mode, 0.0)) - average_shares[mode])
            for mode in MODE_CATEGORIES
        )
    return _mean(losses)


def _income(row: Mapping[str, Any]) -> str:
    return str(row.get("income_group", "")).strip().lower()


def _outcome(row: Mapping[str, Any]) -> str:
    return str(row.get("outcome", "")).strip().lower()


def _float_or_none(value: Any) -> float | None:
    if value in (None, ""):
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _scored_travel_time(row: Mapping[str, Any]) -> float | None:
    travel_time = _float_or_none(row.get("travel_time"))
    if travel_time is not None:
        return travel_time
    congestion_adjusted = _float_or_none(row.get("congestion_adjusted_travel_time"))
    if congestion_adjusted is not None:
        return congestion_adjusted
    return _float_or_none(row.get("free_flow_travel_time"))


def _mean(values: list[float]) -> float:
    return (sum(values) / len(values)) if values else 0.0


def _mean_or_none(values: list[float]) -> float | None:
    return (sum(values) / len(values)) if values else None


def _scalar_metric(value: Any) -> float | None:
    if isinstance(value, dict):
        return None
    return _float_or_none(value)


def _merge_failure_diagnostics(
    row: Mapping[str, Any],
    diagnostics_by_request: Mapping[str, Mapping[str, Any]],
) -> dict[str, Any]:
    merged = dict(row)
    request_id = str(row.get("request_id", "")).strip()
    if request_id and request_id in diagnostics_by_request:
        for key, value in diagnostics_by_request[request_id].items():
            merged.setdefault(key, value)
            if merged.get(key) in (None, ""):
                merged[key] = value
    return merged


def _is_capacity_rejection(*, failure_reason: str, failure_stage: str) -> bool:
    haystack = " ".join(part for part in (failure_reason, failure_stage) if part).lower()
    if not haystack:
        return False
    return any(
        token in haystack
        for token in (
            "capacity",
            "reservation",
            "sold_out",
            "provider_unavailable",
            "inventory",
        )
    )


def _percentile(values: list[float], percentile: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(float(value) for value in values)
    if len(ordered) == 1:
        return ordered[0]
    rank = max(0.0, min(100.0, float(percentile))) / 100.0 * (len(ordered) - 1)
    lower = int(rank)
    upper = min(lower + 1, len(ordered) - 1)
    weight = rank - lower
    return ordered[lower] * (1.0 - weight) + ordered[upper] * weight


def _safe_log2(value: float) -> float:
    import math

    return math.log(value, 2.0)


def _format_value(value: Any) -> Any:
    if isinstance(value, dict):
        return ";".join(f"{key}={float(val):.6f}" for key, val in value.items())
    if isinstance(value, float):
        return f"{value:.6f}"
    return value
