from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
from typing import Any, Iterable
import json
import os

from shared_experiment_config import GRID_HEIGHT, GRID_WIDTH, NUM_COMMUTERS, SIMULATION_STEPS
from shared_matching_validation import compute_full_demand_trip_fingerprint
from shared_trip_generator import TripSpec


@dataclass(frozen=True)
class FrozenCommuterSpec:
    canonical_commuter_id: int
    initial_location: tuple[int, int]
    age: int
    income_level: str
    has_disability: bool
    tech_access: bool
    health_status: str
    payment_scheme: str


def load_fixed_commuters(
    path: str,
    *,
    expected_count: int = NUM_COMMUTERS,
    grid_width: int = GRID_WIDTH,
    grid_height: int = GRID_HEIGHT,
) -> dict[str, Any]:
    payload = _load_json_file(path)
    commuters_raw = _require_list(payload, "commuters")
    specs: list[FrozenCommuterSpec] = []
    seen_ids: set[int] = set()

    for idx, row in enumerate(commuters_raw):
        if not isinstance(row, dict):
            raise ValueError(f"commuters[{idx}] must be an object")
        canonical_id = _require_int(row, "canonical_commuter_id")
        if canonical_id in seen_ids:
            raise ValueError(f"Duplicate canonical_commuter_id={canonical_id}")
        seen_ids.add(canonical_id)
        specs.append(
            FrozenCommuterSpec(
                canonical_commuter_id=canonical_id,
                initial_location=_require_xy(
                    row.get("initial_location"),
                    name=f"commuters[{idx}].initial_location",
                    grid_width=grid_width,
                    grid_height=grid_height,
                ),
                age=_require_int(row, "age"),
                income_level=_require_enum(row, "income_level", {"low", "middle", "high"}),
                has_disability=_require_bool(row, "has_disability"),
                tech_access=_require_bool(row, "tech_access"),
                health_status=_require_enum(row, "health_status", {"good", "poor"}),
                payment_scheme=_require_enum(row, "payment_scheme", {"PAYG", "subscription"}),
            )
        )

    commuter_count = _require_int(payload, "commuter_count")
    if commuter_count != len(specs):
        raise ValueError(
            f"commuter_count mismatch: header={commuter_count}, actual={len(specs)}"
        )
    if expected_count is not None and len(specs) != int(expected_count):
        raise ValueError(
            f"Expected {int(expected_count)} commuters, found {len(specs)}"
        )

    return {
        "schema_version": payload.get("schema_version"),
        "scenario_id": payload.get("scenario_id"),
        "seed": payload.get("seed"),
        "grid_width": payload.get("grid_width"),
        "grid_height": payload.get("grid_height"),
        "commuter_count": len(specs),
        "path": os.path.abspath(path),
        "commuters": sorted(specs, key=lambda item: item.canonical_commuter_id),
        "fingerprint": compute_commuter_fingerprint(specs),
    }


def load_fixed_trip_requests(
    path: str,
    *,
    expected_commuter_ids: Iterable[int] | None = None,
    grid_width: int = GRID_WIDTH,
    grid_height: int = GRID_HEIGHT,
    simulation_steps: int = SIMULATION_STEPS,
) -> dict[str, Any]:
    payload = _load_json_file(path)
    trips_raw = _require_list(payload, "trip_requests")
    trips: list[TripSpec] = []
    seen_trip_ids: set[str] = set()
    commuter_ids = None if expected_commuter_ids is None else {int(value) for value in expected_commuter_ids}

    for idx, row in enumerate(trips_raw):
        if not isinstance(row, dict):
            raise ValueError(f"trip_requests[{idx}] must be an object")
        trip_id = str(row.get("canonical_trip_id", "")).strip()
        if not trip_id:
            raise ValueError(f"trip_requests[{idx}].canonical_trip_id is required")
        if trip_id in seen_trip_ids:
            raise ValueError(f"Duplicate canonical_trip_id={trip_id}")
        seen_trip_ids.add(trip_id)
        canonical_commuter_id = _require_int(row, "canonical_commuter_id")
        if commuter_ids is not None and canonical_commuter_id not in commuter_ids:
            raise ValueError(
                f"Trip {trip_id} references unknown canonical_commuter_id={canonical_commuter_id}"
            )
        depart_step = _require_int(row, "depart_step")
        if depart_step < 0 or depart_step >= int(simulation_steps):
            raise ValueError(
                f"Trip {trip_id} depart_step={depart_step} outside [0, {int(simulation_steps)})"
            )
        trips.append(
            TripSpec(
                trip_id=trip_id,
                commuter_id=canonical_commuter_id,
                trip_index=_require_int(row, "trip_index"),
                day_index=_require_int(row, "day_index"),
                depart_step=depart_step,
                origin_xy=_require_xy(
                    row.get("origin_xy"),
                    name=f"trip_requests[{idx}].origin_xy",
                    grid_width=grid_width,
                    grid_height=grid_height,
                ),
                dest_xy=_require_xy(
                    row.get("dest_xy"),
                    name=f"trip_requests[{idx}].dest_xy",
                    grid_width=grid_width,
                    grid_height=grid_height,
                ),
                purpose=str(row.get("purpose", "")).strip(),
            )
        )
        if not trips[-1].purpose:
            raise ValueError(f"trip_requests[{idx}].purpose is required")

    planned_trip_count = _require_int(payload, "planned_trip_count")
    if planned_trip_count != len(trips):
        raise ValueError(
            f"planned_trip_count mismatch: header={planned_trip_count}, actual={len(trips)}"
        )

    grouped = group_trips_by_canonical_commuter(trips)
    return {
        "schema_version": payload.get("schema_version"),
        "scenario_id": payload.get("scenario_id"),
        "seed": payload.get("seed"),
        "simulation_steps": payload.get("simulation_steps"),
        "planned_trip_count": len(trips),
        "path": os.path.abspath(path),
        "trip_requests": trips,
        "grouped_trip_plans": grouped,
        "fingerprint": compute_trip_request_fingerprint(trips),
    }


def group_trips_by_canonical_commuter(
    trips: Iterable[TripSpec],
) -> dict[int, list[TripSpec]]:
    grouped: dict[int, list[TripSpec]] = {}
    for trip in trips:
        grouped.setdefault(int(trip.commuter_id), []).append(trip)
    for commuter_id in list(grouped):
        grouped[commuter_id] = sorted(
            grouped[commuter_id],
            key=lambda trip: (trip.day_index, trip.depart_step, trip.trip_index),
        )
    return dict(sorted(grouped.items()))


def compute_commuter_fingerprint(commuters: Iterable[FrozenCommuterSpec]) -> str:
    rows = []
    for commuter in sorted(commuters, key=lambda item: item.canonical_commuter_id):
        rows.append(
            {
                "canonical_commuter_id": int(commuter.canonical_commuter_id),
                "initial_location": list(commuter.initial_location),
                "age": int(commuter.age),
                "income_level": commuter.income_level,
                "has_disability": bool(commuter.has_disability),
                "tech_access": bool(commuter.tech_access),
                "health_status": commuter.health_status,
                "payment_scheme": commuter.payment_scheme,
            }
        )
    return sha256(json.dumps(rows, sort_keys=True).encode("utf-8")).hexdigest()[:16]


def compute_trip_request_fingerprint(trips: Iterable[TripSpec]) -> str:
    return compute_full_demand_trip_fingerprint(group_trips_by_canonical_commuter(trips))


def _load_json_file(path: str) -> dict[str, Any]:
    with open(path, "r", encoding="utf-8") as fh:
        payload = json.load(fh)
    if not isinstance(payload, dict):
        raise ValueError(f"{path} must contain a top-level JSON object")
    return payload


def _require_list(payload: dict[str, Any], field: str) -> list[Any]:
    value = payload.get(field)
    if not isinstance(value, list):
        raise ValueError(f"{field} must be a list")
    return value


def _require_int(payload: dict[str, Any], field: str) -> int:
    value = payload.get(field)
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(f"{field} must be an integer")
    return int(value)


def _require_bool(payload: dict[str, Any], field: str) -> bool:
    value = payload.get(field)
    if not isinstance(value, bool):
        raise ValueError(f"{field} must be a boolean")
    return value


def _require_enum(payload: dict[str, Any], field: str, allowed: set[str]) -> str:
    value = str(payload.get(field, "")).strip()
    if value not in allowed:
        raise ValueError(f"{field} must be one of {sorted(allowed)}")
    return value


def _require_xy(
    value: Any,
    *,
    name: str,
    grid_width: int,
    grid_height: int,
) -> tuple[int, int]:
    if not isinstance(value, (list, tuple)) or len(value) != 2:
        raise ValueError(f"{name} must be a 2-item coordinate")
    x, y = value
    if isinstance(x, bool) or not isinstance(x, int) or isinstance(y, bool) or not isinstance(y, int):
        raise ValueError(f"{name} coordinates must be integers")
    if not (0 <= x < int(grid_width) and 0 <= y < int(grid_height)):
        raise ValueError(
            f"{name}={value} outside grid bounds 0..{int(grid_width) - 1}, 0..{int(grid_height) - 1}"
        )
    return (int(x), int(y))
