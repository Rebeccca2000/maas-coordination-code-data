from __future__ import annotations

from copy import deepcopy
import os
from typing import Any


DEFAULT_CENTRAL_BURDEN_VARIANT = "CBR_reference"

_VARIANT_ROWS: tuple[dict[str, Any], ...] = (
    {
        "variant_id": "CBR_reference",
        "variant_name": "Reference no relief",
        "intervention_strength": "none",
        "pool_type": "daily",
        "pool_amount": 0,
        "subsidy_schedule_used": (
            "Keep existing database_01 subsidy_dataset unchanged, but leave pool at zero so no credits can be paid."
        ),
        "exact_changed_mechanism": (
            "No intervention. Centralised runner continues to pass the dormant daily subsidy pool and the existing "
            "income-by-mode subsidy schedule has no live effect because the available pool is zero."
        ),
        "expected_burden_effect": "No burden change; anchor for the intervention family.",
    },
    {
        "variant_id": "CBR_low",
        "variant_name": "Low burden-relief credit pool",
        "intervention_strength": "low",
        "pool_type": "daily",
        "pool_amount": 2500,
        "subsidy_schedule_used": (
            "Keep existing database_01 subsidy_dataset unchanged: low bike/car/MaaS_Bundle=0.50/0.55/0.50; "
            "middle=0.23/0.35/0.35; high=0.10/0.05/0.10."
        ),
        "exact_changed_mechanism": (
            "Switch centralised subsidy_config from zero-pool daily_config to a positive daily pool of 2500 while "
            "leaving routing, utility form, and world settings fixed. Credits are still applied through the existing "
            "utility-stage subsidy path and existing subsidy-usage logging."
        ),
        "expected_burden_effect": (
            "Modest burden reduction through small shifts toward faster subsidised car and MaaS bundle options; "
            "likely weakest but cleanest detectable change."
        ),
    },
    {
        "variant_id": "CBR_medium",
        "variant_name": "Medium burden-relief credit pool",
        "intervention_strength": "medium",
        "pool_type": "daily",
        "pool_amount": 5000,
        "subsidy_schedule_used": (
            "Keep existing database_01 subsidy_dataset unchanged: low bike/car/MaaS_Bundle=0.50/0.55/0.50; "
            "middle=0.23/0.35/0.35; high=0.10/0.05/0.10."
        ),
        "exact_changed_mechanism": (
            "Same mechanism as CBR_low, but increase the daily relief pool to 5000 so the existing income-sensitive "
            "credits remain available deeper into the simulated day."
        ),
        "expected_burden_effect": (
            "Meaningful burden reduction expected in W00 W02 W04 and W07 if price-sensitive travellers switch toward "
            "faster direct or bundle options."
        ),
    },
    {
        "variant_id": "CBR_high",
        "variant_name": "High burden-relief credit pool",
        "intervention_strength": "high",
        "pool_type": "daily",
        "pool_amount": 10000,
        "subsidy_schedule_used": (
            "Keep existing database_01 subsidy_dataset unchanged: low bike/car/MaaS_Bundle=0.50/0.55/0.50; "
            "middle=0.23/0.35/0.35; high=0.10/0.05/0.10."
        ),
        "exact_changed_mechanism": (
            "Same mechanism as CBR_low, but increase the daily relief pool to 10000 so the live credit mechanism is "
            "rarely budget-constrained within a day."
        ),
        "expected_burden_effect": (
            "Largest expected burden reduction; also the highest risk of trade-offs in mode-share equity or "
            "price/readout interpretation if fast-mode uptake becomes too strong."
        ),
    },
)

CENTRAL_BURDEN_VARIANTS = {
    str(row["variant_id"]): row
    for row in _VARIANT_ROWS
}


def list_central_burden_variants() -> list[dict[str, Any]]:
    return [deepcopy(row) for row in _VARIANT_ROWS]


def resolve_central_burden_variant(
    variant: str | None = None,
) -> dict[str, Any]:
    candidate = (
        str(variant or os.getenv("CENTRAL_BURDEN_VARIANT") or DEFAULT_CENTRAL_BURDEN_VARIANT)
        .strip()
    )
    if candidate not in CENTRAL_BURDEN_VARIANTS:
        valid = ", ".join(sorted(CENTRAL_BURDEN_VARIANTS))
        raise ValueError(
            f"Unknown central burden variant '{candidate}'. Valid variants: {valid}"
        )
    return deepcopy(CENTRAL_BURDEN_VARIANTS[candidate])


def build_subsidy_pool_config(
    subsidy_pool_config_cls: type[Any],
    *,
    variant: str | dict[str, Any] | None = None,
) -> Any:
    resolved = (
        resolve_central_burden_variant(variant)
        if not isinstance(variant, dict)
        else dict(variant)
    )
    pool_type = str(resolved.get("pool_type", "daily")).strip()
    pool_amount = int(resolved.get("pool_amount", 0) or 0)
    return subsidy_pool_config_cls(pool_type, pool_amount)


__all__ = [
    "CENTRAL_BURDEN_VARIANTS",
    "DEFAULT_CENTRAL_BURDEN_VARIANT",
    "build_subsidy_pool_config",
    "list_central_burden_variants",
    "resolve_central_burden_variant",
]
