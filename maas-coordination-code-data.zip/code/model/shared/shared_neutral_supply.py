"""Neutral direct-vehicle supply spec (V9 Phase 1.2).

Single source of truth for the shared world layer's fleet capacity table.
Both architectures consume from here when V9_NEUTRAL_SPEC=1 is in effect.

Doctrinal rationale (§19 + §22 adjudication):
- V8 baseline C car total = 34 (UberLike1=15 + UberLike2=19); bike total = 22
  (BikeShare1=10 + BikeShare2=12).
- V8 baseline D car total = 40 dedicated + 20 pooled (`ondemand_C` multi-mode);
  bike total = 22 dedicated + 20 pooled — flagged **unintended asymmetry** in §19.
- Neutral spec: car=34, bike=22, no multi-mode pool. Both sides consume the
  same numbers via `NEUTRAL_SUPPLY_SPEC`. The `ondemand_C` pool is deleted;
  the "extra car line 40" collapses to 34.

Note. Peak-hour tests in §21.5 confirmed capacity is not binding on W00
(car peak concurrent 21/34, bike 9/22), so the burden effect of this
neutralisation is expected to be small. Its purpose is doctrinal: the gate
call must be unambiguous.
"""
from __future__ import annotations

import os
from typing import Dict, Any, List


NEUTRAL_SUPPLY_SPEC: Dict[str, Any] = {
    "car": {
        "total_capacity": 34,
        "providers": [
            {"provider_id": "car_A", "capacity": 15, "role": "generic_ride_hail"},
            {"provider_id": "car_B", "capacity": 19, "role": "generic_ride_hail"},
        ],
        "fare_card_mode": "ride_hail",
    },
    "bike": {
        "total_capacity": 22,
        "providers": [
            {"provider_id": "bike_A", "capacity": 10, "role": "micromobility"},
            {"provider_id": "bike_B", "capacity": 12, "role": "micromobility"},
        ],
        "fare_card_mode": "micromobility",
    },
}

# Historical D-only extras that the neutral spec REMOVES.
REMOVED_D_ONLY_ITEMS: List[str] = [
    "ondemand_C_balanced (multi-mode pool, 20 units — §19 unintended asymmetry)",
    "dedicated car line surplus of 6 units on D (car 40 → 34)",
]

NEUTRAL_SUPPLY_VERSION = "v9_neutral_supply_2026_07_14"


def neutral_spec_active() -> bool:
    """Same convention as `shared_fare_card.neutral_spec_active` — env-gated."""
    val = os.environ.get("V9_NEUTRAL_SPEC", "").strip().lower()
    return val in ("1", "true", "yes", "on")


def summarise_spec() -> Dict[str, Any]:
    return {
        "neutral_supply_version": NEUTRAL_SUPPLY_VERSION,
        "car_total_capacity": NEUTRAL_SUPPLY_SPEC["car"]["total_capacity"],
        "bike_total_capacity": NEUTRAL_SUPPLY_SPEC["bike"]["total_capacity"],
        "removed_d_only_items": list(REMOVED_D_ONLY_ITEMS),
    }


__all__ = [
    "NEUTRAL_SUPPLY_SPEC",
    "NEUTRAL_SUPPLY_VERSION",
    "REMOVED_D_ONLY_ITEMS",
    "neutral_spec_active",
    "summarise_spec",
]
