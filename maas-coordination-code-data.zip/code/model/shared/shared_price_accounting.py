"""Two-layer price accounting (V9 Phase 1.2, per §22 adjudication).

Every realised price is a composition of two things:
- **Layer A — fare card** (world property, §5 fare_card_anchors, unified in
  `shared_fare_card`).
- **Layer B — price-formation mechanism** (architecture-specific: C's DRC
  subsidy, D's operator competition + surge). This is the research variable.

Neutrality-gate reporting (Phase 1.5) requires that Layer B be either
neutralised (both sides bare-card, no subsidy, no competition surge) or
reported as separate columns so the gate call reads only Layer A.

This module publishes:
- `consumer_price(row)` — what the commuter actually paid (post-subsidy /
  post-competition).
- `system_net_cost(row)` — total system flow (what the operator received
  before/after subsidy; positive = system pays out).
- `price_formation_delta(row)` — `system_net_cost - card_only_price`, i.e.
  the Layer-B mechanism's contribution.
- `card_only_price(row, card)` — the counterfactual price under Layer A only,
  no Layer B mechanism.

Row schema. Each helper accepts a dict-like row with the keys:
- `price` (system-facing total price, pre any consumer-side subsidy)
- `subsidy` (optional; consumer-side subsidy from C's DRC; defaults 0)
- `mode` (fare_card_anchors mode id; used by `card_only_price`)
- `distance_units`, `time_ticks` (used by `card_only_price`)
- `off_peak` (optional bool)
"""
from __future__ import annotations

from typing import Any, Dict, Optional

from shared_fare_card import compute_fare


def consumer_price(row: Dict[str, Any]) -> float:
    """Commuter-facing price (post-subsidy). Falls back to `price` if
    `subsidy` is missing."""
    price = float(row.get("price") or 0.0)
    subsidy = float(row.get("subsidy") or 0.0)
    return round(price - subsidy, 4)


def system_net_cost(row: Dict[str, Any]) -> float:
    """System-flow price (pre-subsidy). Under D-competition, this is what the
    winning operator was actually paid; under C-DRC, this is the operator's
    take before any consumer-side subsidy is booked as a system cost."""
    return round(float(row.get("price") or 0.0), 4)


def card_only_price(
    row: Dict[str, Any],
    *,
    mode_override: Optional[str] = None,
) -> float:
    """Layer-A-only price: fare card × trip characteristics, no Layer-B mechanism.

    Used to compute `price_formation_delta` for the Phase 1.5 report. Mode
    is derived from `row["mode"]` (or `mode_override`); distance and time
    from `row["distance_units"]` and `row["time_ticks"]`.
    """
    mode = str(mode_override or row.get("mode") or "walk")
    dist = float(row.get("distance_units") or 0.0)
    time_ticks = float(row.get("time_ticks") or 0.0)
    off_peak = bool(row.get("off_peak") or False)
    try:
        return compute_fare(
            mode,
            distance_units=dist,
            time_ticks=time_ticks,
            off_peak=off_peak,
        )
    except KeyError:
        return 0.0


def price_formation_delta(row: Dict[str, Any]) -> float:
    """Δ = system_net_cost - card_only_price. Attributable to Layer B."""
    return round(system_net_cost(row) - card_only_price(row), 4)


def annotate_row(row: Dict[str, Any]) -> Dict[str, Any]:
    """Return a shallow-copy of `row` with the three columns appended:
    `consumer_price`, `system_net_cost`, `card_only_price`,
    `price_formation_delta`. Used by Phase 1.3+ runners emitting request-level
    CSVs so downstream aggregators (gate calculator, paper tables) can drop
    the raw `price` column without ambiguity."""
    out = dict(row)
    out["consumer_price"] = consumer_price(row)
    out["system_net_cost"] = system_net_cost(row)
    out["card_only_price"] = card_only_price(row)
    out["price_formation_delta"] = price_formation_delta(row)
    return out


__all__ = [
    "consumer_price",
    "system_net_cost",
    "card_only_price",
    "price_formation_delta",
    "annotate_row",
]
