"""Shared fare card publisher (V9 Phase 1.2).

Single source of truth for the model fare card, adopted verbatim from
`fare_card_anchors.md` §5 (2026-07-14 Sydney IPART/UberX/DiDi/Lime calibration).

Card form (fixed by §5, no free choice):
    fare = base + distance_rate * d_grid + time_rate * t_tick

Applied **per leg**. Grid unit ≈ 0.8 km; tick = 10 min. All AUD.

Doctrinal role. This module is a WORLD PROPERTY publisher (§22 adjudication).
Both C and D consume from here when V9_NEUTRAL_SPEC=1 is in effect. The
price-formation MECHANISM (DRC subsidy on C, competition/surge on D) sits
above this layer at the architecture side and is the research variable.
"""
from __future__ import annotations

import math
import os
from typing import Dict, Any, Optional


# --- §5 model rate card (fare_card_anchors.md §5) ---------------------------
#
# Column semantics: base (AUD), distance_rate (AUD/grid-unit), time_rate
# (AUD/tick). `cap` is AUD trip cap (None = no cap). Off-peak discount applied
# via multiplier 0.70 in `compute_fare` when `off_peak` flag set.

FARE_CARD: Dict[str, Dict[str, Optional[float]]] = {
    "train": {
        "base": 3.20, "distance_rate": 0.08, "time_rate": 0.00,
        "cap": 9.55, "off_peak_multiplier": 0.70, "proxy": "Opal train / metro",
    },
    "bus": {
        "base": 3.20, "distance_rate": 0.19, "time_rate": 0.00,
        "cap": 5.05, "off_peak_multiplier": 0.70, "proxy": "Opal bus",
    },
    "light_rail": {
        "base": 3.20, "distance_rate": 0.19, "time_rate": 0.00,
        "cap": 5.05, "off_peak_multiplier": 0.70, "proxy": "Opal light rail",
    },
    "ferry": {
        "base": 8.39, "distance_rate": 0.00, "time_rate": 0.00,
        "cap": None, "off_peak_multiplier": 0.70, "proxy": "Opal ferry (flat)",
    },
    "ride_hail": {
        "base": 1.70, "distance_rate": 1.32, "time_rate": 4.00,
        "cap": None, "off_peak_multiplier": 1.00, "proxy": "Uber/DiDi midpoint",
    },
    "uber": {
        "base": 0.55, "distance_rate": 1.48, "time_rate": 4.50,
        "cap": None, "off_peak_multiplier": 1.00, "proxy": "UberX explicit",
    },
    "didi": {
        "base": 2.80, "distance_rate": 1.16, "time_rate": 3.50,
        "cap": None, "off_peak_multiplier": 1.00, "proxy": "DiDi Express explicit",
    },
    "micromobility": {
        "base": 1.00, "distance_rate": 0.00, "time_rate": 4.50,
        "cap": None, "off_peak_multiplier": 1.00, "proxy": "Lime scooter / e-bike",
    },
    "walk": {
        "base": 0.00, "distance_rate": 0.00, "time_rate": 0.00,
        "cap": None, "off_peak_multiplier": 1.00, "proxy": "walk (free)",
    },
}

# Transfer discount within a single Opal PT journey (AUD per mode-swap).
# Off-peak/weekend caps + 30% off-peak discount are Phase-1-optional.
OPAL_TRANSFER_DISCOUNT_AUD = 2.00
OPAL_DAILY_CAP_AUD = 19.30
OPAL_WEEKLY_CAP_AUD = 50.00

# Card version tag — appears in the neutral-spec manifest.
FARE_CARD_VERSION = "fare_card_anchors_2026_07_14"


# --- Canonical Layer-A input helpers (V9 §1.4 STOP #2(bis), 2026-07-14) ------
#
# Single source of truth for `distance_units` and `time_ticks` fed to
# `compute_fare` under V9_NEUTRAL_SPEC=1. Alignment target: C's consumption
# path (agent_MaaS_03._neutral_direct_price / calculate_single_mode_time_and_price).
# Provider posting (decentralized_provider.submit_offer_for_request), the
# D reporter card_only replay (run_decentralized_model._v9_d_card_only_inline,
# run_phase2_baseline._v9_d_card_only), and the C reporter card_only replay
# (run_visualisation_03._v9_compute_card_only_price) MUST call these helpers.
# Any ad-hoc inline Manhattan / travel_time reuse is FORBIDDEN under §22 doctrine
# — if price and card_only share ad-hoc inline code, PFD ≈ 0 is true by
# construction and proves nothing about card consumption.

# Peak window replicates C's `check_is_peak` (agent_service_provider_03.py:115):
# tick % 144 ∈ [36,60) ∪ [90,114).
_PEAK_INTERVALS = ((36, 60), (90, 114))

# Canonical grid-units-per-tick speeds for direct-vehicle offers. Mirror C's
# `get_travel_speed` (agent_service_provider_03.py:120). Bike is speed-invariant.
_CANONICAL_DIRECT_SPEED = {
    ("car", True): 6.5,
    ("car", False): 7.5,
    ("bike", True): 1.4,
    ("bike", False): 1.4,
    ("walk", True): 0.76,
    ("walk", False): 0.76,
}

# Mode alias table: request modes → canonical direct-vehicle mode used above.
# Kept small — extend only when a new request mode is introduced.
_DIRECT_MODE_ALIAS = {
    "car": "car", "ride_hail": "car", "uber": "car", "didi": "car",
    "bike": "bike", "micromobility": "bike",
    "walk": "walk",
}


def is_peak_tick(tick) -> bool:
    """Canonical peak-window flag. Matches C's `check_is_peak`."""
    try:
        t = int(tick) % 144
    except Exception:
        return False
    for lo, hi in _PEAK_INTERVALS:
        if lo <= t < hi:
            return True
    return False


def card_distance_units(origin, dest) -> float:
    """Canonical world-layer distance for the fare card: Manhattan on the grid.

    Alignment target: the world-canonical `d_grid` axis of `fare_card_anchors.md`
    §5. All Layer-A consumers (C direct-vehicle price, D provider posting,
    C+D reporter replays) MUST call this helper — never re-derive inline.
    """
    try:
        return float(abs(float(origin[0]) - float(dest[0])) +
                     abs(float(origin[1]) - float(dest[1])))
    except Exception as e:
        raise ValueError(f"card_distance_units: bad coords origin={origin!r} dest={dest!r}: {e}")


def canonical_direct_speed(mode: str, tick) -> float:
    """Canonical grid-units/tick speed for a direct-vehicle mode at `tick`.

    Peak-adjusted for car (6.5 peak / 7.5 off-peak); fixed 1.4 for bike;
    fixed 0.76 for walk. Matches C's `agent_service_provider_03.get_travel_speed`.
    """
    canon = _DIRECT_MODE_ALIAS.get(str(mode).strip().lower())
    if canon is None:
        raise KeyError(f"canonical_direct_speed: unsupported mode {mode!r}")
    key = (canon, is_peak_tick(tick))
    return float(_CANONICAL_DIRECT_SPEED[key])


def card_time_ticks_direct(mode: str, distance_units: float, tick) -> float:
    """Canonical time-ticks for direct-vehicle `compute_fare` input:
        max(1.0, distance_units / canonical_direct_speed(mode, tick))

    Mirrors C's `calculate_single_mode_time_and_price` formula
    (`total_length / unit_speed`) with the world-canonical Manhattan distance
    substituted for C's Euclidean route length so the world layer publishes
    ONE `(d, t)` pair per (o, d, tick) triple.
    """
    speed = canonical_direct_speed(mode, tick)
    d = float(distance_units)
    if d <= 0.0 or speed <= 0.0:
        return 1.0
    return max(1.0, d / speed)


# --- Neutral-spec flag ------------------------------------------------------
#
# The shared card is default-OFF for the Rep/Sydney legacy runs (V8 smoke,
# V7 evidence) so pre-Phase-1 artefacts don't shift under a rerun. Turn on
# for the Phase 1.3/1.4/1.5 runs by setting `V9_NEUTRAL_SPEC=1` in the
# environment. Callers should ask via `neutral_spec_active()`.

def neutral_spec_active() -> bool:
    """Return True iff V9_NEUTRAL_SPEC=1 (or 'true') is set in the env."""
    val = os.environ.get("V9_NEUTRAL_SPEC", "").strip().lower()
    return val in ("1", "true", "yes", "on")


# --- V9 caught-error-#8 fix (option a): world price factors ------------------
# `pt_price_factor` / `direct_price_factor` are WORLD properties. The V9
# neutral-spec fare refactor prices BOTH arms from this fixed card, so the
# Phase-C price sweep axes (which scaled the pre-refactor legacy pricing) went
# inert under the neutral spec (caught error #8, STOP #12(final)). They are
# re-bound HERE, at the single shared-card site — no architecture code — sourced
# from the env, which the runner sets per-world from `world_config`'s
# `world_level_exogenous_settings`; both arms consume identically ⇒ world
# property. Applied ONLY under the neutral spec; default 1.0 (unset) is an EXACT
# no-op. pt factor → PT modes {train,bus,light_rail,ferry} (hence PT + bundle-PT,
# which route through `compute_fare`/`compute_pt_journey_fare`); direct factor →
# {ride_hail, micromobility}.
_PT_FACTOR_MODES = frozenset({"train", "bus", "light_rail", "ferry"})
_DIRECT_FACTOR_MODES = frozenset({"ride_hail", "micromobility"})


def _world_price_factor(env_name: str) -> float:
    """World price multiplier from the env (neutral spec only; default 1.0)."""
    if not neutral_spec_active():
        return 1.0
    try:
        return float(os.environ.get(env_name, "1.0") or "1.0")
    except (TypeError, ValueError):
        return 1.0


def pt_price_factor() -> float:
    """World PT-fare multiplier (V9_PT_PRICE_FACTOR); 1.0 unless set under neutral."""
    return _world_price_factor("V9_PT_PRICE_FACTOR")


def direct_price_factor() -> float:
    """World direct-mode (ride_hail/micromobility) multiplier (V9_DIRECT_PRICE_FACTOR)."""
    return _world_price_factor("V9_DIRECT_PRICE_FACTOR")


def _price_factor_for_mode(mode: str) -> float:
    if mode in _PT_FACTOR_MODES:
        return pt_price_factor()
    if mode in _DIRECT_FACTOR_MODES:
        return direct_price_factor()
    return 1.0


# --- Fare compute -----------------------------------------------------------

def compute_fare(
    mode: str,
    *,
    distance_units: float = 0.0,
    time_ticks: float = 0.0,
    off_peak: bool = False,
) -> float:
    """Compute per-leg fare under the §5 card. Cap applied AFTER off-peak.

    Unknown modes raise KeyError — callers must map to a canonical mode id
    (e.g. `train`, `bus`, `ride_hail`, `micromobility`) before calling.
    """
    if mode not in FARE_CARD:
        raise KeyError(f"Unknown fare-card mode: {mode!r}")
    card = FARE_CARD[mode]
    base = float(card["base"])
    dist_rate = float(card["distance_rate"])
    time_rate = float(card["time_rate"])
    fare = base + dist_rate * float(distance_units) + time_rate * float(time_ticks)
    if off_peak:
        fare *= float(card.get("off_peak_multiplier") or 1.0)
    cap = card.get("cap")
    if cap is not None:
        fare = min(fare, float(cap))
    # V9 caught-error-#8 (option a): world price factor scales the finished card
    # fare uniformly (after cap ⇒ realised ratio == factor on card-priced modes).
    # factor == 1.0 (default / unset / non-neutral) skips ⇒ exact no-op.
    _factor = _price_factor_for_mode(mode)
    if _factor != 1.0:
        fare *= _factor
    return round(fare, 4)


def summarise_card() -> Dict[str, Any]:
    """Structured summary for manifest logging."""
    return {
        "fare_card_version": FARE_CARD_VERSION,
        "modes": {k: dict(v) for k, v in FARE_CARD.items()},
        "transfer_discount_aud": OPAL_TRANSFER_DISCOUNT_AUD,
        "daily_cap_aud": OPAL_DAILY_CAP_AUD,
        "weekly_cap_aud": OPAL_WEEKLY_CAP_AUD,
    }


# --- Journey fare (V9 §1.4.1 wiring) ---------------------------------------
#
# Opal is a single-journey card (per fare_card_anchors.md §5): one base per
# journey + distance term per leg, mode-transfer discount −2 per PT-mode change.
# The existing per-segment `compute_fare` is per-LEG; `compute_pt_journey_fare`
# below composes it into a journey total, matching real Opal semantics.
#
# `legs`: iterable of dicts with `mode` (∈ FARE_CARD PT modes: train, bus,
# light_rail, ferry) and `distance_units` (leg tap-on → tap-off straight-line
# in grid units). Off-peak flag applied uniformly to the journey.
#
# Transfer discount fires when consecutive PT legs' modes DIFFER (Sydney Opal
# rule; two consecutive train legs on the same or different train routes are
# NOT discounted, matching real tap-on/tap-off semantics on trains within
# 60 min).

_PT_JOURNEY_MODES = ("train", "bus", "light_rail", "ferry")


def compute_pt_journey_fare(legs, *, off_peak: bool = False) -> float:
    """Journey-level Opal fare across a list of PT legs.

    Rules (fare_card_anchors.md §5):
      - Each leg: `base + distance_rate·d`, off-peak multiplier if set, capped.
      - Between consecutive legs with different PT modes: subtract 2.00 AUD.
      - Journey total floored at 0.0.
      - Non-PT legs (ride_hail, micromobility, walk) contribute 0 to the PT
        journey fare (they belong to `compute_fare` at the bundle-connector
        level, not the journey level).

    Returns 0.0 for empty leg list. Unknown modes are treated as 0-fare.
    """
    legs = list(legs or [])
    if not legs:
        return 0.0
    total = 0.0
    prev_pt_mode = None
    # V9 caught-error-#8: scale the transfer discount by the same PT factor the
    # per-leg fares get (via compute_fare) so the whole journey scales uniformly
    # (realised journey ratio == pt_price_factor). 1.0 ⇒ exact no-op.
    _pt_f = pt_price_factor()
    for leg in legs:
        mode = str(leg.get("mode") or "").strip().lower()
        d = float(leg.get("distance_units") or 0.0)
        if mode not in _PT_JOURNEY_MODES:
            # walk / connector legs contribute nothing at the journey level.
            prev_pt_mode = None
            continue
        try:
            leg_fare = compute_fare(mode, distance_units=d, time_ticks=0.0, off_peak=off_peak)
        except KeyError:
            leg_fare = 0.0
        total += float(leg_fare)
        if prev_pt_mode is not None and prev_pt_mode != mode:
            total -= OPAL_TRANSFER_DISCOUNT_AUD * _pt_f
        prev_pt_mode = mode
    return round(max(0.0, total), 4)


# --- Bundle / itinerary composite card price (V9 §1.4.2, STOP #4 work-item 1) ---
#
# A D "bundle" (or a pure-PT itinerary assembled from per-hop segment offers) is
# priced under the neutral spec as the sum of its constituent-leg CARD fares —
# NOT as `sum(seg['price'])`, which repeats the per-hop base fare on every hop
# and applies a Layer-B multi-modal discount. That per-hop sum is the STOP #4
# work-item-1 defect behind the D public PFD residual: the direct-offer path was
# journey-fare wired (§1.4.1) but the segment-assembly path (`segment_sum_bundle`)
# was not. Composition rule (fare_card_anchors.md §5):
#   - Contiguous PT legs (train/bus/light_rail/ferry) -> ONE Opal journey via
#     `compute_pt_journey_fare` (single base + per-leg distance + −2 transfer
#     discount on PT-mode change). A run breaks on route_id OR mode change.
#   - Non-PT connector legs (car/ride_hail, bike/micromobility) -> per-leg card
#     fare via `compute_fare` at the mode's card rate (§1.4.2).
#   - walk / unknown legs contribute 0 (free world resource, §1.4.3).
# Each PT leg distance = tap-on -> tap-off Euclidean on the run's first/last
# segment endpoints, matching how the D provider and the reporter build journey
# legs, so a pure-PT bundle reprices to exactly its `card_only_price`.

def compute_bundle_card_price(segments, *, off_peak: bool = False) -> float:
    """Composite Opal card price for a D bundle / assembled PT itinerary.

    `segments`: ordered iterable of dicts, each with `mode` and `origin`/
    `destination` as (x, y); PT segments additionally carry `route_id`. Optional
    `depart_time` on connector legs sets the canonical peak flag for their time
    term. Returns the rounded AUD journey+connector card total.
    """
    segments = list(segments or [])
    if not segments:
        return 0.0
    journey_legs: list = []
    connector_total = 0.0
    cur_mode = cur_route = cur_first = cur_last = None

    def _flush():
        nonlocal cur_mode, cur_route, cur_first, cur_last
        if cur_mode is not None and cur_first is not None and cur_last is not None:
            d = ((cur_first[0] - cur_last[0]) ** 2 + (cur_first[1] - cur_last[1]) ** 2) ** 0.5
            journey_legs.append({"mode": cur_mode, "distance_units": float(d)})
        cur_mode = cur_route = cur_first = cur_last = None

    for seg in segments:
        m = str(seg.get("mode") or "").strip().lower()
        o = seg.get("origin"); d = seg.get("destination")
        if m in _PT_JOURNEY_MODES:
            rid = seg.get("route_id")
            if o is None or d is None:
                continue
            if rid != cur_route or m != cur_mode:
                _flush()
                cur_mode = m; cur_route = rid; cur_first = o
            cur_last = d
            continue
        # non-PT leg terminates any open PT run
        _flush()
        if m in ("walk", "unknown", ""):
            continue  # §1.4.3 walk connectors are free
        canon = _DIRECT_MODE_ALIAS.get(m)
        card_mode = {"car": "ride_hail", "bike": "micromobility"}.get(canon)
        if card_mode is None or o is None or d is None:
            continue  # unknown connector mode: no card charge (report, don't guess)
        dist = card_distance_units(o, d)
        tick = seg.get("depart_time", 0) or 0
        t = card_time_ticks_direct(canon, dist, tick)
        try:
            connector_total += float(compute_fare(card_mode, distance_units=dist,
                                                  time_ticks=t, off_peak=off_peak))
        except KeyError:
            pass
    _flush()
    return round(float(compute_pt_journey_fare(journey_legs, off_peak=off_peak))
                 + connector_total, 4)


__all__ = [
    "FARE_CARD",
    "FARE_CARD_VERSION",
    "OPAL_TRANSFER_DISCOUNT_AUD",
    "OPAL_DAILY_CAP_AUD",
    "OPAL_WEEKLY_CAP_AUD",
    "neutral_spec_active",
    "compute_fare",
    "compute_pt_journey_fare",
    "compute_bundle_card_price",
    "summarise_card",
    "card_distance_units",
    "card_time_ticks_direct",
    "canonical_direct_speed",
    "is_peak_tick",
]
