"""Canonical single-source for commuter PREFERENCE PARAMETERS (V9 §B.9,
STOP #4 work-item 2).

These are demand-side WORLD properties: the same humans travel in both the
centralised (C) and decentralised (D) worlds, so their income-tier value of
time, price/time utility coefficients, flexibility multiplier and mode-specific
constants (ASCs) must come from ONE place. Under `V9_NEUTRAL_SPEC=1` both C's
MNL (`agent_commuter_03.calculate_generalized_utility`) and D's offer
evaluation (`decentralized_commuter.calculate_option_utility`) read these
values from here instead of their local `database_01` / `config` copies.

Choice ARCHITECTURE stays per-side (C: MNL over the full menu; D: sequential
acceptance over visible posted offers). Only the PARAMETERS are unified.

Provenance of the values (verified 2026-07-14, STOP #4):
  - VALUE_OF_TIME, UTILITY_FUNCTION_BASE_COEFFICIENTS, FLEXIBILITY_ADJUSTMENTS
    were already byte-identical in C's database_01.py and D's config.py.
  - ASC_VALUES: all COMMUTE modes (car/bike/public/maas/bundle) were already
    0 == 0 on both sides (a prior v8 parity fix unified the maas ASC). The one
    residual divergence was `walk`: C = -2 (a deliberately refined mild walk
    disutility), D = 0 (an unset default). The shared source adopts C's -2 as
    the canonical world property. `walk` is not offered as a scored commute
    option in the parity option sets, so this does not affect the commute-mode
    ranking; it only makes a walk fallback marginally less attractive on the D
    side under the neutral spec (report, don't gate).
"""
from __future__ import annotations

import os

PREFERENCES_VERSION = "v9_shared_preferences_2026_07_14"

# Income-tier value of time ($/hour equivalent, converted to per-10-min in the
# utility functions as VOT/6). Identical on both sides pre-unification.
VALUE_OF_TIME = {
    "low": 5,
    "middle": 10,
    "high": 20,
}

# Flexibility multiplier on VOT (a flexible traveller values time less).
FLEXIBILITY_ADJUSTMENTS = {
    "low": 1.15,
    "medium": 1.0,
    "high": 0.85,
}

# Base price/time/walk/affordability coefficients. Income tiers scale beta_C /
# beta_T inside each side's utility function (high 0.9/1.2, middle 1.0/1.0,
# low 1.5/0.85) — that scaling is choice-logic, not a parameter, so it stays in
# each agent. Identical on both sides pre-unification.
UTILITY_FUNCTION_BASE_COEFFICIENTS = {
    "beta_C": -0.15,
    "beta_T": -0.09,
    "beta_W": -0.04,
    "beta_A": -0.04,
    "alpha": -0.01,
}

# Mode-specific alternative-specific constants. Commute modes all 0 (unbiased);
# walk carries C's refined -2. Both sides resolve a mode by prefix / exact key;
# extra D-only keys (bus/train/bundle) are included so D's exact-key lookups
# stay valid and equal to C's prefix resolution.
ASC_VALUES = {
    "walk": -2,
    "bike": 0,
    "car": 0,
    "public": 0,
    "bus": 0,
    "train": 0,
    "maas": 0,
    "bundle": 0,
    "default": 0,
}


def neutral_prefs_active() -> bool:
    """True iff V9_NEUTRAL_SPEC=1 (or 'true'/'yes'/'on') is set in the env."""
    return os.environ.get("V9_NEUTRAL_SPEC", "").strip().lower() in (
        "1", "true", "yes", "on",
    )


def shared_preferences():
    """Return the four canonical preference families as a tuple
    (VALUE_OF_TIME, ASC_VALUES, UTILITY_FUNCTION_BASE_COEFFICIENTS,
    FLEXIBILITY_ADJUSTMENTS). Callers pass these through their OWN choice logic.
    """
    return (VALUE_OF_TIME, ASC_VALUES, UTILITY_FUNCTION_BASE_COEFFICIENTS,
            FLEXIBILITY_ADJUSTMENTS)


__all__ = [
    "PREFERENCES_VERSION",
    "VALUE_OF_TIME",
    "FLEXIBILITY_ADJUSTMENTS",
    "UTILITY_FUNCTION_BASE_COEFFICIENTS",
    "ASC_VALUES",
    "neutral_prefs_active",
    "shared_preferences",
]
