"""
Canonical config used by BOTH centralised and decentralised ABMs.
Goal: ensure only matching mechanism differs.
"""

# Reproducibility
RANDOM_SEED = 42

# Simulation horizon (keep identical across both)
SIMULATION_STEPS = 144  # e.g., 24h * 6 steps/hour (10-min steps)

# Spatial grid (must match your station coordinates convention)
GRID_WIDTH = 100
GRID_HEIGHT = 80

# Population scale (must match)
NUM_COMMUTERS = 200  # NTEO Sydney faithful replication (was 140 in synthetic 5-hub build)

# Small-world mapping parameter (fixed final mapping)
SMALL_WORLD_P = 0.20

# Canonical PT in-vehicle time per adjacent stop hop.
# This matches centralised MaaS routing semantics.
PT_IN_VEHICLE_PER_HOP = 0.8

# Shared walk speed (grid units per tick). Mirrors Rep tree; sourced from
# the D bundle_router bug #1 fix, promoted to shared world-layer constant
# by V9 §27 so C-side door-to-door corrections use the same coefficient.
WALK_SPEED_UNITS_PER_TICK = 0.76

# Metric convention tag (V9 §27 Phase 1.1).
METRIC_CONVENTION = "door_to_door_v9_phase_1_0"
METRIC_CONVENTION_PRE = "station_to_station_pre_v9_phase_1_0"

# Shared walk / station-catchment radius (V9 §26.7 ruling; Phase 1.2).
# Mirrors Rep tree — see there for full commentary.
WALK_CATCHMENT_RADIUS = 15.0
