from __future__ import annotations

from copy import deepcopy
import os
from typing import Any, Mapping


S1_VARIANTS = ("S1_base", "S1_compressed", "S1_expanded")
S1_VARIANT_ENV = "S1_OPERATOR_HETEROGENEITY_VARIANT"
DEFAULT_S1_VARIANT = "S1_base"

DECN_FIELDS = (
    "base_price",
    "distance_rate",
    "speed",
    "bike_speed",
    "reliability",
    "quality_score",
    "fleet_capacity",
    "service_area",
)

CENTRALISED_PRICE_GROUPS = {
    "car": ("UberLike1", "UberLike2"),
    "bike": ("BikeShare1", "BikeShare2"),
}

VARIANT_FACTORS = {
    "S1_base": 1.0,
    "S1_compressed": 0.25,
    "S1_expanded": 1.75,
}

FIELD_BOUNDS = {
    "base_price": (0.01, None),
    "distance_rate": (0.01, None),
    "speed": (0.05, None),
    "bike_speed": (0.05, None),
    "reliability": (0.50, 0.99),
    "quality_score": (1.0, 100.0),
    "fleet_capacity": (1.0, None),
    "service_area": (10.0, None),
}


def resolve_s1_variant(variant: str | None = None) -> str:
    candidate = (variant or os.getenv(S1_VARIANT_ENV) or DEFAULT_S1_VARIANT).strip()
    if candidate not in S1_VARIANTS:
        raise ValueError(f"Unsupported S1 operator heterogeneity variant: {candidate}")
    return candidate


def get_variant_factor(variant: str | None = None) -> float:
    return VARIANT_FACTORS[resolve_s1_variant(variant)]


def transform_decentralized_ondemand_profiles(
    profiles: list[Mapping[str, Any]],
    *,
    variant: str | None = None,
) -> list[dict[str, Any]]:
    resolved = resolve_s1_variant(variant)
    transformed = [deepcopy(dict(profile)) for profile in profiles]
    factor = VARIANT_FACTORS[resolved]
    if factor != 1.0:
        field_means = {
            field: _mean(
                [
                    float(profile[field])
                    for profile in transformed
                    if profile.get(field) is not None
                ]
            )
            for field in DECN_FIELDS
        }

        for profile in transformed:
            for field in DECN_FIELDS:
                value = profile.get(field)
                if value is None:
                    continue
                shifted = field_means[field] + factor * (float(value) - field_means[field])
                bounded = _bounded(field, shifted)
                profile[field] = round(bounded, 6)

    _apply_structural_variant_rules(transformed, resolved)
    return transformed


def transform_centralized_price_overrides(
    base_prices: Mapping[str, float],
    *,
    variant: str | None = None,
) -> dict[str, float]:
    resolved = resolve_s1_variant(variant)
    factor = VARIANT_FACTORS[resolved]
    output = {name: float(price) for name, price in base_prices.items()}
    if factor == 1.0:
        return output

    for provider_names in CENTRALISED_PRICE_GROUPS.values():
        group_prices = [float(base_prices[name]) for name in provider_names]
        group_mean = _mean(group_prices)
        for name in provider_names:
            shifted = group_mean + factor * (float(base_prices[name]) - group_mean)
            output[name] = round(max(0.01, shifted), 6)
    return output


def build_decentralized_profile_rows(
    profiles: list[Mapping[str, Any]],
    *,
    variant: str,
    transformation_scope: str,
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for profile in profiles:
        rows.append(
            {
                "architecture": "decentralised",
                "variant": variant,
                "transformation_scope": transformation_scope,
                "provider_name": profile.get("operator_id"),
                "provider_group": "ondemand",
                "mode_set": "|".join(profile.get("mode_set", []) or []),
                "capacity": profile.get("fleet_capacity"),
                "base_price": profile.get("base_price"),
                "distance_rate": profile.get("distance_rate"),
                "speed": profile.get("speed"),
                "bike_speed": profile.get("bike_speed"),
                "reliability": profile.get("reliability"),
                "quality_score": profile.get("quality_score"),
                "service_area": profile.get("service_area"),
                "coverage_type": profile.get("coverage_type"),
                "preferred_zones": "|".join(profile.get("preferred_zones", []) or []),
                "out_of_preference_penalty_multiplier": profile.get("out_of_preference_penalty_multiplier"),
                "active_fields": "|".join(DECN_FIELDS),
            }
        )
    return rows


def build_centralized_profile_rows(
    *,
    prices: Mapping[str, float],
    capacities: Mapping[str, int],
    variant: str,
    transformation_scope: str,
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for provider_name, price in prices.items():
        provider_group = "car" if provider_name.startswith("UberLike") else "bike"
        rows.append(
            {
                "architecture": "centralised",
                "variant": variant,
                "transformation_scope": transformation_scope,
                "provider_name": provider_name,
                "provider_group": provider_group,
                "mode_set": provider_group,
                "capacity": capacities.get(provider_name),
                "base_price": round(float(price), 6),
                "distance_rate": "",
                "speed": "",
                "bike_speed": "",
                "reliability": "",
                "quality_score": "",
                "active_fields": "base_price",
            }
        )
    return rows


def s1_transformation_rule_markdown() -> str:
    return "\n".join(
        [
            "### Transformation rule",
            "",
            "- `S1_base`: no change.",
            "- `S1_compressed`: stronger compression toward the fleet mean plus city-wide coverage normalization.",
            "- `S1_expanded`: stronger separation away from the mean plus explicit capacity and service-area specialization.",
            "- Decentralised applies the rule to active on-demand profile fields: `base_price`, `distance_rate`, `speed`, `bike_speed`, `reliability`, `quality_score`, `fleet_capacity`, `service_area`.",
            "- Centralised applies the rule only to active legacy on-demand base-price fields because its reference path does not expose speed, reliability, or quality parameters without redesign.",
            "- Centralised prices are transformed within mode groups (`car`, `bike`) rather than across all four providers to preserve the legacy mode-scale structure.",
            "",
        ]
    )


def _mean(values: list[float]) -> float:
    return (sum(values) / len(values)) if values else 0.0


def _bounded(field: str, value: float) -> float:
    lower, upper = FIELD_BOUNDS[field]
    bounded = max(lower, value) if lower is not None else value
    bounded = min(upper, bounded) if upper is not None else bounded
    return bounded


def _apply_structural_variant_rules(
    profiles: list[dict[str, Any]],
    resolved: str,
) -> None:
    if resolved == "S1_base":
        return

    profile_by_id = {str(profile.get("operator_id")): profile for profile in profiles}

    if resolved == "S1_compressed":
        for profile in profiles:
            profile["coverage_type"] = "city_wide"
            profile["service_area"] = 120.0
            profile["out_of_preference_penalty_multiplier"] = 1.02
        return

    if resolved != "S1_expanded":
        return

    low_price = profile_by_id.get("ondemand_A_low_price")
    premium = profile_by_id.get("ondemand_B_fast_premium")
    balanced = profile_by_id.get("ondemand_C_balanced")

    if low_price is not None:
        low_price["coverage_type"] = "district"
        low_price["preferred_zones"] = ["nw", "sw"]
        low_price["service_area"] = 36.0
        low_price["fleet_capacity"] = max(float(low_price.get("fleet_capacity", 0) or 0), 34.0)
        low_price["base_price"] = round(max(0.01, float(low_price.get("base_price", 0) or 0) * 0.78), 6)
        low_price["distance_rate"] = round(max(0.01, float(low_price.get("distance_rate", 0) or 0) * 0.82), 6)
        low_price["out_of_preference_penalty_multiplier"] = 1.28

    if premium is not None:
        premium["coverage_type"] = "district"
        premium["preferred_zones"] = ["ne", "se"]
        premium["service_area"] = 32.0
        premium["fleet_capacity"] = min(float(premium.get("fleet_capacity", 0) or 0), 12.0)
        premium["base_price"] = round(max(0.01, float(premium.get("base_price", 0) or 0) * 1.22), 6)
        premium["distance_rate"] = round(max(0.01, float(premium.get("distance_rate", 0) or 0) * 1.18), 6)
        premium["speed"] = round(max(0.05, float(premium.get("speed", 0) or 0) * 1.08), 6)
        premium["out_of_preference_penalty_multiplier"] = 1.32

    if balanced is not None:
        balanced["coverage_type"] = "regional"
        balanced["preferred_zones"] = ["nw", "ne"]
        balanced["service_area"] = 46.0
        balanced["fleet_capacity"] = max(float(balanced.get("fleet_capacity", 0) or 0), 24.0)
        balanced["base_price"] = round(max(0.01, float(balanced.get("base_price", 0) or 0) * 0.92), 6)
        balanced["distance_rate"] = round(max(0.01, float(balanced.get("distance_rate", 0) or 0) * 0.94), 6)
        balanced["out_of_preference_penalty_multiplier"] = 1.12
