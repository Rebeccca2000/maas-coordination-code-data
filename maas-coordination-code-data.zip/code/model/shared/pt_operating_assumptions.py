from __future__ import annotations

from typing import Any, Dict, Iterable, List, Tuple
import copy
import math
import os

from shared_experiment_config import PT_IN_VEHICLE_PER_HOP
from shared_topology_v2 import get_route_definition, get_shared_topology_v2


PT_PEAK_WINDOWS = ((36, 60), (90, 114))

PT_MODE_FARE_RULES: Dict[str, Dict[str, float]] = {
    "train": {
        "base_fare": 1.8,
        "distance_rate": 0.20,
        "peak_multiplier": 1.15,
        "offpeak_multiplier": 1.00,
    },
    "bus": {
        "base_fare": 1.2,
        "distance_rate": 0.18,
        "peak_multiplier": 1.10,
        "offpeak_multiplier": 1.00,
    },
    "transfer": {
        "base_fare": 0.0,
        "distance_rate": 0.0,
        "peak_multiplier": 1.00,
        "offpeak_multiplier": 1.00,
    },
}


def is_peak_pt_time(step: float | int) -> bool:
    time_of_day = float(step) % 144
    return any(start <= time_of_day < end for start, end in PT_PEAK_WINDOWS)


def get_pt_mode_fare_rule(mode: str) -> Dict[str, float]:
    return copy.deepcopy(PT_MODE_FARE_RULES[mode])


def get_pt_mode_base_fare(
    mode: str,
    depart_step: float | int,
    *,
    price_factor: float = 1.0,
) -> float:
    rule = PT_MODE_FARE_RULES[mode]
    multiplier = rule["peak_multiplier"] if is_peak_pt_time(depart_step) else rule["offpeak_multiplier"]
    return round(rule["base_fare"] * multiplier * float(price_factor), 2)


def get_pt_mode_distance_rate(mode: str) -> float:
    return float(PT_MODE_FARE_RULES[mode]["distance_rate"])


def get_pt_schedule_interval(route_id: str) -> int:
    return int(get_route_definition(route_id)["frequency"])


def get_pt_expected_wait_time(route_id: str) -> float:
    return float(get_pt_schedule_interval(route_id)) / 2.0


def next_departure(route_id: str, station_id: str, tick: float | int) -> int:
    """V9 §1.2 shared timetable primitive. Mirrors Rep tree — see there."""
    interval = get_pt_schedule_interval(route_id)
    if interval <= 0:
        return int(math.ceil(tick))
    t = float(tick)
    k = math.ceil(t / float(interval))
    return int(k * interval)


def get_pt_in_vehicle_time_per_hop(route_id: str | None = None) -> float:
    if route_id:
        return float(get_route_definition(route_id).get("travel_time", PT_IN_VEHICLE_PER_HOP))
    return float(PT_IN_VEHICLE_PER_HOP)


def compute_pt_segment_fare(
    *,
    mode: str,
    origin_xy: Tuple[int, int],
    destination_xy: Tuple[int, int],
    depart_step: float | int,
    price_factor: float = 1.0,
) -> float:
    rule = PT_MODE_FARE_RULES[mode]
    multiplier = rule["peak_multiplier"] if is_peak_pt_time(depart_step) else rule["offpeak_multiplier"]
    distance = math.sqrt((origin_xy[0] - destination_xy[0]) ** 2 + (origin_xy[1] - destination_xy[1]) ** 2)
    fare = (rule["base_fare"] + distance * rule["distance_rate"]) * multiplier * float(price_factor)
    return round(fare, 2)


def get_pt_route_operating_assumptions() -> List[Dict[str, Any]]:
    topology = get_shared_topology_v2()
    rows: List[Dict[str, Any]] = []
    for route_id, route_def in sorted(topology.route_catalog.items()):
        mode = str(route_def["mode"])
        if mode not in ("train", "bus"):
            continue
        rows.append(
            {
                "route_id": route_id,
                "mode": mode,
                "service_scope": route_def.get("service_scope"),
                "corridor_id": route_def.get("corridor_id"),
                "zone_id": route_def.get("zone_id"),
                "schedule_interval": int(route_def["frequency"]),
                "expected_wait_time": get_pt_expected_wait_time(route_id),
                "in_vehicle_per_hop": get_pt_in_vehicle_time_per_hop(route_id),
                "capacity": int(route_def["capacity"]),
                "base_fare_peak": get_pt_mode_base_fare(mode, 40),
                "base_fare_offpeak": get_pt_mode_base_fare(mode, 10),
                "distance_rate": get_pt_mode_distance_rate(mode),
            }
        )
    return rows


def compute_pt_itinerary_time_and_price(
    *,
    detailed_itinerary: Iterable[tuple],
    stations: Dict[str, Dict[str, Tuple[int, int]]],
    transfers: Dict[Tuple[str, str], float],
    depart_step: int,
    price_factor: float = 1.0,
    wait_time_factor: float = 1.0,
    in_vehicle_time_factor: float = 1.0,
) -> Tuple[float, float]:
    total_time = 0.0
    total_price = 0.0
    current_time = float(depart_step)

    def _station_xy(station_id: str) -> Tuple[int, int]:
        if station_id.startswith("T_"):
            return stations["train"][station_id]
        if station_id.startswith("B_"):
            return stations["bus"][station_id]
        raise KeyError(f"Unknown station id {station_id}")

    # V9 §1.4.1 wiring: journey-fare replacement under V9_NEUTRAL_SPEC=1. Mirrors Rep.
    _journey_legs: list = []
    _neutral = os.environ.get("V9_NEUTRAL_SPEC", "").strip().lower() in ("1", "true", "yes", "on")

    for segment in detailed_itinerary:
        segment_type = segment[0]
        if segment_type in ("bus", "train"):
            route_id = segment[1]
            stops = list(segment[2])
            if len(stops) < 2:
                continue
            wait_time = get_pt_expected_wait_time(route_id) * float(wait_time_factor)
            total_time += wait_time
            current_time += wait_time

            hop_time = get_pt_in_vehicle_time_per_hop(route_id) * float(in_vehicle_time_factor)
            leg_first_xy = _station_xy(stops[0])
            leg_last_xy = _station_xy(stops[-1])
            for origin_station, destination_station in zip(stops, stops[1:]):
                origin_xy = _station_xy(origin_station)
                destination_xy = _station_xy(destination_station)
                total_time += hop_time
                if not _neutral:
                    total_price += compute_pt_segment_fare(
                        mode=segment_type,
                        origin_xy=origin_xy,
                        destination_xy=destination_xy,
                        depart_step=current_time,
                        price_factor=price_factor,
                    )
                current_time += hop_time
            _leg_dist = (
                (leg_first_xy[0] - leg_last_xy[0]) ** 2
                + (leg_first_xy[1] - leg_last_xy[1]) ** 2
            ) ** 0.5
            _journey_legs.append({"mode": segment_type, "distance_units": float(_leg_dist)})
        elif segment_type == "transfer":
            transfer_pair = tuple(segment[1])
            transfer_time = float(transfers.get(transfer_pair, 1.0))
            total_time += transfer_time
            current_time += transfer_time

    if _neutral:
        try:
            from shared_fare_card import compute_pt_journey_fare
            total_price = compute_pt_journey_fare(_journey_legs)
        except Exception:
            total_price = 0.0

    return round(total_time, 4), round(total_price, 2)
