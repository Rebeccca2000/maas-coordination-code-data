from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from typing import Any, Mapping
import json
import math
import os

from shared_experiment_config import NUM_COMMUTERS


WORLD_CONFIG_ENV = "CROSS_WORLD_WORLD_CONFIG_JSON"
DEFAULT_BACKGROUND_TRAFFIC_AMOUNT = 120
DEFAULT_PT_PRICE_FACTOR = 1.0
DEFAULT_PT_WAIT_TIME_FACTOR = 1.0
DEFAULT_PT_IN_VEHICLE_TIME_FACTOR = 1.0
DEFAULT_OPERATOR_NICHE_PROFILE = "baseline"


def resolve_world_config_path(path: str | os.PathLike[str] | None = None) -> str | None:
    candidate = path if path not in (None, "") else os.getenv(WORLD_CONFIG_ENV)
    if candidate in (None, ""):
        return None
    return str(Path(candidate).resolve())


def load_world_config(path: str | os.PathLike[str] | None = None) -> dict[str, Any] | None:
    resolved = resolve_world_config_path(path)
    if resolved is None:
        return None
    with open(resolved, "r", encoding="utf-8") as fh:
        payload = json.load(fh)
    if not isinstance(payload, dict):
        raise ValueError(f"World config at {resolved} must contain a top-level JSON object")
    payload = deepcopy(payload)
    payload["_resolved_world_config_path"] = resolved
    return payload


def normalize_world_settings(
    world_config: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    config = dict(world_config or {})
    nested_settings = config.get("world_level_exogenous_settings")
    if nested_settings:
        settings = dict(nested_settings)
    else:
        # Accept already-normalized world settings so this function is idempotent.
        settings = {
            key: config.get(key)
            for key in (
                "baseline_num_commuters",
                "baseline_background_traffic_amount",
                "direct_price_factor",
                "pt_price_factor",
                "pt_wait_time_factor",
                "pt_in_vehicle_time_factor",
                "direct_capacity_factor",
                "background_traffic_factor",
                "operator_niche_profile",
                "materialized_commuter_count",
                "materialized_background_traffic_amount",
                "trip_pattern_profile",
                "morning_window",
                "evening_window",
            )
        }

    baseline_num_commuters = _as_int(
        settings.get("baseline_num_commuters"),
        default=NUM_COMMUTERS,
    )
    baseline_background_traffic_amount = _as_int(
        settings.get("baseline_background_traffic_amount"),
        default=DEFAULT_BACKGROUND_TRAFFIC_AMOUNT,
    )
    direct_price_factor = _as_float(
        settings.get("direct_price_factor"),
        default=1.0,
    )
    pt_price_factor = _as_float(
        settings.get("pt_price_factor"),
        default=DEFAULT_PT_PRICE_FACTOR,
    )
    pt_wait_time_factor = _as_float(
        settings.get("pt_wait_time_factor"),
        default=DEFAULT_PT_WAIT_TIME_FACTOR,
    )
    pt_in_vehicle_time_factor = _as_float(
        settings.get("pt_in_vehicle_time_factor"),
        default=DEFAULT_PT_IN_VEHICLE_TIME_FACTOR,
    )
    direct_capacity_factor = _as_float(
        settings.get("direct_capacity_factor"),
        default=1.0,
    )
    background_traffic_factor = _as_float(
        settings.get("background_traffic_factor"),
        default=1.0,
    )

    materialized_commuter_count = _as_int(
        settings.get("materialized_commuter_count"),
        default=baseline_num_commuters,
    )
    materialized_background_traffic_amount = _as_int(
        settings.get("materialized_background_traffic_amount"),
        default=_round_half_up(
            baseline_background_traffic_amount * background_traffic_factor,
            minimum=0,
        ),
    )
    trip_pattern_profile = str(settings.get("trip_pattern_profile") or "baseline").strip() or "baseline"
    operator_niche_profile = (
        str(settings.get("operator_niche_profile") or DEFAULT_OPERATOR_NICHE_PROFILE).strip()
        or DEFAULT_OPERATOR_NICHE_PROFILE
    )
    morning_window = _window_or_default(settings.get("morning_window"), default=(40, 56))
    evening_window = _window_or_default(settings.get("evening_window"), default=(96, 112))

    return {
        "world_id": str(config.get("world_id", "")).strip(),
        "scenario_name": str(config.get("scenario_name", "")).strip(),
        "world_config_path": str(
            config.get("_resolved_world_config_path", config.get("world_config_path", ""))
        ).strip(),
        "direct_price_factor": direct_price_factor,
        "pt_price_factor": pt_price_factor,
        "pt_wait_time_factor": pt_wait_time_factor,
        "pt_in_vehicle_time_factor": pt_in_vehicle_time_factor,
        "direct_capacity_factor": direct_capacity_factor,
        "background_traffic_factor": background_traffic_factor,
        "baseline_num_commuters": baseline_num_commuters,
        "materialized_commuter_count": materialized_commuter_count,
        "baseline_background_traffic_amount": baseline_background_traffic_amount,
        "materialized_background_traffic_amount": materialized_background_traffic_amount,
        "trip_pattern_profile": trip_pattern_profile,
        "operator_niche_profile": operator_niche_profile,
        "morning_window": morning_window,
        "evening_window": evening_window,
    }


def load_world_settings(path: str | os.PathLike[str] | None = None) -> dict[str, Any]:
    return normalize_world_settings(load_world_config(path))


def resolve_num_commuters(
    *,
    fixed_commuter_count: int | None = None,
    world_settings: Mapping[str, Any] | None = None,
    fallback: int = NUM_COMMUTERS,
) -> int:
    requested = _as_int(
        (world_settings or {}).get("materialized_commuter_count"),
        default=fallback,
    )
    if fixed_commuter_count is None:
        return requested
    fixed_commuter_count = int(fixed_commuter_count)
    if fixed_commuter_count != requested:
        raise ValueError(
            "Fixed commuter count does not match world-config materialized_commuter_count: "
            f"{fixed_commuter_count} != {requested}"
        )
    return fixed_commuter_count


def resolve_background_traffic_amount(
    *,
    world_settings: Mapping[str, Any] | None = None,
    baseline_amount: int = DEFAULT_BACKGROUND_TRAFFIC_AMOUNT,
) -> int:
    return _as_int(
        (world_settings or {}).get("materialized_background_traffic_amount"),
        default=baseline_amount,
    )


def scale_direct_price(
    value: float | int,
    *,
    world_settings: Mapping[str, Any] | None = None,
) -> float:
    factor = _as_float((world_settings or {}).get("direct_price_factor"), default=1.0)
    return round(float(value) * factor, 6)


def scale_pt_price(
    value: float | int,
    *,
    world_settings: Mapping[str, Any] | None = None,
) -> float:
    factor = _as_float((world_settings or {}).get("pt_price_factor"), default=DEFAULT_PT_PRICE_FACTOR)
    return round(float(value) * factor, 6)


def scale_direct_capacity(
    value: float | int,
    *,
    world_settings: Mapping[str, Any] | None = None,
) -> int:
    factor = _as_float((world_settings or {}).get("direct_capacity_factor"), default=1.0)
    return _round_half_up(float(value) * factor)


def apply_world_scales_to_decentralized_ondemand_profiles(
    profiles: list[Mapping[str, Any]],
    *,
    world_settings: Mapping[str, Any] | None = None,
) -> list[dict[str, Any]]:
    scaled: list[dict[str, Any]] = []
    for profile in profiles:
        row = deepcopy(dict(profile))
        row["fleet_capacity"] = scale_direct_capacity(
            row.get("fleet_capacity", 0),
            world_settings=world_settings,
        )
        row["base_price"] = scale_direct_price(
            row.get("base_price", 0.0),
            world_settings=world_settings,
        )
        row["distance_rate"] = scale_direct_price(
            row.get("distance_rate", 0.0),
            world_settings=world_settings,
        )
        scaled.append(row)
    return scaled


def resolve_pt_price_factor(
    *,
    world_settings: Mapping[str, Any] | None = None,
) -> float:
    return _as_float(
        (world_settings or {}).get("pt_price_factor"),
        default=DEFAULT_PT_PRICE_FACTOR,
    )


def resolve_pt_wait_time_factor(
    *,
    world_settings: Mapping[str, Any] | None = None,
) -> float:
    return _as_float(
        (world_settings or {}).get("pt_wait_time_factor"),
        default=DEFAULT_PT_WAIT_TIME_FACTOR,
    )


def resolve_pt_in_vehicle_time_factor(
    *,
    world_settings: Mapping[str, Any] | None = None,
) -> float:
    return _as_float(
        (world_settings or {}).get("pt_in_vehicle_time_factor"),
        default=DEFAULT_PT_IN_VEHICLE_TIME_FACTOR,
    )


def resolve_operator_niche_profile(
    *,
    world_settings: Mapping[str, Any] | None = None,
) -> str:
    return (
        str((world_settings or {}).get("operator_niche_profile") or DEFAULT_OPERATOR_NICHE_PROFILE).strip()
        or DEFAULT_OPERATOR_NICHE_PROFILE
    )


def _round_half_up(value: float, *, minimum: int = 1) -> int:
    return max(minimum, int(math.floor(float(value) + 0.5)))


def _as_float(value: Any, *, default: float) -> float:
    if value in (None, ""):
        return float(default)
    return float(value)


def _as_int(value: Any, *, default: int) -> int:
    if value in (None, ""):
        return int(default)
    return int(value)


def _window_or_default(value: Any, *, default: tuple[int, int]) -> tuple[int, int]:
    if value in (None, ""):
        return default
    if isinstance(value, (list, tuple)) and len(value) == 2:
        return (int(value[0]), int(value[1]))
    raise ValueError(f"Expected a 2-value morning/evening window, got {value!r}")


__all__ = [
    "DEFAULT_BACKGROUND_TRAFFIC_AMOUNT",
    "DEFAULT_OPERATOR_NICHE_PROFILE",
    "DEFAULT_PT_IN_VEHICLE_TIME_FACTOR",
    "DEFAULT_PT_PRICE_FACTOR",
    "DEFAULT_PT_WAIT_TIME_FACTOR",
    "WORLD_CONFIG_ENV",
    "apply_world_scales_to_decentralized_ondemand_profiles",
    "load_world_config",
    "load_world_settings",
    "normalize_world_settings",
    "resolve_background_traffic_amount",
    "resolve_num_commuters",
    "resolve_operator_niche_profile",
    "resolve_pt_in_vehicle_time_factor",
    "resolve_pt_price_factor",
    "resolve_pt_wait_time_factor",
    "resolve_world_config_path",
    "scale_direct_capacity",
    "scale_direct_price",
    "scale_pt_price",
]
