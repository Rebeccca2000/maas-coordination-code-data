"""Canonical single-source for the D-side income x mode matching subsidy
(V9 caught error #6, Rulings A+B, 2026-07-14).

Historical state (pre-ruling): the same income-tiered subsidy table was
inlined in THREE places in the D tree, all ungated:
  1. `decentralized_commuter.calculate_option_utility` via `_apply_subsidy`
     (SUBSIDY_DATASET) -> steers the commuter's option ranking (CHOICE).
  2. `blockchain_interface.run_marketplace_matching` (~946-972)
     `final_price = offer_price x (1 - rate)` -> the RECORDED price /
     CSV `consumer_price` (this is the site the PM verified as caught #6).
  3. `blockchain_interface._run_matching_algorithm` (~1113-1140)
     `effective_price = price x (1 - rate)` inside the offer score ->
     steers WHICH offer wins the match (ALLOCATION).

All three used the identical rate table (bike/car/maas-bundle values equal
across the three copies; only the internal key spelling differed). This
module is now the ONE source; every site consumes `subsidy_rate(...)`.

Gating (Ruling A, amended by the STOP #3 USER DECISION 2026-07-14):
  - `V9_D_MATCH_SUBSIDY` explicit value ALWAYS wins when set.
  - Its DEFAULT is spec-dependent:
      * `V9_NEUTRAL_SPEC` UNSET (legacy path)  -> default ON  (bit-identical
        to pre-ruling; provenance preserved).
      * `V9_NEUTRAL_SPEC=1` (neutral baseline) -> default OFF. The neutral
        baseline is zero-subsidy on BOTH sides, symmetric with C's pool=0.
        The subsidy returns only as the explicitly-labeled RQ5 "matching-
        subsidy design" arm (`V9_NEUTRAL_SPEC=1 V9_D_MATCH_SUBSIDY=1`).
  - Forced OFF whenever `V9_LAYER_B_NEUTRAL=1`, regardless of the above --
    gate 1.5's "bare-card both sides" is non-negotiable.

Truthful accounting (Ruling B, applied by the reporters, not here): when the
subsidy fires, `subsidy` = offer_price x rate (actual transfer),
`consumer_price` = post-subsidy, `system_net_cost` = consumer_price + subsidy
(= pre-subsidy posted offer price). This module exposes `subsidy_transfer`
and `pre_subsidy_price` so the reporters compute those from a single formula.
"""
from __future__ import annotations

import os
from typing import Optional

SUBSIDY_VERSION = "d_match_subsidy_v9_2026_07_14"

# Verbatim from the three historical inline copies. Rates identical across
# them; canonical internal keys are {'bike','car','maas'} ('maas' covers
# maas/bundle rides, matching the historical MaaS_Bundle == maas == bundle
# values).
_SUBSIDY_BY_MODE = {
    "low":    {"bike": 0.50, "car": 0.55, "maas": 0.50},
    "middle": {"bike": 0.23, "car": 0.35, "maas": 0.35},
    "high":   {"bike": 0.10, "car": 0.05, "maas": 0.10},
}


def _env_flag(name: str, default: bool) -> bool:
    v = os.environ.get(name)
    if v is None:
        return default
    return v.strip().lower() in ("1", "true", "yes", "on")


def subsidy_enabled() -> bool:
    """True iff the D matching subsidy should apply on this run.

    Forced OFF under Layer-B neutralisation. Otherwise honours an explicit
    V9_D_MATCH_SUBSIDY; when unset the default is OFF under the neutral spec
    (V9_NEUTRAL_SPEC=1) and ON on the legacy path (STOP #3 user decision).
    """
    if _env_flag("V9_LAYER_B_NEUTRAL", False):
        return False
    default_on = not _env_flag("V9_NEUTRAL_SPEC", False)
    return _env_flag("V9_D_MATCH_SUBSIDY", default_on)


def subsidy_key(mode) -> Optional[str]:
    """Map a free-text mode string to a subsidy-table key, or None.

    Substring set is verbatim from the three historical inline mappers so that
    a default-ON run is bit-identical to pre-ruling: {maas,bundle}->maas,
    {bike}->bike, {car,uber}->car. Public transit modes (train/bus/public)
    map to None -> rate 0 (no PT subsidy, matching history)."""
    m = str(mode or "").lower()
    if "maas" in m or "bundle" in m:
        return "maas"
    if "bike" in m:
        return "bike"
    if "car" in m or "uber" in m:
        return "car"
    return None


def subsidy_rate(mode, income_level) -> float:
    """The fractional discount rate in [0,1). 0.0 when the subsidy is disabled,
    the income tier is unknown, or the mode is not subsidised."""
    if not subsidy_enabled():
        return 0.0
    key = subsidy_key(mode)
    if key is None:
        return 0.0
    return float(_SUBSIDY_BY_MODE.get(str(income_level), {}).get(key, 0.0))


def apply_subsidy(price, mode, income_level) -> float:
    """Post-subsidy price = price x (1 - rate). Legacy `_apply_subsidy` shim."""
    return float(price) * (1.0 - subsidy_rate(mode, income_level))


def subsidy_transfer(offer_price, mode, income_level) -> float:
    """Actual transfer = offer_price x rate (Ruling B). 0.0 when disabled."""
    return float(offer_price) * subsidy_rate(mode, income_level)


def pre_subsidy_price(consumer_price, mode, income_level) -> float:
    """Reconstruct the pre-subsidy (posted offer) price from the recorded
    post-subsidy consumer price. Exact inverse of `apply_subsidy` because the
    same rate is used on both sides (single source)."""
    rate = subsidy_rate(mode, income_level)
    if rate <= 0.0 or rate >= 1.0:
        return float(consumer_price)
    return float(consumer_price) / (1.0 - rate)


__all__ = [
    "SUBSIDY_VERSION",
    "subsidy_enabled",
    "subsidy_key",
    "subsidy_rate",
    "apply_subsidy",
    "subsidy_transfer",
    "pre_subsidy_price",
]
