"""Metric-convention tagging helper (V9 §27 Phase 1.1) — Sydney twin.

Mirrors `Rep/shared_metric_convention.py`. See that module's docstring for
purpose and semantics. Sourced from the same shared_experiment_config
constants, so the two trees emit and check the same tag.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, Union

from shared_experiment_config import METRIC_CONVENTION, METRIC_CONVENTION_PRE

SIDECAR_FILENAME = "metric_convention.json"


def write_metric_convention_sidecar(
    output_dir: Union[str, Path],
    *,
    convention: str = METRIC_CONVENTION,
    extra: Dict[str, Any] | None = None,
) -> Path:
    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    payload = {"metric_convention": str(convention)}
    if extra:
        payload.update(extra)
    path = out_dir / SIDECAR_FILENAME
    path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    return path


def read_metric_convention(output_dir: Union[str, Path]) -> str | None:
    path = Path(output_dir) / SIDECAR_FILENAME
    if not path.exists():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None
    value = payload.get("metric_convention")
    return None if value is None else str(value)


def gate_check_metric_convention(
    output_dirs,
    *,
    required: str = METRIC_CONVENTION,
) -> tuple[bool, list[dict]]:
    details = []
    ok = True
    for d in output_dirs:
        actual = read_metric_convention(d)
        row = {
            "path": str(d),
            "metric_convention": actual,
            "compliant": actual == required,
        }
        if not row["compliant"]:
            ok = False
        details.append(row)
    return ok, details


__all__ = [
    "METRIC_CONVENTION",
    "METRIC_CONVENTION_PRE",
    "SIDECAR_FILENAME",
    "write_metric_convention_sidecar",
    "read_metric_convention",
    "gate_check_metric_convention",
]
