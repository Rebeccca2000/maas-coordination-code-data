from __future__ import annotations

from typing import Any, Iterable, Mapping


def build_authoritative_request_summary(
    rows: Iterable[Mapping[str, Any]],
    *,
    model_label: str,
    seed: int | None = None,
    raw_summary: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    row_list = list(rows)
    request_count = len(row_list)
    num_matched = sum(1 for row in row_list if str(row.get("outcome", "")).strip().lower() == "success")
    match_rate = (num_matched / request_count) if request_count else 0.0

    summary = {
        "model": model_label,
        "seed": "" if seed is None else seed,
        "authoritative_request_count": request_count,
        "authoritative_num_matched": num_matched,
        "authoritative_match_rate": match_rate,
        "raw_num_requests": _safe_int(raw_summary.get("num_requests")) if raw_summary else None,
        "raw_num_matched": _safe_int(raw_summary.get("num_matched")) if raw_summary else None,
        "raw_match_rate": _safe_float(raw_summary.get("match_rate")) if raw_summary else None,
    }
    summary["request_count_mismatch"] = _compare_optional(summary["raw_num_requests"], request_count)
    summary["matched_count_mismatch"] = _compare_optional(summary["raw_num_matched"], num_matched)
    summary["match_rate_mismatch"] = _compare_float_optional(summary["raw_match_rate"], match_rate)
    summary["has_any_mismatch"] = any(
        (
            summary["request_count_mismatch"],
            summary["matched_count_mismatch"],
            summary["match_rate_mismatch"],
        )
    )
    return summary


def mismatch_diagnostics_from_summary(summary: Mapping[str, Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for field_name, raw_key, auth_key in (
        ("num_requests", "raw_num_requests", "authoritative_request_count"),
        ("num_matched", "raw_num_matched", "authoritative_num_matched"),
        ("match_rate", "raw_match_rate", "authoritative_match_rate"),
    ):
        raw_value = summary.get(raw_key)
        auth_value = summary.get(auth_key)
        if field_name in {"num_requests", "num_matched"}:
            mismatch = _compare_optional(raw_value, auth_value)
        else:
            mismatch = _compare_float_optional(raw_value, auth_value)
        if mismatch:
            rows.append(
                {
                    "model": summary.get("model"),
                    "seed": summary.get("seed"),
                    "field": field_name,
                    "raw_value": raw_value,
                    "authoritative_value": auth_value,
                    "diagnostic": "summary_field_disagrees_with_request_rows",
                }
            )
    return rows


def _safe_int(value: Any) -> int | None:
    if value in (None, ""):
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _safe_float(value: Any) -> float | None:
    if value in (None, ""):
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _compare_optional(left: Any, right: Any) -> bool:
    if left is None:
        return False
    return left != right


def _compare_float_optional(left: Any, right: float, *, tol: float = 1e-9) -> bool:
    if left is None:
        return False
    try:
        return abs(float(left) - float(right)) > tol
    except (TypeError, ValueError):
        return True
