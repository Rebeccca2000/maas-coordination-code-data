#!/usr/bin/env python3
"""
run_v9_sydney_frontier_one.py — per-cell frontier driver for the Sydney sweep.

Ruling (§B.23 build): the frontier driver WRAPS the proven runner
`run_v9_sydney_paired_one.py` — it does NOT resurrect the Rep frontier driver.
The 38 Phase-C factor worlds are materialized as regular worlds under
`Sydney_Run/worlds/<world_id>/frozen_inputs/`, so a frontier cell is just a paired
cell on a factor world: the paired runner already (a) reads that world's frozen
inputs, (b) exports V9_PT_PRICE_FACTOR / V9_DIRECT_PRICE_FACTOR from the world's
world_config (the 12 price worlds), and (c) does per-job C-DB isolation. This
wrapper delegates verbatim and only re-points the default out-root so frontier
outputs land in their own tree.

Identical CLI to run_v9_sydney_paired_one.py (so the PBS is symmetric).
"""
from __future__ import annotations
import subprocess
import sys
from pathlib import Path

_HERE = Path(__file__).resolve().parent
_PAIRED = _HERE / "run_v9_sydney_paired_one.py"


def main() -> int:
    argv = sys.argv[1:]
    if not _PAIRED.is_file():
        print(f"[error] proven runner missing: {_PAIRED}", file=sys.stderr)
        return 2
    # Delegate verbatim to the proven paired runner (same flags). The caller
    # supplies --world <factor_world_id> --out-root <frontier tree>.
    cmd = [sys.executable, str(_PAIRED), *argv]
    return subprocess.run(cmd).returncode


if __name__ == "__main__":
    raise SystemExit(main())
