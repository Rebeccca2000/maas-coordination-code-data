"""Stage 6 — Build frozen inputs for all 8 worlds on the Sydney network.

For each of the 8 CrossWorldScenarioV7 scenarios (W00..W07), generates:
    world_config.json, fixed_commuters.json, fixed_trip_requests.json,
    fingerprints.json
in worlds/<world_id>/frozen_inputs/.

By default runs single seed 42 (matches Stage 5 seed). For Stage 7 sweep,
pass a comma-separated seed list, e.g.:
    python run_world_builder_sydney.py --seeds 42,43,44
That writes per-seed subfolders: frozen_inputs/seed_42/, seed_43/, ...

Usage:
    python code/runners/run_world_builder_sydney.py
    python code/runners/run_world_builder_sydney.py --seeds 42,43,44,45,46
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

_HERE = Path(__file__).resolve().parent
_ROOT = _HERE.parents[1]
_CODE = _ROOT / "code" / "model"

for sub in ("shared", "network", "centralised"):
    p = str(_CODE / sub)
    if p not in sys.path:
        sys.path.insert(0, p)

os.environ.setdefault("MPLBACKEND", "Agg")

from dataclasses import replace

from cross_world_panel import (
    WORLD_SCENARIOS_V7,
    build_shared_world_map,
    generate_world_trips,
    generate_world_commuters,
    build_fixed_commuters_payload,
    build_fixed_trip_requests_payload,
    compute_commuter_payload_fingerprint,
    build_world_config_payload,
)
from shared_frozen_inputs import compute_trip_request_fingerprint


def _write_json(path: Path, payload) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, sort_keys=True, indent=2) + "\n", encoding="utf-8")


def build_scenario(scenario, seed: int, base_dir: Path, multi_seed: bool):
    scenario_seed = replace(scenario, generation_seed=seed) if scenario.generation_seed != seed else scenario
    shared_map = build_shared_world_map()

    trips = generate_world_trips(scenario_seed, shared_map=shared_map)
    commuters = generate_world_commuters(scenario_seed, trips)
    fixed_commuters = build_fixed_commuters_payload(scenario_seed, commuters)
    fixed_trips = build_fixed_trip_requests_payload(scenario_seed, trips)
    world_config = build_world_config_payload(
        scenario_seed, map_fingerprint=shared_map.meta.get('fingerprint', '')
    )
    fingerprints = {
        "world_id": scenario_seed.world_id,
        "scenario_id": scenario_seed.scenario_id,
        "seed": seed,
        "map_fingerprint": shared_map.meta.get("fingerprint"),
        "commuter_fingerprint": compute_commuter_payload_fingerprint(commuters),
        "trip_request_fingerprint": compute_trip_request_fingerprint(trips),
    }

    world_dir = base_dir / scenario_seed.world_id / "frozen_inputs"
    if multi_seed:
        world_dir = world_dir / f"seed_{seed}"

    _write_json(world_dir / "world_config.json", world_config)
    _write_json(world_dir / "fixed_commuters.json", fixed_commuters)
    _write_json(world_dir / "fixed_trip_requests.json", fixed_trips)
    _write_json(world_dir / "fingerprints.json", fingerprints)

    return {
        "world_id": scenario_seed.world_id,
        "seed": seed,
        "commuters": len(commuters),
        "trips": len(trips),
        "materialised": scenario_seed.materialized_commuter_count(),
        "fingerprints": fingerprints,
        "out_dir": str(world_dir),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--seeds", type=str, default="42",
                        help="Comma-separated seeds (default 42). Multi-seed writes seed_<N>/ subdirs.")
    parser.add_argument("--worlds", type=str, default="",
                        help="Comma-separated world IDs to build (default: all 8).")
    args = parser.parse_args()

    seeds = [int(s) for s in args.seeds.split(",") if s.strip()]
    world_ids = [w for w in args.worlds.split(",") if w.strip()] if args.worlds else None
    multi_seed = len(seeds) > 1

    scenarios = WORLD_SCENARIOS_V7
    if world_ids:
        scenarios = tuple(s for s in scenarios if s.world_id in world_ids)

    base_dir = _ROOT / "data" / "frozen_inputs"
    print(f"=== World builder — Sydney network ===")
    print(f"Base dir: {base_dir}")
    print(f"Seeds: {seeds}")
    print(f"Worlds: {[s.world_id for s in scenarios]}")
    print(f"Multi-seed layout: {multi_seed}")
    print()

    results = []
    for scenario in scenarios:
        for seed in seeds:
            r = build_scenario(scenario, seed, base_dir, multi_seed)
            results.append(r)
            print(f"  built {r['world_id']} seed={seed}: {r['commuters']} commuters, {r['trips']} trips  fp={r['fingerprints']['trip_request_fingerprint']}")

    manifest_path = base_dir / "build_manifest.json"
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(json.dumps({"builds": results}, sort_keys=True, indent=2) + "\n")
    print(f"\nWrote manifest: {manifest_path}")
    print(f"\n=== Stage 6 PASS: {len(results)} world x seed builds complete ===")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
