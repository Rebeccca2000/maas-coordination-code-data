#!/usr/bin/env python3
"""
build_frontier_worlds_sydney.py — materialize the 38 Phase-C frontier factor worlds
on the Sydney network from the frozen v9-neutral-spec.2 anchors.

Reuses the frozen tree's own builder (`run_world_builder_sydney.build_scenario`) and
the Sydney anchor scenario (`WORLD_SCENARIOS_V7[0]` = W00_baseline_reference, all six
axis factors = 1.0). Each factor world = the anchor with ONE factor replaced (OFAT),
per the canonical Phase-C Table-2 SWEEP_META (identical world_ids/values to the Rep
sweep builder `run_cross_world_sweep_build_v1.SWEEP_META`).

Writes to `Sydney_Run/worlds/<world_id>/frozen_inputs/` (single generation seed 42,
same structure as W00) so the proven runner `run_v9_sydney_paired_one.py` consumes each
as a regular world (it auto-exports V9_PT/DIRECT_PRICE_FACTOR from the world_config;
SC/SW/ST/SD factors are read from the same world_config by the model at runtime).

Does NOT touch the frozen Sydney code (aggregate 09b9f260 unchanged) — only adds world
input dirs. Generation seed 42 = the anchor generation seed (frozen demand per world;
the 5 model seeds 42–46 are applied at RUN time by the array).
"""
from __future__ import annotations
import sys
from dataclasses import replace
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[2]
_CODE = _ROOT / "code" / "model"
_RUNNERS = _ROOT / "code" / "runners"
if str(_RUNNERS) not in sys.path:
    sys.path.insert(0, str(_RUNNERS))
for sub in ("runners", "shared", "network", "centralised"):
    p = str(_CODE / sub)
    if p not in sys.path:
        sys.path.insert(0, p)

from run_world_builder_sydney import build_scenario, WORLD_SCENARIOS_V7  # frozen builder

GEN_SEED = 42  # anchor generation seed (frozen demand); model seeds 42-46 at run time

# Phase-C Table 2 — 38 worlds (1 anchor + 6 OFAT axes). world_id → (axis, param, value).
SWEEP_META = {
    "SA_d100_c100": ("anchor", None, 1.0),
    "SD_d060": ("demand", "demand_scale_factor", 0.60),
    "SD_d070": ("demand", "demand_scale_factor", 0.70),
    "SD_d080": ("demand", "demand_scale_factor", 0.80),
    "SD_d090": ("demand", "demand_scale_factor", 0.90),
    "SD_d110": ("demand", "demand_scale_factor", 1.10),
    "SD_d120": ("demand", "demand_scale_factor", 1.20),
    "SD_d130": ("demand", "demand_scale_factor", 1.30),
    "SD_d140": ("demand", "demand_scale_factor", 1.40),
    "SC_c030": ("capacity", "direct_capacity_factor", 0.30),
    "SC_c045": ("capacity", "direct_capacity_factor", 0.45),
    "SC_c060": ("capacity", "direct_capacity_factor", 0.60),
    "SC_c075": ("capacity", "direct_capacity_factor", 0.75),
    "SC_c090": ("capacity", "direct_capacity_factor", 0.90),
    "SC_c120": ("capacity", "direct_capacity_factor", 1.20),
    "SC_c150": ("capacity", "direct_capacity_factor", 1.50),
    "SP_p050": ("pt_price", "pt_price_factor", 0.50),
    "SP_p065": ("pt_price", "pt_price_factor", 0.65),
    "SP_p080": ("pt_price", "pt_price_factor", 0.80),
    "SP_p120": ("pt_price", "pt_price_factor", 1.20),
    "SP_p140": ("pt_price", "pt_price_factor", 1.40),
    "SP_p160": ("pt_price", "pt_price_factor", 1.60),
    "SR_p050": ("direct_price", "direct_price_factor", 0.50),
    "SR_p065": ("direct_price", "direct_price_factor", 0.65),
    "SR_p080": ("direct_price", "direct_price_factor", 0.80),
    "SR_p120": ("direct_price", "direct_price_factor", 1.20),
    "SR_p140": ("direct_price", "direct_price_factor", 1.40),
    "SR_p160": ("direct_price", "direct_price_factor", 1.60),
    "SW_w050": ("pt_wait", "pt_wait_time_factor", 0.50),
    "SW_w075": ("pt_wait", "pt_wait_time_factor", 0.75),
    "SW_w125": ("pt_wait", "pt_wait_time_factor", 1.25),
    "SW_w150": ("pt_wait", "pt_wait_time_factor", 1.50),
    "SW_w200": ("pt_wait", "pt_wait_time_factor", 2.00),
    "ST_t050": ("traffic", "background_traffic_factor", 0.50),
    "ST_t075": ("traffic", "background_traffic_factor", 0.75),
    "ST_t125": ("traffic", "background_traffic_factor", 1.25),
    "ST_t150": ("traffic", "background_traffic_factor", 1.50),
    "ST_t200": ("traffic", "background_traffic_factor", 2.00),
}

# All six axis factors reset to 1.0 on the anchor so each world is strictly OFAT.
_ALL_FACTORS = {
    "demand_scale_factor": 1.0, "direct_capacity_factor": 1.0,
    "pt_price_factor": 1.0, "direct_price_factor": 1.0,
    "pt_wait_time_factor": 1.0, "background_traffic_factor": 1.0,
}


def main() -> int:
    base_dir = _ROOT / "data" / "frozen_inputs"
    anchor = WORLD_SCENARIOS_V7[0]  # W00_baseline_reference
    assert anchor.world_id == "W00_baseline_reference", f"unexpected anchor {anchor.world_id}"
    clean = replace(anchor, **_ALL_FACTORS)  # force all factors 1.0 (W00 already is)

    print(f"materializing {len(SWEEP_META)} frontier worlds into {base_dir} (gen seed {GEN_SEED})")
    results = []
    for wid, (axis, param, value) in SWEEP_META.items():
        kw = {"world_id": wid,
              "scenario_name": f"frontier {axis} {param}={value}" if param else "frontier anchor"}
        if param is not None:
            kw[param] = value
        scenario = replace(clean, **kw)
        r = build_scenario(scenario, GEN_SEED, base_dir, multi_seed=False)
        results.append((wid, axis, param, value, r["materialised"], r["trips"]))
        print(f"  {wid:14} {axis:12} {str(param):24} v={value:<5} commuters={r['materialised']:>4} trips={r['trips']}")
    print(f"DONE — {len(results)} worlds written.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
