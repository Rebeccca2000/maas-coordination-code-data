#!/usr/bin/env python3
"""
run_v9_sydney_paired_one.py — NEUTRAL-SPEC per-cell driver for the Sydney port.

Ruling B (STOP #12 adjudication, handover §B.18): the Sydney tree had no
neutral-spec runner — only legacy Stage-7/v8 shell runners and the LEGACY-path
smoke driver `Rep/katana/run_v9_sydney_smoke_one.py` (which sets NO V9 flags).
This driver adds the FROZEN neutral env and the S3 market variant, reusing the
Sydney binaries' exact CLI (identical to run_all_worlds_seeds_sydney.sh). It
lives OUTSIDE the frozen Sydney tree (does not change the aggregate sha256).

Frozen env (FREEZE_MANIFEST §4) — single source of truth restated here only as
orchestration, never as a model value:
    C: V9_NEUTRAL_SPEC=1 V9_LAYER_B_NEUTRAL=1 MAAS_CENTRALISED_DB_PATH=<per-job>
    D: + V8_TIMEOUT_TICKS=999999 V8_D_CANONICAL_PT_FALLBACK=1 V8_BUG3_REPORT_PATH=<per-run>
       --market-variant matching_only_direct_offer_formalized_plus_pt_bundle_feasibility
       SKIP_CHAIN_PROCESSING=1 (Sydney D convention; blockchain path off)

Per-job SQLite isolation (STOP #9): each C cell points MAAS_CENTRALISED_DB_PATH at
a unique fresh DB so C legs never collide on commuter_info_log.

Outputs, per cell, under <out-root>/seed_<seed>/<world>/<arch>/:
    requests.csv (request-level, the scorer input), run_record.jsonl, run.log,
    (D) v8_bug3_fallback_report.json, manifest.json (env + input/output sha1).

smoke vs neutral: this is NOT the smoke driver. Numbers here are for the Phase-1
no-op / face-validation cells and (post schema-sync + re-freeze) the Sydney array.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

S3_VARIANT = "matching_only_direct_offer_formalized_plus_pt_bundle_feasibility"


def _sha1(path: Path) -> str:
    h = hashlib.sha1()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--repository-root",
        type=Path,
        default=Path(__file__).resolve().parents[2],
        help="Release repository root (default: detected from this script).",
    )
    ap.add_argument("--world", required=True)
    ap.add_argument("--seed", type=int, required=True)
    ap.add_argument("--arch", required=True, choices=["centralised", "decentralised"])
    ap.add_argument("--out-root", type=Path, required=True)
    ap.add_argument("--spec", choices=["neutral", "legacy"], default="neutral",
                    help="neutral = full frozen env (default). legacy = NO V9 flags "
                         "(for the Phase-1 shared-layer no-op check vs pre-freeze baseline).")
    ap.add_argument("--market-variant", default=S3_VARIANT,
                    help="D only. Default = frozen S3 variant.")
    ap.add_argument("--pt-price-factor", type=float, default=None,
                    help="Override world pt_price_factor (else read from world_config). Neutral only.")
    ap.add_argument("--direct-price-factor", type=float, default=None,
                    help="Override world direct_price_factor (else read from world_config). Neutral only.")
    args = ap.parse_args()

    repository_root = args.repository_root.resolve()
    frozen = repository_root / "data" / "frozen_inputs" / args.world / "frozen_inputs"
    fc = frozen / "fixed_commuters.json"
    ft = frozen / "fixed_trip_requests.json"
    wc = frozen / "world_config.json"
    for p in (fc, ft, wc):
        if not p.is_file():
            print(f"[error] missing frozen input: {p}", file=sys.stderr)
            return 2

    out_dir = (args.out_root / f"seed_{args.seed}" / args.world / args.arch).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    results = out_dir / "run_record.jsonl"
    req_csv = out_dir / "requests.csv"
    log = out_dir / "run.log"

    env = dict(os.environ)
    env.setdefault("MPLBACKEND", "Agg")
    # --- frozen neutral env (both arms) ---
    if args.spec == "neutral":
        env["V9_NEUTRAL_SPEC"] = "1"
        env["V9_LAYER_B_NEUTRAL"] = "1"
        # V9 caught-error-#8 (option a): export the world price factors so the
        # shared card scales PT/direct fares. Value comes from the world_config
        # (world property), overridable via CLI for the gates. Both arms consume
        # the SAME env from the SAME world_config ⇒ identical, architecture-neutral.
        _s = {}
        try:
            _s = (json.loads(wc.read_text()).get("world_level_exogenous_settings") or {})
        except Exception as _e:
            print(f"[warn] could not read price factors from world_config: {_e}")
        _ptf = args.pt_price_factor if args.pt_price_factor is not None else float(_s.get("pt_price_factor", 1.0))
        _drf = args.direct_price_factor if args.direct_price_factor is not None else float(_s.get("direct_price_factor", 1.0))
        env["V9_PT_PRICE_FACTOR"] = str(_ptf)
        env["V9_DIRECT_PRICE_FACTOR"] = str(_drf)
    else:  # legacy no-op reference: ensure the flags are UNSET
        for k in ("V9_NEUTRAL_SPEC", "V9_LAYER_B_NEUTRAL",
                  "V8_TIMEOUT_TICKS", "V8_D_CANONICAL_PT_FALLBACK", "V9_D_MATCH_SUBSIDY",
                  "V9_PT_PRICE_FACTOR", "V9_DIRECT_PRICE_FACTOR"):
            env.pop(k, None)

    if args.arch == "centralised":
        cwd = repository_root / "code" / "model" / "centralised"
        runner = "run_visualisation_03.py"
        env["MAAS_CENTRALISED_DB_PATH"] = str(out_dir / f"service_provider_seed{args.seed}.db")
        cmd = [sys.executable, runner,
               "--seed", str(args.seed),
               "--fixed-commuters", str(fc),
               "--fixed-trip-requests", str(ft),
               "--world-config", str(wc),
               "--results", str(results),
               "--request-level-results", str(req_csv),
               "--no-plots"]
    else:
        cwd = repository_root / "code" / "model" / "decentralised" / "abm" / "agents"
        runner = "run_decentralized_model.py"
        env["SKIP_CHAIN_PROCESSING"] = "1"
        env["V8_BUG3_REPORT_PATH"] = str(out_dir / "v8_bug3_fallback_report.json")
        if args.spec == "neutral":
            env["V8_TIMEOUT_TICKS"] = "999999"
            env["V8_D_CANONICAL_PT_FALLBACK"] = "1"
        cmd = [sys.executable, runner,
               "--seed", str(args.seed),
               "--market-variant", args.market_variant,
               "--fixed-commuters", str(fc),
               "--fixed-trip-requests", str(ft),
               "--world-config", str(wc),
               "--results", str(results),
               "--request-level-results", str(req_csv),
               "--no-plots"]

    if not (cwd / runner).is_file():
        print(f"[error] runner missing: {cwd/runner}", file=sys.stderr)
        return 2

    input_files = {k: {"path": str(p), "sha1": _sha1(p)}
                   for k, p in (("fixed_commuters", fc), ("fixed_trip_requests", ft),
                                ("world_config", wc))}

    print(f"[run] spec={args.spec} world={args.world} seed={args.seed} arch={args.arch}")
    print(f"[run] cmd: {' '.join(cmd)} (cwd={cwd})")
    with log.open("w") as lf:
        proc = subprocess.run(cmd, cwd=str(cwd), env=env, stdout=lf, stderr=subprocess.STDOUT)

    produced = sorted(str(p.relative_to(out_dir)) for p in out_dir.rglob("*") if p.is_file())
    outputs = {rel: _sha1(out_dir / rel) for rel in produced}
    status = "RAN_TO_COMPLETION" if proc.returncode == 0 else f"FAILED_rc{proc.returncode}"
    manifest = dict(
        driver="run_v9_sydney_paired_one.py", spec=args.spec, tag_target="v9-neutral-spec.1",
        world=args.world, seed=args.seed, arch=args.arch, status=status, returncode=proc.returncode,
        repository_root=str(repository_root), runner=str(cwd / runner),
        market_variant=(args.market_variant if args.arch == "decentralised" else None),
        frozen_env=dict(
            V9_NEUTRAL_SPEC=env.get("V9_NEUTRAL_SPEC"),
            V9_LAYER_B_NEUTRAL=env.get("V9_LAYER_B_NEUTRAL"),
            V8_TIMEOUT_TICKS=env.get("V8_TIMEOUT_TICKS"),
            V8_D_CANONICAL_PT_FALLBACK=env.get("V8_D_CANONICAL_PT_FALLBACK"),
            V9_PT_PRICE_FACTOR=env.get("V9_PT_PRICE_FACTOR"),
            V9_DIRECT_PRICE_FACTOR=env.get("V9_DIRECT_PRICE_FACTOR"),
            MAAS_CENTRALISED_DB_PATH=env.get("MAAS_CENTRALISED_DB_PATH"),
        ),
        input_files=input_files, output_files=outputs,
        request_level_csv=str(req_csv), produced_request_csv=req_csv.is_file(),
    )
    (out_dir / "manifest.json").write_text(json.dumps(manifest, indent=2))
    print(f"[{'ok' if proc.returncode == 0 else 'FAIL'}] {status} — outputs: {produced}")
    return proc.returncode


if __name__ == "__main__":
    sys.exit(main())
