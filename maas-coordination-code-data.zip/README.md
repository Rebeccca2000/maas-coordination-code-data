# Coordination architecture comparison code and data

This repository contains the code and numerical data needed to inspect and reproduce the computational results for the accompanying Nature Communications manuscript on centralised and decentralised Mobility as a Service coordination. Manuscript source files, submitted figures and unrelated historical outputs are deliberately excluded.

## Authors

- [Ruiyi Zhao](https://edas.info/showPerson.php?p=2467850&c=34965), University of New South Wales, Australia
- [Khaled Almiani](https://edas.info/showPerson.php?p=1664449&c=34965), Higher Colleges of Technology, United Arab Emirates
- [Salil S Kanhere](https://edas.info/showPerson.php?p=108880&c=34965), UNSW Sydney, Australia
- [Travis Waller](https://edas.info/showPerson.php?p=132851&c=34965), The University of Texas at Austin, USA
- [Taha H. Rashidi](https://edas.info/showPerson.php?p=2026639&c=34965), University of New South Wales, Australia

## Repository contents

- `code/model/` contains the centralised dispatcher, decentralised market, shared experiment logic and Sydney-referenced network implementation.
- `code/runners/` contains the paired stress-world and one-factor sensitivity runners and the frozen-input builders.
- `code/analysis/reproduce_headline_metrics.py` rebuilds the five headline stress-world metrics from request-level outputs and checks them against the archived source table.
- `data/frozen_inputs/` contains the 46 frozen input worlds used in the eight stress tests and 38 one-factor sensitivity settings.
- `data/stress_runs/` contains request-level results for eight stress worlds, two architectures and five paired random seeds.
- `data/sensitivity_runs/` contains request-level results for 38 one-factor settings, two architectures and five paired random seeds.
- `data/source_data/` contains the final numerical tables used for the manuscript figures, tables and supplementary checks. The `sydney` subdirectory contains the principal results; `synthetic` contains the independent synthetic-network robustness results.

The archived stress and sensitivity outputs use seeds 42 to 46. The W06 stress-world results and the direct-capacity sensitivity axis contain the final corrected specification used in the manuscript.

## Reproduce the headline table

Create a Python environment, install the dependencies, and run:

```bash
python code/analysis/reproduce_headline_metrics.py --check
```

A successful check reports that all 40 rows reproduce the stored five-metric source table. To write a fresh copy as well:

```bash
python code/analysis/reproduce_headline_metrics.py --check --output reproduced_headline_metrics.csv
```

## Re-run a simulation cell

The following command reruns one architecture for one frozen world. Choose `centralised` or `decentralised`, and provide a separate output directory so the archived results are not overwritten.

```bash
python code/runners/run_v9_sydney_paired_one.py \
  --world W00_baseline_reference \
  --seed 42 \
  --arch centralised \
  --out-root rerun_outputs
```

The simulations use a 10-minute model tick. Generalised cost is reported in minutes-equivalent per served trip as door-to-door time plus fare divided by the income-specific value of time. The value-of-time assumptions are AUD 5, 10 and 20 per hour for low-, middle- and high-income travellers, respectively.

## Data interpretation

Each `requests.csv` file records one request and whether it was served. Served-trip averages must therefore be interpreted with Match Rate. The source-data directory includes the like-for-like served-set checks used to determine whether a small apparent performance difference was caused by different sets of completed requests.

The `manifest.json` files retained with each run record the frozen settings, input hashes and execution environment used for that cell. Historical machine paths in those provenance records have been replaced with portable repository-relative markers; they are not runtime dependencies.

## License

The code is released under the MIT License. Data are released under the Creative Commons Attribution 4.0 International License. See `LICENSE` for details.
